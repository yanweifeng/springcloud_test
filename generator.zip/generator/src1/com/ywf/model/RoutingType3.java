package com.ywf.model;

import java.util.Date;

public class RoutingType3 {
    private Long id;

    private Long routingtype1Id;

    private Long createId;

    private String link;

    private Integer seqnum;

    private Integer restnum;

    private String mktind;

    private String mktcity1;

    private String mktcity2;

    private String mktappl;

    private String viaind;

    private String viacxrcity;

    private String vianondir;

    private String viasur;

    private String rwctmpm;

    private String reserved;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRoutingtype1Id() {
        return routingtype1Id;
    }

    public void setRoutingtype1Id(Long routingtype1Id) {
        this.routingtype1Id = routingtype1Id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link == null ? null : link.trim();
    }

    public Integer getSeqnum() {
        return seqnum;
    }

    public void setSeqnum(Integer seqnum) {
        this.seqnum = seqnum;
    }

    public Integer getRestnum() {
        return restnum;
    }

    public void setRestnum(Integer restnum) {
        this.restnum = restnum;
    }

    public String getMktind() {
        return mktind;
    }

    public void setMktind(String mktind) {
        this.mktind = mktind == null ? null : mktind.trim();
    }

    public String getMktcity1() {
        return mktcity1;
    }

    public void setMktcity1(String mktcity1) {
        this.mktcity1 = mktcity1 == null ? null : mktcity1.trim();
    }

    public String getMktcity2() {
        return mktcity2;
    }

    public void setMktcity2(String mktcity2) {
        this.mktcity2 = mktcity2 == null ? null : mktcity2.trim();
    }

    public String getMktappl() {
        return mktappl;
    }

    public void setMktappl(String mktappl) {
        this.mktappl = mktappl == null ? null : mktappl.trim();
    }

    public String getViaind() {
        return viaind;
    }

    public void setViaind(String viaind) {
        this.viaind = viaind == null ? null : viaind.trim();
    }

    public String getViacxrcity() {
        return viacxrcity;
    }

    public void setViacxrcity(String viacxrcity) {
        this.viacxrcity = viacxrcity == null ? null : viacxrcity.trim();
    }

    public String getVianondir() {
        return vianondir;
    }

    public void setVianondir(String vianondir) {
        this.vianondir = vianondir == null ? null : vianondir.trim();
    }

    public String getViasur() {
        return viasur;
    }

    public void setViasur(String viasur) {
        this.viasur = viasur == null ? null : viasur.trim();
    }

    public String getRwctmpm() {
        return rwctmpm;
    }

    public void setRwctmpm(String rwctmpm) {
        this.rwctmpm = rwctmpm == null ? null : rwctmpm.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}