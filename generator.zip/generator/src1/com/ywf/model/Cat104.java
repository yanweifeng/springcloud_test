package com.ywf.model;

import java.util.Date;

public class Cat104 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String restr;

    private String normal;

    private String spec;

    private String filler1;

    private String uscan;

    private String dom;

    private String intl;

    private String same;

    private String appl;

    private String loctype;

    private String loc1code;

    private String loc2code;

    private String filler2;

    private String abacomb;

    private String allsegs;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String filler3;

    private Date createtime;

    private Date updatetime;

    private String constpoint;

    private String tkt;

    private String farebrkstop;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getRestr() {
        return restr;
    }

    public void setRestr(String restr) {
        this.restr = restr == null ? null : restr.trim();
    }

    public String getNormal() {
        return normal;
    }

    public void setNormal(String normal) {
        this.normal = normal == null ? null : normal.trim();
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec == null ? null : spec.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getUscan() {
        return uscan;
    }

    public void setUscan(String uscan) {
        this.uscan = uscan == null ? null : uscan.trim();
    }

    public String getDom() {
        return dom;
    }

    public void setDom(String dom) {
        this.dom = dom == null ? null : dom.trim();
    }

    public String getIntl() {
        return intl;
    }

    public void setIntl(String intl) {
        this.intl = intl == null ? null : intl.trim();
    }

    public String getSame() {
        return same;
    }

    public void setSame(String same) {
        this.same = same == null ? null : same.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getLoctype() {
        return loctype;
    }

    public void setLoctype(String loctype) {
        this.loctype = loctype == null ? null : loctype.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public String getAbacomb() {
        return abacomb;
    }

    public void setAbacomb(String abacomb) {
        this.abacomb = abacomb == null ? null : abacomb.trim();
    }

    public String getAllsegs() {
        return allsegs;
    }

    public void setAllsegs(String allsegs) {
        this.allsegs = allsegs == null ? null : allsegs.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getFiller3() {
        return filler3;
    }

    public void setFiller3(String filler3) {
        this.filler3 = filler3 == null ? null : filler3.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getConstpoint() {
        return constpoint;
    }

    public void setConstpoint(String constpoint) {
        this.constpoint = constpoint == null ? null : constpoint.trim();
    }

    public String getTkt() {
        return tkt;
    }

    public void setTkt(String tkt) {
        this.tkt = tkt == null ? null : tkt.trim();
    }

    public String getFarebrkstop() {
        return farebrkstop;
    }

    public void setFarebrkstop(String farebrkstop) {
        this.farebrkstop = farebrkstop == null ? null : farebrkstop.trim();
    }
}