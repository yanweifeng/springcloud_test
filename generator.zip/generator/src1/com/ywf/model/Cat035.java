package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat035 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String sectblno;

    private String ptc;

    private String farctblno;

    private String methodtype;

    private String netgrosind;

    private String tktpct;

    private BigDecimal comamt1;

    private String comcur1;

    private Integer comdec1;

    private BigDecimal comamt2;

    private String comcur2;

    private Integer comdec2;

    private String reserved1;

    private String upgrade;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String reserved2;

    private String tktind;

    private String tktappl;

    private String tktcxr;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    private String filler;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getSectblno() {
        return sectblno;
    }

    public void setSectblno(String sectblno) {
        this.sectblno = sectblno == null ? null : sectblno.trim();
    }

    public String getPtc() {
        return ptc;
    }

    public void setPtc(String ptc) {
        this.ptc = ptc == null ? null : ptc.trim();
    }

    public String getFarctblno() {
        return farctblno;
    }

    public void setFarctblno(String farctblno) {
        this.farctblno = farctblno == null ? null : farctblno.trim();
    }

    public String getMethodtype() {
        return methodtype;
    }

    public void setMethodtype(String methodtype) {
        this.methodtype = methodtype == null ? null : methodtype.trim();
    }

    public String getNetgrosind() {
        return netgrosind;
    }

    public void setNetgrosind(String netgrosind) {
        this.netgrosind = netgrosind == null ? null : netgrosind.trim();
    }

    public String getTktpct() {
        return tktpct;
    }

    public void setTktpct(String tktpct) {
        this.tktpct = tktpct == null ? null : tktpct.trim();
    }

    public BigDecimal getComamt1() {
        return comamt1;
    }

    public void setComamt1(BigDecimal comamt1) {
        this.comamt1 = comamt1;
    }

    public String getComcur1() {
        return comcur1;
    }

    public void setComcur1(String comcur1) {
        this.comcur1 = comcur1 == null ? null : comcur1.trim();
    }

    public Integer getComdec1() {
        return comdec1;
    }

    public void setComdec1(Integer comdec1) {
        this.comdec1 = comdec1;
    }

    public BigDecimal getComamt2() {
        return comamt2;
    }

    public void setComamt2(BigDecimal comamt2) {
        this.comamt2 = comamt2;
    }

    public String getComcur2() {
        return comcur2;
    }

    public void setComcur2(String comcur2) {
        this.comcur2 = comcur2 == null ? null : comcur2.trim();
    }

    public Integer getComdec2() {
        return comdec2;
    }

    public void setComdec2(Integer comdec2) {
        this.comdec2 = comdec2;
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1 == null ? null : reserved1.trim();
    }

    public String getUpgrade() {
        return upgrade;
    }

    public void setUpgrade(String upgrade) {
        this.upgrade = upgrade == null ? null : upgrade.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getReserved2() {
        return reserved2;
    }

    public void setReserved2(String reserved2) {
        this.reserved2 = reserved2 == null ? null : reserved2.trim();
    }

    public String getTktind() {
        return tktind;
    }

    public void setTktind(String tktind) {
        this.tktind = tktind == null ? null : tktind.trim();
    }

    public String getTktappl() {
        return tktappl;
    }

    public void setTktappl(String tktappl) {
        this.tktappl = tktappl == null ? null : tktappl.trim();
    }

    public String getTktcxr() {
        return tktcxr;
    }

    public void setTktcxr(String tktcxr) {
        this.tktcxr = tktcxr == null ? null : tktcxr.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }
}