package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat025 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String psgrtype;

    private String psgrappl;

    private String psgrstat;

    private String geotype;

    private String geoloc;

    private String psgrid;

    private Integer psgrmin;

    private Integer psgrmax;

    private Integer psgrocc1;

    private Integer psgrocc2;

    private String twwtype;

    private String twwloc;

    private String reserved1;

    private String psgtsi;

    private String ptotype;

    private String ptoloc;

    private String reserved2;

    private Integer fltsegs;

    private String nodisc;

    private Integer milemin;

    private Integer milemax;

    private String farecalc;

    private String farepcnt;

    private BigDecimal sfare1amt;

    private String sfare1cur;

    private Integer sfare1dec;

    private BigDecimal sfare2amt;

    private String sfare2cur;

    private Integer sfare2dec;

    private String reserved3;

    private BigDecimal rfare1min;

    private BigDecimal rfare1max;

    private String rfare1cur;

    private Integer rfare1dec;

    private BigDecimal rfare2min;

    private BigDecimal rfare2max;

    private String rfare2cur;

    private Integer rfare2dec;

    private String rulestrf;

    private String carrier;

    private String fareclass;

    private String faretype;

    private String sameTrfrule;

    private String reserved4;

    private String rfowrt;

    private String rfglobal;

    private String rfroutetrf;

    private String rfrouteno;

    private String rfmpm;

    private String rfclass;

    private String rfarecode;

    private String rfseason;

    private String rfdow;

    private String rfdiscat;

    private String rfprccat;

    private String rfbkcode;

    private String rftblno;

    private String primesector;

    private String reserved5;

    private String rftktcode;

    private String rftcm;

    private String rftktdsgn;

    private String rftktdmod;

    private String catotag;

    private String highest;

    private String dtetblno;

    private String txttblno;

    private String bsetblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getPsgrtype() {
        return psgrtype;
    }

    public void setPsgrtype(String psgrtype) {
        this.psgrtype = psgrtype == null ? null : psgrtype.trim();
    }

    public String getPsgrappl() {
        return psgrappl;
    }

    public void setPsgrappl(String psgrappl) {
        this.psgrappl = psgrappl == null ? null : psgrappl.trim();
    }

    public String getPsgrstat() {
        return psgrstat;
    }

    public void setPsgrstat(String psgrstat) {
        this.psgrstat = psgrstat == null ? null : psgrstat.trim();
    }

    public String getGeotype() {
        return geotype;
    }

    public void setGeotype(String geotype) {
        this.geotype = geotype == null ? null : geotype.trim();
    }

    public String getGeoloc() {
        return geoloc;
    }

    public void setGeoloc(String geoloc) {
        this.geoloc = geoloc == null ? null : geoloc.trim();
    }

    public String getPsgrid() {
        return psgrid;
    }

    public void setPsgrid(String psgrid) {
        this.psgrid = psgrid == null ? null : psgrid.trim();
    }

    public Integer getPsgrmin() {
        return psgrmin;
    }

    public void setPsgrmin(Integer psgrmin) {
        this.psgrmin = psgrmin;
    }

    public Integer getPsgrmax() {
        return psgrmax;
    }

    public void setPsgrmax(Integer psgrmax) {
        this.psgrmax = psgrmax;
    }

    public Integer getPsgrocc1() {
        return psgrocc1;
    }

    public void setPsgrocc1(Integer psgrocc1) {
        this.psgrocc1 = psgrocc1;
    }

    public Integer getPsgrocc2() {
        return psgrocc2;
    }

    public void setPsgrocc2(Integer psgrocc2) {
        this.psgrocc2 = psgrocc2;
    }

    public String getTwwtype() {
        return twwtype;
    }

    public void setTwwtype(String twwtype) {
        this.twwtype = twwtype == null ? null : twwtype.trim();
    }

    public String getTwwloc() {
        return twwloc;
    }

    public void setTwwloc(String twwloc) {
        this.twwloc = twwloc == null ? null : twwloc.trim();
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1 == null ? null : reserved1.trim();
    }

    public String getPsgtsi() {
        return psgtsi;
    }

    public void setPsgtsi(String psgtsi) {
        this.psgtsi = psgtsi == null ? null : psgtsi.trim();
    }

    public String getPtotype() {
        return ptotype;
    }

    public void setPtotype(String ptotype) {
        this.ptotype = ptotype == null ? null : ptotype.trim();
    }

    public String getPtoloc() {
        return ptoloc;
    }

    public void setPtoloc(String ptoloc) {
        this.ptoloc = ptoloc == null ? null : ptoloc.trim();
    }

    public String getReserved2() {
        return reserved2;
    }

    public void setReserved2(String reserved2) {
        this.reserved2 = reserved2 == null ? null : reserved2.trim();
    }

    public Integer getFltsegs() {
        return fltsegs;
    }

    public void setFltsegs(Integer fltsegs) {
        this.fltsegs = fltsegs;
    }

    public String getNodisc() {
        return nodisc;
    }

    public void setNodisc(String nodisc) {
        this.nodisc = nodisc == null ? null : nodisc.trim();
    }

    public Integer getMilemin() {
        return milemin;
    }

    public void setMilemin(Integer milemin) {
        this.milemin = milemin;
    }

    public Integer getMilemax() {
        return milemax;
    }

    public void setMilemax(Integer milemax) {
        this.milemax = milemax;
    }

    public String getFarecalc() {
        return farecalc;
    }

    public void setFarecalc(String farecalc) {
        this.farecalc = farecalc == null ? null : farecalc.trim();
    }

    public String getFarepcnt() {
        return farepcnt;
    }

    public void setFarepcnt(String farepcnt) {
        this.farepcnt = farepcnt == null ? null : farepcnt.trim();
    }

    public BigDecimal getSfare1amt() {
        return sfare1amt;
    }

    public void setSfare1amt(BigDecimal sfare1amt) {
        this.sfare1amt = sfare1amt;
    }

    public String getSfare1cur() {
        return sfare1cur;
    }

    public void setSfare1cur(String sfare1cur) {
        this.sfare1cur = sfare1cur == null ? null : sfare1cur.trim();
    }

    public Integer getSfare1dec() {
        return sfare1dec;
    }

    public void setSfare1dec(Integer sfare1dec) {
        this.sfare1dec = sfare1dec;
    }

    public BigDecimal getSfare2amt() {
        return sfare2amt;
    }

    public void setSfare2amt(BigDecimal sfare2amt) {
        this.sfare2amt = sfare2amt;
    }

    public String getSfare2cur() {
        return sfare2cur;
    }

    public void setSfare2cur(String sfare2cur) {
        this.sfare2cur = sfare2cur == null ? null : sfare2cur.trim();
    }

    public Integer getSfare2dec() {
        return sfare2dec;
    }

    public void setSfare2dec(Integer sfare2dec) {
        this.sfare2dec = sfare2dec;
    }

    public String getReserved3() {
        return reserved3;
    }

    public void setReserved3(String reserved3) {
        this.reserved3 = reserved3 == null ? null : reserved3.trim();
    }

    public BigDecimal getRfare1min() {
        return rfare1min;
    }

    public void setRfare1min(BigDecimal rfare1min) {
        this.rfare1min = rfare1min;
    }

    public BigDecimal getRfare1max() {
        return rfare1max;
    }

    public void setRfare1max(BigDecimal rfare1max) {
        this.rfare1max = rfare1max;
    }

    public String getRfare1cur() {
        return rfare1cur;
    }

    public void setRfare1cur(String rfare1cur) {
        this.rfare1cur = rfare1cur == null ? null : rfare1cur.trim();
    }

    public Integer getRfare1dec() {
        return rfare1dec;
    }

    public void setRfare1dec(Integer rfare1dec) {
        this.rfare1dec = rfare1dec;
    }

    public BigDecimal getRfare2min() {
        return rfare2min;
    }

    public void setRfare2min(BigDecimal rfare2min) {
        this.rfare2min = rfare2min;
    }

    public BigDecimal getRfare2max() {
        return rfare2max;
    }

    public void setRfare2max(BigDecimal rfare2max) {
        this.rfare2max = rfare2max;
    }

    public String getRfare2cur() {
        return rfare2cur;
    }

    public void setRfare2cur(String rfare2cur) {
        this.rfare2cur = rfare2cur == null ? null : rfare2cur.trim();
    }

    public Integer getRfare2dec() {
        return rfare2dec;
    }

    public void setRfare2dec(Integer rfare2dec) {
        this.rfare2dec = rfare2dec;
    }

    public String getRulestrf() {
        return rulestrf;
    }

    public void setRulestrf(String rulestrf) {
        this.rulestrf = rulestrf == null ? null : rulestrf.trim();
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    public String getFareclass() {
        return fareclass;
    }

    public void setFareclass(String fareclass) {
        this.fareclass = fareclass == null ? null : fareclass.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getSameTrfrule() {
        return sameTrfrule;
    }

    public void setSameTrfrule(String sameTrfrule) {
        this.sameTrfrule = sameTrfrule == null ? null : sameTrfrule.trim();
    }

    public String getReserved4() {
        return reserved4;
    }

    public void setReserved4(String reserved4) {
        this.reserved4 = reserved4 == null ? null : reserved4.trim();
    }

    public String getRfowrt() {
        return rfowrt;
    }

    public void setRfowrt(String rfowrt) {
        this.rfowrt = rfowrt == null ? null : rfowrt.trim();
    }

    public String getRfglobal() {
        return rfglobal;
    }

    public void setRfglobal(String rfglobal) {
        this.rfglobal = rfglobal == null ? null : rfglobal.trim();
    }

    public String getRfroutetrf() {
        return rfroutetrf;
    }

    public void setRfroutetrf(String rfroutetrf) {
        this.rfroutetrf = rfroutetrf == null ? null : rfroutetrf.trim();
    }

    public String getRfrouteno() {
        return rfrouteno;
    }

    public void setRfrouteno(String rfrouteno) {
        this.rfrouteno = rfrouteno == null ? null : rfrouteno.trim();
    }

    public String getRfmpm() {
        return rfmpm;
    }

    public void setRfmpm(String rfmpm) {
        this.rfmpm = rfmpm == null ? null : rfmpm.trim();
    }

    public String getRfclass() {
        return rfclass;
    }

    public void setRfclass(String rfclass) {
        this.rfclass = rfclass == null ? null : rfclass.trim();
    }

    public String getRfarecode() {
        return rfarecode;
    }

    public void setRfarecode(String rfarecode) {
        this.rfarecode = rfarecode == null ? null : rfarecode.trim();
    }

    public String getRfseason() {
        return rfseason;
    }

    public void setRfseason(String rfseason) {
        this.rfseason = rfseason == null ? null : rfseason.trim();
    }

    public String getRfdow() {
        return rfdow;
    }

    public void setRfdow(String rfdow) {
        this.rfdow = rfdow == null ? null : rfdow.trim();
    }

    public String getRfdiscat() {
        return rfdiscat;
    }

    public void setRfdiscat(String rfdiscat) {
        this.rfdiscat = rfdiscat == null ? null : rfdiscat.trim();
    }

    public String getRfprccat() {
        return rfprccat;
    }

    public void setRfprccat(String rfprccat) {
        this.rfprccat = rfprccat == null ? null : rfprccat.trim();
    }

    public String getRfbkcode() {
        return rfbkcode;
    }

    public void setRfbkcode(String rfbkcode) {
        this.rfbkcode = rfbkcode == null ? null : rfbkcode.trim();
    }

    public String getRftblno() {
        return rftblno;
    }

    public void setRftblno(String rftblno) {
        this.rftblno = rftblno == null ? null : rftblno.trim();
    }

    public String getPrimesector() {
        return primesector;
    }

    public void setPrimesector(String primesector) {
        this.primesector = primesector == null ? null : primesector.trim();
    }

    public String getReserved5() {
        return reserved5;
    }

    public void setReserved5(String reserved5) {
        this.reserved5 = reserved5 == null ? null : reserved5.trim();
    }

    public String getRftktcode() {
        return rftktcode;
    }

    public void setRftktcode(String rftktcode) {
        this.rftktcode = rftktcode == null ? null : rftktcode.trim();
    }

    public String getRftcm() {
        return rftcm;
    }

    public void setRftcm(String rftcm) {
        this.rftcm = rftcm == null ? null : rftcm.trim();
    }

    public String getRftktdsgn() {
        return rftktdsgn;
    }

    public void setRftktdsgn(String rftktdsgn) {
        this.rftktdsgn = rftktdsgn == null ? null : rftktdsgn.trim();
    }

    public String getRftktdmod() {
        return rftktdmod;
    }

    public void setRftktdmod(String rftktdmod) {
        this.rftktdmod = rftktdmod == null ? null : rftktdmod.trim();
    }

    public String getCatotag() {
        return catotag;
    }

    public void setCatotag(String catotag) {
        this.catotag = catotag == null ? null : catotag.trim();
    }

    public String getHighest() {
        return highest;
    }

    public void setHighest(String highest) {
        this.highest = highest == null ? null : highest.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getBsetblno() {
        return bsetblno;
    }

    public void setBsetblno(String bsetblno) {
        this.bsetblno = bsetblno == null ? null : bsetblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}