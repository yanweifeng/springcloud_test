package com.ywf.model;

import java.util.Date;

public class Cat015 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private Date eresdate;

    private Date etktdate;

    private Date lresdate;

    private Date ltktdate;

    private String ctry;

    private String res;

    private String cxrsale;

    private String cxroth;

    private String cxrval;

    private String cxrseg;

    private String tasale;

    private String tasel;

    private String fopca;

    private String fopck;

    private String fopcr;

    private String foptr;

    private String curctry;

    private String curcode;

    private String tkismail;

    private String tkispta;

    private String tkismech;

    private String tkisself;

    private String tkisptat;

    private String tkisatm;

    private String tkisstp;

    private String tkissato;

    private String tkisetkt;

    private String tkisrsvd;

    private String siti;

    private String soto;

    private String sito;

    private String soti;

    private String reserved;

    private String famgrp;

    private String extens;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public Date getEresdate() {
        return eresdate;
    }

    public void setEresdate(Date eresdate) {
        this.eresdate = eresdate;
    }

    public Date getEtktdate() {
        return etktdate;
    }

    public void setEtktdate(Date etktdate) {
        this.etktdate = etktdate;
    }

    public Date getLresdate() {
        return lresdate;
    }

    public void setLresdate(Date lresdate) {
        this.lresdate = lresdate;
    }

    public Date getLtktdate() {
        return ltktdate;
    }

    public void setLtktdate(Date ltktdate) {
        this.ltktdate = ltktdate;
    }

    public String getCtry() {
        return ctry;
    }

    public void setCtry(String ctry) {
        this.ctry = ctry == null ? null : ctry.trim();
    }

    public String getRes() {
        return res;
    }

    public void setRes(String res) {
        this.res = res == null ? null : res.trim();
    }

    public String getCxrsale() {
        return cxrsale;
    }

    public void setCxrsale(String cxrsale) {
        this.cxrsale = cxrsale == null ? null : cxrsale.trim();
    }

    public String getCxroth() {
        return cxroth;
    }

    public void setCxroth(String cxroth) {
        this.cxroth = cxroth == null ? null : cxroth.trim();
    }

    public String getCxrval() {
        return cxrval;
    }

    public void setCxrval(String cxrval) {
        this.cxrval = cxrval == null ? null : cxrval.trim();
    }

    public String getCxrseg() {
        return cxrseg;
    }

    public void setCxrseg(String cxrseg) {
        this.cxrseg = cxrseg == null ? null : cxrseg.trim();
    }

    public String getTasale() {
        return tasale;
    }

    public void setTasale(String tasale) {
        this.tasale = tasale == null ? null : tasale.trim();
    }

    public String getTasel() {
        return tasel;
    }

    public void setTasel(String tasel) {
        this.tasel = tasel == null ? null : tasel.trim();
    }

    public String getFopca() {
        return fopca;
    }

    public void setFopca(String fopca) {
        this.fopca = fopca == null ? null : fopca.trim();
    }

    public String getFopck() {
        return fopck;
    }

    public void setFopck(String fopck) {
        this.fopck = fopck == null ? null : fopck.trim();
    }

    public String getFopcr() {
        return fopcr;
    }

    public void setFopcr(String fopcr) {
        this.fopcr = fopcr == null ? null : fopcr.trim();
    }

    public String getFoptr() {
        return foptr;
    }

    public void setFoptr(String foptr) {
        this.foptr = foptr == null ? null : foptr.trim();
    }

    public String getCurctry() {
        return curctry;
    }

    public void setCurctry(String curctry) {
        this.curctry = curctry == null ? null : curctry.trim();
    }

    public String getCurcode() {
        return curcode;
    }

    public void setCurcode(String curcode) {
        this.curcode = curcode == null ? null : curcode.trim();
    }

    public String getTkismail() {
        return tkismail;
    }

    public void setTkismail(String tkismail) {
        this.tkismail = tkismail == null ? null : tkismail.trim();
    }

    public String getTkispta() {
        return tkispta;
    }

    public void setTkispta(String tkispta) {
        this.tkispta = tkispta == null ? null : tkispta.trim();
    }

    public String getTkismech() {
        return tkismech;
    }

    public void setTkismech(String tkismech) {
        this.tkismech = tkismech == null ? null : tkismech.trim();
    }

    public String getTkisself() {
        return tkisself;
    }

    public void setTkisself(String tkisself) {
        this.tkisself = tkisself == null ? null : tkisself.trim();
    }

    public String getTkisptat() {
        return tkisptat;
    }

    public void setTkisptat(String tkisptat) {
        this.tkisptat = tkisptat == null ? null : tkisptat.trim();
    }

    public String getTkisatm() {
        return tkisatm;
    }

    public void setTkisatm(String tkisatm) {
        this.tkisatm = tkisatm == null ? null : tkisatm.trim();
    }

    public String getTkisstp() {
        return tkisstp;
    }

    public void setTkisstp(String tkisstp) {
        this.tkisstp = tkisstp == null ? null : tkisstp.trim();
    }

    public String getTkissato() {
        return tkissato;
    }

    public void setTkissato(String tkissato) {
        this.tkissato = tkissato == null ? null : tkissato.trim();
    }

    public String getTkisetkt() {
        return tkisetkt;
    }

    public void setTkisetkt(String tkisetkt) {
        this.tkisetkt = tkisetkt == null ? null : tkisetkt.trim();
    }

    public String getTkisrsvd() {
        return tkisrsvd;
    }

    public void setTkisrsvd(String tkisrsvd) {
        this.tkisrsvd = tkisrsvd == null ? null : tkisrsvd.trim();
    }

    public String getSiti() {
        return siti;
    }

    public void setSiti(String siti) {
        this.siti = siti == null ? null : siti.trim();
    }

    public String getSoto() {
        return soto;
    }

    public void setSoto(String soto) {
        this.soto = soto == null ? null : soto.trim();
    }

    public String getSito() {
        return sito;
    }

    public void setSito(String sito) {
        this.sito = sito == null ? null : sito.trim();
    }

    public String getSoti() {
        return soti;
    }

    public void setSoti(String soti) {
        this.soti = soti == null ? null : soti.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public String getFamgrp() {
        return famgrp;
    }

    public void setFamgrp(String famgrp) {
        this.famgrp = famgrp == null ? null : famgrp.trim();
    }

    public String getExtens() {
        return extens;
    }

    public void setExtens(String extens) {
        this.extens = extens == null ? null : extens.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}