package com.ywf.model;

import java.util.Date;

public class Tbl994 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String reserve;

    private Date tvleffdt;

    private Date tvldisdt;

    private Date tkteffdt;

    private Date tktdisdt;

    private Date rsveffdt;

    private Date rsvdisdt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getReserve() {
        return reserve;
    }

    public void setReserve(String reserve) {
        this.reserve = reserve == null ? null : reserve.trim();
    }

    public Date getTvleffdt() {
        return tvleffdt;
    }

    public void setTvleffdt(Date tvleffdt) {
        this.tvleffdt = tvleffdt;
    }

    public Date getTvldisdt() {
        return tvldisdt;
    }

    public void setTvldisdt(Date tvldisdt) {
        this.tvldisdt = tvldisdt;
    }

    public Date getTkteffdt() {
        return tkteffdt;
    }

    public void setTkteffdt(Date tkteffdt) {
        this.tkteffdt = tkteffdt;
    }

    public Date getTktdisdt() {
        return tktdisdt;
    }

    public void setTktdisdt(Date tktdisdt) {
        this.tktdisdt = tktdisdt;
    }

    public Date getRsveffdt() {
        return rsveffdt;
    }

    public void setRsveffdt(Date rsveffdt) {
        this.rsveffdt = rsveffdt;
    }

    public Date getRsvdisdt() {
        return rsvdisdt;
    }

    public void setRsvdisdt(Date rsvdisdt) {
        this.rsvdisdt = rsvdisdt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}