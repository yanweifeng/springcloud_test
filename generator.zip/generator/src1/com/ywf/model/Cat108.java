package com.ywf.model;

import java.util.Date;

public class Cat108 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String appl;

    private String norm1;

    private String owrt;

    private String same;

    private String val;

    private String type;

    private String fcl;

    private String pensca;

    private String mrph;

    private String append;

    private String reserve;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getNorm1() {
        return norm1;
    }

    public void setNorm1(String norm1) {
        this.norm1 = norm1 == null ? null : norm1.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getSame() {
        return same;
    }

    public void setSame(String same) {
        this.same = same == null ? null : same.trim();
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val == null ? null : val.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getPensca() {
        return pensca;
    }

    public void setPensca(String pensca) {
        this.pensca = pensca == null ? null : pensca.trim();
    }

    public String getMrph() {
        return mrph;
    }

    public void setMrph(String mrph) {
        this.mrph = mrph == null ? null : mrph.trim();
    }

    public String getAppend() {
        return append;
    }

    public void setAppend(String append) {
        this.append = append == null ? null : append.trim();
    }

    public String getReserve() {
        return reserve;
    }

    public void setReserve(String reserve) {
        this.reserve = reserve == null ? null : reserve.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}