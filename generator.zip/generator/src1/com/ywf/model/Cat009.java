package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat009 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String spare1;

    private String minxfer;

    private String maxxfer;

    private String spare2;

    private String xfrow;

    private String maxprime;

    private String xfrsame;

    private String maxsame;

    private String spare3;

    private String xfrany;

    private String maxprmoth;

    private String xfroth;

    private String maxothoth;

    private String outxfer;

    private String inxfer;

    private String xfrorind;

    private String spare4;

    private String fbsurftag;

    private String surftbl976;

    private String embsurftag;

    private String embtbl976;

    private String spare5;

    private String chg1appl;

    private String chg1numf;

    private BigDecimal chg1amtf;

    private String chg1numa;

    private BigDecimal chg1amta;

    private String chg1cur;

    private Integer chg1dec;

    private BigDecimal chg2amtf;

    private BigDecimal chg2amta;

    private String chg2amta2;

    private Integer chg2dec;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getMinxfer() {
        return minxfer;
    }

    public void setMinxfer(String minxfer) {
        this.minxfer = minxfer == null ? null : minxfer.trim();
    }

    public String getMaxxfer() {
        return maxxfer;
    }

    public void setMaxxfer(String maxxfer) {
        this.maxxfer = maxxfer == null ? null : maxxfer.trim();
    }

    public String getSpare2() {
        return spare2;
    }

    public void setSpare2(String spare2) {
        this.spare2 = spare2 == null ? null : spare2.trim();
    }

    public String getXfrow() {
        return xfrow;
    }

    public void setXfrow(String xfrow) {
        this.xfrow = xfrow == null ? null : xfrow.trim();
    }

    public String getMaxprime() {
        return maxprime;
    }

    public void setMaxprime(String maxprime) {
        this.maxprime = maxprime == null ? null : maxprime.trim();
    }

    public String getXfrsame() {
        return xfrsame;
    }

    public void setXfrsame(String xfrsame) {
        this.xfrsame = xfrsame == null ? null : xfrsame.trim();
    }

    public String getMaxsame() {
        return maxsame;
    }

    public void setMaxsame(String maxsame) {
        this.maxsame = maxsame == null ? null : maxsame.trim();
    }

    public String getSpare3() {
        return spare3;
    }

    public void setSpare3(String spare3) {
        this.spare3 = spare3 == null ? null : spare3.trim();
    }

    public String getXfrany() {
        return xfrany;
    }

    public void setXfrany(String xfrany) {
        this.xfrany = xfrany == null ? null : xfrany.trim();
    }

    public String getMaxprmoth() {
        return maxprmoth;
    }

    public void setMaxprmoth(String maxprmoth) {
        this.maxprmoth = maxprmoth == null ? null : maxprmoth.trim();
    }

    public String getXfroth() {
        return xfroth;
    }

    public void setXfroth(String xfroth) {
        this.xfroth = xfroth == null ? null : xfroth.trim();
    }

    public String getMaxothoth() {
        return maxothoth;
    }

    public void setMaxothoth(String maxothoth) {
        this.maxothoth = maxothoth == null ? null : maxothoth.trim();
    }

    public String getOutxfer() {
        return outxfer;
    }

    public void setOutxfer(String outxfer) {
        this.outxfer = outxfer == null ? null : outxfer.trim();
    }

    public String getInxfer() {
        return inxfer;
    }

    public void setInxfer(String inxfer) {
        this.inxfer = inxfer == null ? null : inxfer.trim();
    }

    public String getXfrorind() {
        return xfrorind;
    }

    public void setXfrorind(String xfrorind) {
        this.xfrorind = xfrorind == null ? null : xfrorind.trim();
    }

    public String getSpare4() {
        return spare4;
    }

    public void setSpare4(String spare4) {
        this.spare4 = spare4 == null ? null : spare4.trim();
    }

    public String getFbsurftag() {
        return fbsurftag;
    }

    public void setFbsurftag(String fbsurftag) {
        this.fbsurftag = fbsurftag == null ? null : fbsurftag.trim();
    }

    public String getSurftbl976() {
        return surftbl976;
    }

    public void setSurftbl976(String surftbl976) {
        this.surftbl976 = surftbl976 == null ? null : surftbl976.trim();
    }

    public String getEmbsurftag() {
        return embsurftag;
    }

    public void setEmbsurftag(String embsurftag) {
        this.embsurftag = embsurftag == null ? null : embsurftag.trim();
    }

    public String getEmbtbl976() {
        return embtbl976;
    }

    public void setEmbtbl976(String embtbl976) {
        this.embtbl976 = embtbl976 == null ? null : embtbl976.trim();
    }

    public String getSpare5() {
        return spare5;
    }

    public void setSpare5(String spare5) {
        this.spare5 = spare5 == null ? null : spare5.trim();
    }

    public String getChg1appl() {
        return chg1appl;
    }

    public void setChg1appl(String chg1appl) {
        this.chg1appl = chg1appl == null ? null : chg1appl.trim();
    }

    public String getChg1numf() {
        return chg1numf;
    }

    public void setChg1numf(String chg1numf) {
        this.chg1numf = chg1numf == null ? null : chg1numf.trim();
    }

    public BigDecimal getChg1amtf() {
        return chg1amtf;
    }

    public void setChg1amtf(BigDecimal chg1amtf) {
        this.chg1amtf = chg1amtf;
    }

    public String getChg1numa() {
        return chg1numa;
    }

    public void setChg1numa(String chg1numa) {
        this.chg1numa = chg1numa == null ? null : chg1numa.trim();
    }

    public BigDecimal getChg1amta() {
        return chg1amta;
    }

    public void setChg1amta(BigDecimal chg1amta) {
        this.chg1amta = chg1amta;
    }

    public String getChg1cur() {
        return chg1cur;
    }

    public void setChg1cur(String chg1cur) {
        this.chg1cur = chg1cur == null ? null : chg1cur.trim();
    }

    public Integer getChg1dec() {
        return chg1dec;
    }

    public void setChg1dec(Integer chg1dec) {
        this.chg1dec = chg1dec;
    }

    public BigDecimal getChg2amtf() {
        return chg2amtf;
    }

    public void setChg2amtf(BigDecimal chg2amtf) {
        this.chg2amtf = chg2amtf;
    }

    public BigDecimal getChg2amta() {
        return chg2amta;
    }

    public void setChg2amta(BigDecimal chg2amta) {
        this.chg2amta = chg2amta;
    }

    public String getChg2amta2() {
        return chg2amta2;
    }

    public void setChg2amta2(String chg2amta2) {
        this.chg2amta2 = chg2amta2 == null ? null : chg2amta2.trim();
    }

    public Integer getChg2dec() {
        return chg2dec;
    }

    public void setChg2dec(Integer chg2dec) {
        this.chg2dec = chg2dec;
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}