package com.ywf.model;

import java.util.Date;

public class Record8Segs {
    private Long id;

    private Long record8Id;

    private Long createId;

    private String pax;

    private String resrv3;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecord8Id() {
        return record8Id;
    }

    public void setRecord8Id(Long record8Id) {
        this.record8Id = record8Id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getPax() {
        return pax;
    }

    public void setPax(String pax) {
        this.pax = pax == null ? null : pax.trim();
    }

    public String getResrv3() {
        return resrv3;
    }

    public void setResrv3(String resrv3) {
        this.resrv3 = resrv3 == null ? null : resrv3.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}