package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat026 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String type;

    private Integer sizemin;

    private Integer sizemax;

    private String fclass;

    private Integer fltno;

    private String fltpct;

    private String fltmax;

    private String val;

    private String appl;

    private String betgeotbl;

    private String andgeotbl;

    private Integer chlno;

    private String chlpct;

    private String chlfcl;

    private String chltype;

    private String namreq;

    private Date namdate;

    private String namtod;

    private String namper;

    private String namunit;

    private String namappl;

    private String itiner;

    private String pnr;

    private String faretbc;

    private String apxno;

    private String apxpct;

    private String apxtod;

    private String apxper;

    private String apxunit;

    private String apxttod;

    private String apxtper;

    private String paxtunit;

    private String paxtimm;

    private String spaxno;

    private String spaxpct;

    private String spaxtod;

    private String spaxper;

    private String spaxunit;

    private String spaxttod;

    private String spaxtper;

    private String spaxtunit;

    private String spaxtimm;

    private Integer gminnos;

    private String gout;

    private String gin;

    private String geither;

    private String gbetgetbl;

    private String gandgetbl;

    private String gtime;

    private String gwaiver;

    private String gperm;

    private String gsame;

    private String gtod;

    private String gperiod;

    private String gunit;

    private String goutin;

    private BigDecimal gamt1;

    private String gcur1;

    private Integer gdec1;

    private BigDecimal gamt2;

    private String gcur2;

    private Integer gdec2;

    private String gpct;

    private String gbetgeotbl;

    private String gandgeotbl;

    private Integer asmminno;

    private String asmgeotbl;

    private String asmrtn;

    private Integer gtmino;

    private Integer gtmaxno;

    private Integer gtcondno;

    private Integer gtpaypass;

    private Integer gtmax;

    private Integer gtage;

    private String gttvl;

    private String gtbetgtbl;

    private String gtandgtbl;

    private String gtdiff;

    private String gtwrit;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public Integer getSizemin() {
        return sizemin;
    }

    public void setSizemin(Integer sizemin) {
        this.sizemin = sizemin;
    }

    public Integer getSizemax() {
        return sizemax;
    }

    public void setSizemax(Integer sizemax) {
        this.sizemax = sizemax;
    }

    public String getFclass() {
        return fclass;
    }

    public void setFclass(String fclass) {
        this.fclass = fclass == null ? null : fclass.trim();
    }

    public Integer getFltno() {
        return fltno;
    }

    public void setFltno(Integer fltno) {
        this.fltno = fltno;
    }

    public String getFltpct() {
        return fltpct;
    }

    public void setFltpct(String fltpct) {
        this.fltpct = fltpct == null ? null : fltpct.trim();
    }

    public String getFltmax() {
        return fltmax;
    }

    public void setFltmax(String fltmax) {
        this.fltmax = fltmax == null ? null : fltmax.trim();
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val == null ? null : val.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getBetgeotbl() {
        return betgeotbl;
    }

    public void setBetgeotbl(String betgeotbl) {
        this.betgeotbl = betgeotbl == null ? null : betgeotbl.trim();
    }

    public String getAndgeotbl() {
        return andgeotbl;
    }

    public void setAndgeotbl(String andgeotbl) {
        this.andgeotbl = andgeotbl == null ? null : andgeotbl.trim();
    }

    public Integer getChlno() {
        return chlno;
    }

    public void setChlno(Integer chlno) {
        this.chlno = chlno;
    }

    public String getChlpct() {
        return chlpct;
    }

    public void setChlpct(String chlpct) {
        this.chlpct = chlpct == null ? null : chlpct.trim();
    }

    public String getChlfcl() {
        return chlfcl;
    }

    public void setChlfcl(String chlfcl) {
        this.chlfcl = chlfcl == null ? null : chlfcl.trim();
    }

    public String getChltype() {
        return chltype;
    }

    public void setChltype(String chltype) {
        this.chltype = chltype == null ? null : chltype.trim();
    }

    public String getNamreq() {
        return namreq;
    }

    public void setNamreq(String namreq) {
        this.namreq = namreq == null ? null : namreq.trim();
    }

    public Date getNamdate() {
        return namdate;
    }

    public void setNamdate(Date namdate) {
        this.namdate = namdate;
    }

    public String getNamtod() {
        return namtod;
    }

    public void setNamtod(String namtod) {
        this.namtod = namtod == null ? null : namtod.trim();
    }

    public String getNamper() {
        return namper;
    }

    public void setNamper(String namper) {
        this.namper = namper == null ? null : namper.trim();
    }

    public String getNamunit() {
        return namunit;
    }

    public void setNamunit(String namunit) {
        this.namunit = namunit == null ? null : namunit.trim();
    }

    public String getNamappl() {
        return namappl;
    }

    public void setNamappl(String namappl) {
        this.namappl = namappl == null ? null : namappl.trim();
    }

    public String getItiner() {
        return itiner;
    }

    public void setItiner(String itiner) {
        this.itiner = itiner == null ? null : itiner.trim();
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr == null ? null : pnr.trim();
    }

    public String getFaretbc() {
        return faretbc;
    }

    public void setFaretbc(String faretbc) {
        this.faretbc = faretbc == null ? null : faretbc.trim();
    }

    public String getApxno() {
        return apxno;
    }

    public void setApxno(String apxno) {
        this.apxno = apxno == null ? null : apxno.trim();
    }

    public String getApxpct() {
        return apxpct;
    }

    public void setApxpct(String apxpct) {
        this.apxpct = apxpct == null ? null : apxpct.trim();
    }

    public String getApxtod() {
        return apxtod;
    }

    public void setApxtod(String apxtod) {
        this.apxtod = apxtod == null ? null : apxtod.trim();
    }

    public String getApxper() {
        return apxper;
    }

    public void setApxper(String apxper) {
        this.apxper = apxper == null ? null : apxper.trim();
    }

    public String getApxunit() {
        return apxunit;
    }

    public void setApxunit(String apxunit) {
        this.apxunit = apxunit == null ? null : apxunit.trim();
    }

    public String getApxttod() {
        return apxttod;
    }

    public void setApxttod(String apxttod) {
        this.apxttod = apxttod == null ? null : apxttod.trim();
    }

    public String getApxtper() {
        return apxtper;
    }

    public void setApxtper(String apxtper) {
        this.apxtper = apxtper == null ? null : apxtper.trim();
    }

    public String getPaxtunit() {
        return paxtunit;
    }

    public void setPaxtunit(String paxtunit) {
        this.paxtunit = paxtunit == null ? null : paxtunit.trim();
    }

    public String getPaxtimm() {
        return paxtimm;
    }

    public void setPaxtimm(String paxtimm) {
        this.paxtimm = paxtimm == null ? null : paxtimm.trim();
    }

    public String getSpaxno() {
        return spaxno;
    }

    public void setSpaxno(String spaxno) {
        this.spaxno = spaxno == null ? null : spaxno.trim();
    }

    public String getSpaxpct() {
        return spaxpct;
    }

    public void setSpaxpct(String spaxpct) {
        this.spaxpct = spaxpct == null ? null : spaxpct.trim();
    }

    public String getSpaxtod() {
        return spaxtod;
    }

    public void setSpaxtod(String spaxtod) {
        this.spaxtod = spaxtod == null ? null : spaxtod.trim();
    }

    public String getSpaxper() {
        return spaxper;
    }

    public void setSpaxper(String spaxper) {
        this.spaxper = spaxper == null ? null : spaxper.trim();
    }

    public String getSpaxunit() {
        return spaxunit;
    }

    public void setSpaxunit(String spaxunit) {
        this.spaxunit = spaxunit == null ? null : spaxunit.trim();
    }

    public String getSpaxttod() {
        return spaxttod;
    }

    public void setSpaxttod(String spaxttod) {
        this.spaxttod = spaxttod == null ? null : spaxttod.trim();
    }

    public String getSpaxtper() {
        return spaxtper;
    }

    public void setSpaxtper(String spaxtper) {
        this.spaxtper = spaxtper == null ? null : spaxtper.trim();
    }

    public String getSpaxtunit() {
        return spaxtunit;
    }

    public void setSpaxtunit(String spaxtunit) {
        this.spaxtunit = spaxtunit == null ? null : spaxtunit.trim();
    }

    public String getSpaxtimm() {
        return spaxtimm;
    }

    public void setSpaxtimm(String spaxtimm) {
        this.spaxtimm = spaxtimm == null ? null : spaxtimm.trim();
    }

    public Integer getGminnos() {
        return gminnos;
    }

    public void setGminnos(Integer gminnos) {
        this.gminnos = gminnos;
    }

    public String getGout() {
        return gout;
    }

    public void setGout(String gout) {
        this.gout = gout == null ? null : gout.trim();
    }

    public String getGin() {
        return gin;
    }

    public void setGin(String gin) {
        this.gin = gin == null ? null : gin.trim();
    }

    public String getGeither() {
        return geither;
    }

    public void setGeither(String geither) {
        this.geither = geither == null ? null : geither.trim();
    }

    public String getGbetgetbl() {
        return gbetgetbl;
    }

    public void setGbetgetbl(String gbetgetbl) {
        this.gbetgetbl = gbetgetbl == null ? null : gbetgetbl.trim();
    }

    public String getGandgetbl() {
        return gandgetbl;
    }

    public void setGandgetbl(String gandgetbl) {
        this.gandgetbl = gandgetbl == null ? null : gandgetbl.trim();
    }

    public String getGtime() {
        return gtime;
    }

    public void setGtime(String gtime) {
        this.gtime = gtime == null ? null : gtime.trim();
    }

    public String getGwaiver() {
        return gwaiver;
    }

    public void setGwaiver(String gwaiver) {
        this.gwaiver = gwaiver == null ? null : gwaiver.trim();
    }

    public String getGperm() {
        return gperm;
    }

    public void setGperm(String gperm) {
        this.gperm = gperm == null ? null : gperm.trim();
    }

    public String getGsame() {
        return gsame;
    }

    public void setGsame(String gsame) {
        this.gsame = gsame == null ? null : gsame.trim();
    }

    public String getGtod() {
        return gtod;
    }

    public void setGtod(String gtod) {
        this.gtod = gtod == null ? null : gtod.trim();
    }

    public String getGperiod() {
        return gperiod;
    }

    public void setGperiod(String gperiod) {
        this.gperiod = gperiod == null ? null : gperiod.trim();
    }

    public String getGunit() {
        return gunit;
    }

    public void setGunit(String gunit) {
        this.gunit = gunit == null ? null : gunit.trim();
    }

    public String getGoutin() {
        return goutin;
    }

    public void setGoutin(String goutin) {
        this.goutin = goutin == null ? null : goutin.trim();
    }

    public BigDecimal getGamt1() {
        return gamt1;
    }

    public void setGamt1(BigDecimal gamt1) {
        this.gamt1 = gamt1;
    }

    public String getGcur1() {
        return gcur1;
    }

    public void setGcur1(String gcur1) {
        this.gcur1 = gcur1 == null ? null : gcur1.trim();
    }

    public Integer getGdec1() {
        return gdec1;
    }

    public void setGdec1(Integer gdec1) {
        this.gdec1 = gdec1;
    }

    public BigDecimal getGamt2() {
        return gamt2;
    }

    public void setGamt2(BigDecimal gamt2) {
        this.gamt2 = gamt2;
    }

    public String getGcur2() {
        return gcur2;
    }

    public void setGcur2(String gcur2) {
        this.gcur2 = gcur2 == null ? null : gcur2.trim();
    }

    public Integer getGdec2() {
        return gdec2;
    }

    public void setGdec2(Integer gdec2) {
        this.gdec2 = gdec2;
    }

    public String getGpct() {
        return gpct;
    }

    public void setGpct(String gpct) {
        this.gpct = gpct == null ? null : gpct.trim();
    }

    public String getGbetgeotbl() {
        return gbetgeotbl;
    }

    public void setGbetgeotbl(String gbetgeotbl) {
        this.gbetgeotbl = gbetgeotbl == null ? null : gbetgeotbl.trim();
    }

    public String getGandgeotbl() {
        return gandgeotbl;
    }

    public void setGandgeotbl(String gandgeotbl) {
        this.gandgeotbl = gandgeotbl == null ? null : gandgeotbl.trim();
    }

    public Integer getAsmminno() {
        return asmminno;
    }

    public void setAsmminno(Integer asmminno) {
        this.asmminno = asmminno;
    }

    public String getAsmgeotbl() {
        return asmgeotbl;
    }

    public void setAsmgeotbl(String asmgeotbl) {
        this.asmgeotbl = asmgeotbl == null ? null : asmgeotbl.trim();
    }

    public String getAsmrtn() {
        return asmrtn;
    }

    public void setAsmrtn(String asmrtn) {
        this.asmrtn = asmrtn == null ? null : asmrtn.trim();
    }

    public Integer getGtmino() {
        return gtmino;
    }

    public void setGtmino(Integer gtmino) {
        this.gtmino = gtmino;
    }

    public Integer getGtmaxno() {
        return gtmaxno;
    }

    public void setGtmaxno(Integer gtmaxno) {
        this.gtmaxno = gtmaxno;
    }

    public Integer getGtcondno() {
        return gtcondno;
    }

    public void setGtcondno(Integer gtcondno) {
        this.gtcondno = gtcondno;
    }

    public Integer getGtpaypass() {
        return gtpaypass;
    }

    public void setGtpaypass(Integer gtpaypass) {
        this.gtpaypass = gtpaypass;
    }

    public Integer getGtmax() {
        return gtmax;
    }

    public void setGtmax(Integer gtmax) {
        this.gtmax = gtmax;
    }

    public Integer getGtage() {
        return gtage;
    }

    public void setGtage(Integer gtage) {
        this.gtage = gtage;
    }

    public String getGttvl() {
        return gttvl;
    }

    public void setGttvl(String gttvl) {
        this.gttvl = gttvl == null ? null : gttvl.trim();
    }

    public String getGtbetgtbl() {
        return gtbetgtbl;
    }

    public void setGtbetgtbl(String gtbetgtbl) {
        this.gtbetgtbl = gtbetgtbl == null ? null : gtbetgtbl.trim();
    }

    public String getGtandgtbl() {
        return gtandgtbl;
    }

    public void setGtandgtbl(String gtandgtbl) {
        this.gtandgtbl = gtandgtbl == null ? null : gtandgtbl.trim();
    }

    public String getGtdiff() {
        return gtdiff;
    }

    public void setGtdiff(String gtdiff) {
        this.gtdiff = gtdiff == null ? null : gtdiff.trim();
    }

    public String getGtwrit() {
        return gtwrit;
    }

    public void setGtwrit(String gtwrit) {
        this.gtwrit = gtwrit == null ? null : gtwrit.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}