package com.ywf.model;

import java.util.Date;

public class FootnotesSegs {
    private Long id;

    private Long footnoteId;

    private Long createId;

    private Integer segorder;

    private String relind;

    private String catno;

    private String tblno;

    private String ioind;

    private String dirind;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFootnoteId() {
        return footnoteId;
    }

    public void setFootnoteId(Long footnoteId) {
        this.footnoteId = footnoteId;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }

    public String getRelind() {
        return relind;
    }

    public void setRelind(String relind) {
        this.relind = relind == null ? null : relind.trim();
    }

    public String getCatno() {
        return catno;
    }

    public void setCatno(String catno) {
        this.catno = catno == null ? null : catno.trim();
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public String getIoind() {
        return ioind;
    }

    public void setIoind(String ioind) {
        this.ioind = ioind == null ? null : ioind.trim();
    }

    public String getDirind() {
        return dirind;
    }

    public void setDirind(String dirind) {
        this.dirind = dirind == null ? null : dirind.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}