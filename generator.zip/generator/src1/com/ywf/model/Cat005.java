package com.ywf.model;

import java.util.Date;

public class Cat005 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String arsftime;

    private String arsfper;

    private String arsfunit;

    private String arsltime;

    private String arslper;

    private String arslunit;

    private String arstsi;

    private String arsperm;

    private String arstktd;

    private String arsstand;

    private String confall;

    private String confgtbl;

    private String confeach;

    private String atktime;

    private String atkper;

    private String atkpunit;

    private String atkopt;

    private Integer atkdept;

    private String atkdunit;

    private String atktsi;

    private String atkboth;

    private Integer atkexc;

    private String atkeunit;

    private Date waivrdte;

    private Date waivtdte;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getArsftime() {
        return arsftime;
    }

    public void setArsftime(String arsftime) {
        this.arsftime = arsftime == null ? null : arsftime.trim();
    }

    public String getArsfper() {
        return arsfper;
    }

    public void setArsfper(String arsfper) {
        this.arsfper = arsfper == null ? null : arsfper.trim();
    }

    public String getArsfunit() {
        return arsfunit;
    }

    public void setArsfunit(String arsfunit) {
        this.arsfunit = arsfunit == null ? null : arsfunit.trim();
    }

    public String getArsltime() {
        return arsltime;
    }

    public void setArsltime(String arsltime) {
        this.arsltime = arsltime == null ? null : arsltime.trim();
    }

    public String getArslper() {
        return arslper;
    }

    public void setArslper(String arslper) {
        this.arslper = arslper == null ? null : arslper.trim();
    }

    public String getArslunit() {
        return arslunit;
    }

    public void setArslunit(String arslunit) {
        this.arslunit = arslunit == null ? null : arslunit.trim();
    }

    public String getArstsi() {
        return arstsi;
    }

    public void setArstsi(String arstsi) {
        this.arstsi = arstsi == null ? null : arstsi.trim();
    }

    public String getArsperm() {
        return arsperm;
    }

    public void setArsperm(String arsperm) {
        this.arsperm = arsperm == null ? null : arsperm.trim();
    }

    public String getArstktd() {
        return arstktd;
    }

    public void setArstktd(String arstktd) {
        this.arstktd = arstktd == null ? null : arstktd.trim();
    }

    public String getArsstand() {
        return arsstand;
    }

    public void setArsstand(String arsstand) {
        this.arsstand = arsstand == null ? null : arsstand.trim();
    }

    public String getConfall() {
        return confall;
    }

    public void setConfall(String confall) {
        this.confall = confall == null ? null : confall.trim();
    }

    public String getConfgtbl() {
        return confgtbl;
    }

    public void setConfgtbl(String confgtbl) {
        this.confgtbl = confgtbl == null ? null : confgtbl.trim();
    }

    public String getConfeach() {
        return confeach;
    }

    public void setConfeach(String confeach) {
        this.confeach = confeach == null ? null : confeach.trim();
    }

    public String getAtktime() {
        return atktime;
    }

    public void setAtktime(String atktime) {
        this.atktime = atktime == null ? null : atktime.trim();
    }

    public String getAtkper() {
        return atkper;
    }

    public void setAtkper(String atkper) {
        this.atkper = atkper == null ? null : atkper.trim();
    }

    public String getAtkpunit() {
        return atkpunit;
    }

    public void setAtkpunit(String atkpunit) {
        this.atkpunit = atkpunit == null ? null : atkpunit.trim();
    }

    public String getAtkopt() {
        return atkopt;
    }

    public void setAtkopt(String atkopt) {
        this.atkopt = atkopt == null ? null : atkopt.trim();
    }

    public Integer getAtkdept() {
        return atkdept;
    }

    public void setAtkdept(Integer atkdept) {
        this.atkdept = atkdept;
    }

    public String getAtkdunit() {
        return atkdunit;
    }

    public void setAtkdunit(String atkdunit) {
        this.atkdunit = atkdunit == null ? null : atkdunit.trim();
    }

    public String getAtktsi() {
        return atktsi;
    }

    public void setAtktsi(String atktsi) {
        this.atktsi = atktsi == null ? null : atktsi.trim();
    }

    public String getAtkboth() {
        return atkboth;
    }

    public void setAtkboth(String atkboth) {
        this.atkboth = atkboth == null ? null : atkboth.trim();
    }

    public Integer getAtkexc() {
        return atkexc;
    }

    public void setAtkexc(Integer atkexc) {
        this.atkexc = atkexc;
    }

    public String getAtkeunit() {
        return atkeunit;
    }

    public void setAtkeunit(String atkeunit) {
        this.atkeunit = atkeunit == null ? null : atkeunit.trim();
    }

    public Date getWaivrdte() {
        return waivrdte;
    }

    public void setWaivrdte(Date waivrdte) {
        this.waivrdte = waivrdte;
    }

    public Date getWaivtdte() {
        return waivtdte;
    }

    public void setWaivtdte(Date waivtdte) {
        this.waivtdte = waivtdte;
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}