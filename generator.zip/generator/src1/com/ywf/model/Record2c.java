package com.ywf.model;

import java.util.Date;

public class Record2c {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String action;

    private String ruletar;

    private String cxr;

    private String ruleno;

    private String cat;

    private String mcn;

    private String seqno;

    private String loc1type;

    private String loc1code;

    private String loc2type;

    private String loc2code;

    private String fcl;

    private String faretype;

    private String seatype;

    private String dowtype;

    private String owrt;

    private String rtgno;

    private String ftnt;

    private String jtcxrtbl;

    private Date effdate;

    private Date disdate;

    private String batchci;

    private String batchno;

    private String notappl;

    private String soj;

    private String sojod;

    private String doj;

    private String dojcxr;

    private String dojtr;

    private String dojfc;

    private String dojruletsc;

    private String dojruleno;

    private String dojruleapp;

    private String ct2;

    private String ct2cxr;

    private String ct2tr;

    private String ct2fc;

    private String ct2ruletsc;

    private String ct2ruleno;

    private String ct2ruleapp;

    private String ctm;

    private String ctmcxr;

    private String ctmtr;

    private String ctmfc;

    private String ctmruletsc;

    private String ctmruleno;

    private String ctmruleapp;

    private String end;

    private String endcxr;

    private String endtr;

    private String endfc;

    private String endruletsc;

    private String endruleno;

    private String endruleapp;

    private String arb;

    private String arbcxr;

    private String arbtr;

    private String arbfc;

    private String arbruletsc;

    private String arbruleno;

    private String arbruleapp;

    private String samepttbl;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }

    public String getRuletar() {
        return ruletar;
    }

    public void setRuletar(String ruletar) {
        this.ruletar = ruletar == null ? null : ruletar.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat == null ? null : cat.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getSeatype() {
        return seatype;
    }

    public void setSeatype(String seatype) {
        this.seatype = seatype == null ? null : seatype.trim();
    }

    public String getDowtype() {
        return dowtype;
    }

    public void setDowtype(String dowtype) {
        this.dowtype = dowtype == null ? null : dowtype.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getRtgno() {
        return rtgno;
    }

    public void setRtgno(String rtgno) {
        this.rtgno = rtgno == null ? null : rtgno.trim();
    }

    public String getFtnt() {
        return ftnt;
    }

    public void setFtnt(String ftnt) {
        this.ftnt = ftnt == null ? null : ftnt.trim();
    }

    public String getJtcxrtbl() {
        return jtcxrtbl;
    }

    public void setJtcxrtbl(String jtcxrtbl) {
        this.jtcxrtbl = jtcxrtbl == null ? null : jtcxrtbl.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getNotappl() {
        return notappl;
    }

    public void setNotappl(String notappl) {
        this.notappl = notappl == null ? null : notappl.trim();
    }

    public String getSoj() {
        return soj;
    }

    public void setSoj(String soj) {
        this.soj = soj == null ? null : soj.trim();
    }

    public String getSojod() {
        return sojod;
    }

    public void setSojod(String sojod) {
        this.sojod = sojod == null ? null : sojod.trim();
    }

    public String getDoj() {
        return doj;
    }

    public void setDoj(String doj) {
        this.doj = doj == null ? null : doj.trim();
    }

    public String getDojcxr() {
        return dojcxr;
    }

    public void setDojcxr(String dojcxr) {
        this.dojcxr = dojcxr == null ? null : dojcxr.trim();
    }

    public String getDojtr() {
        return dojtr;
    }

    public void setDojtr(String dojtr) {
        this.dojtr = dojtr == null ? null : dojtr.trim();
    }

    public String getDojfc() {
        return dojfc;
    }

    public void setDojfc(String dojfc) {
        this.dojfc = dojfc == null ? null : dojfc.trim();
    }

    public String getDojruletsc() {
        return dojruletsc;
    }

    public void setDojruletsc(String dojruletsc) {
        this.dojruletsc = dojruletsc == null ? null : dojruletsc.trim();
    }

    public String getDojruleno() {
        return dojruleno;
    }

    public void setDojruleno(String dojruleno) {
        this.dojruleno = dojruleno == null ? null : dojruleno.trim();
    }

    public String getDojruleapp() {
        return dojruleapp;
    }

    public void setDojruleapp(String dojruleapp) {
        this.dojruleapp = dojruleapp == null ? null : dojruleapp.trim();
    }

    public String getCt2() {
        return ct2;
    }

    public void setCt2(String ct2) {
        this.ct2 = ct2 == null ? null : ct2.trim();
    }

    public String getCt2cxr() {
        return ct2cxr;
    }

    public void setCt2cxr(String ct2cxr) {
        this.ct2cxr = ct2cxr == null ? null : ct2cxr.trim();
    }

    public String getCt2tr() {
        return ct2tr;
    }

    public void setCt2tr(String ct2tr) {
        this.ct2tr = ct2tr == null ? null : ct2tr.trim();
    }

    public String getCt2fc() {
        return ct2fc;
    }

    public void setCt2fc(String ct2fc) {
        this.ct2fc = ct2fc == null ? null : ct2fc.trim();
    }

    public String getCt2ruletsc() {
        return ct2ruletsc;
    }

    public void setCt2ruletsc(String ct2ruletsc) {
        this.ct2ruletsc = ct2ruletsc == null ? null : ct2ruletsc.trim();
    }

    public String getCt2ruleno() {
        return ct2ruleno;
    }

    public void setCt2ruleno(String ct2ruleno) {
        this.ct2ruleno = ct2ruleno == null ? null : ct2ruleno.trim();
    }

    public String getCt2ruleapp() {
        return ct2ruleapp;
    }

    public void setCt2ruleapp(String ct2ruleapp) {
        this.ct2ruleapp = ct2ruleapp == null ? null : ct2ruleapp.trim();
    }

    public String getCtm() {
        return ctm;
    }

    public void setCtm(String ctm) {
        this.ctm = ctm == null ? null : ctm.trim();
    }

    public String getCtmcxr() {
        return ctmcxr;
    }

    public void setCtmcxr(String ctmcxr) {
        this.ctmcxr = ctmcxr == null ? null : ctmcxr.trim();
    }

    public String getCtmtr() {
        return ctmtr;
    }

    public void setCtmtr(String ctmtr) {
        this.ctmtr = ctmtr == null ? null : ctmtr.trim();
    }

    public String getCtmfc() {
        return ctmfc;
    }

    public void setCtmfc(String ctmfc) {
        this.ctmfc = ctmfc == null ? null : ctmfc.trim();
    }

    public String getCtmruletsc() {
        return ctmruletsc;
    }

    public void setCtmruletsc(String ctmruletsc) {
        this.ctmruletsc = ctmruletsc == null ? null : ctmruletsc.trim();
    }

    public String getCtmruleno() {
        return ctmruleno;
    }

    public void setCtmruleno(String ctmruleno) {
        this.ctmruleno = ctmruleno == null ? null : ctmruleno.trim();
    }

    public String getCtmruleapp() {
        return ctmruleapp;
    }

    public void setCtmruleapp(String ctmruleapp) {
        this.ctmruleapp = ctmruleapp == null ? null : ctmruleapp.trim();
    }

    public String getEnd() {
        return end;
    }

    public void setEnd(String end) {
        this.end = end == null ? null : end.trim();
    }

    public String getEndcxr() {
        return endcxr;
    }

    public void setEndcxr(String endcxr) {
        this.endcxr = endcxr == null ? null : endcxr.trim();
    }

    public String getEndtr() {
        return endtr;
    }

    public void setEndtr(String endtr) {
        this.endtr = endtr == null ? null : endtr.trim();
    }

    public String getEndfc() {
        return endfc;
    }

    public void setEndfc(String endfc) {
        this.endfc = endfc == null ? null : endfc.trim();
    }

    public String getEndruletsc() {
        return endruletsc;
    }

    public void setEndruletsc(String endruletsc) {
        this.endruletsc = endruletsc == null ? null : endruletsc.trim();
    }

    public String getEndruleno() {
        return endruleno;
    }

    public void setEndruleno(String endruleno) {
        this.endruleno = endruleno == null ? null : endruleno.trim();
    }

    public String getEndruleapp() {
        return endruleapp;
    }

    public void setEndruleapp(String endruleapp) {
        this.endruleapp = endruleapp == null ? null : endruleapp.trim();
    }

    public String getArb() {
        return arb;
    }

    public void setArb(String arb) {
        this.arb = arb == null ? null : arb.trim();
    }

    public String getArbcxr() {
        return arbcxr;
    }

    public void setArbcxr(String arbcxr) {
        this.arbcxr = arbcxr == null ? null : arbcxr.trim();
    }

    public String getArbtr() {
        return arbtr;
    }

    public void setArbtr(String arbtr) {
        this.arbtr = arbtr == null ? null : arbtr.trim();
    }

    public String getArbfc() {
        return arbfc;
    }

    public void setArbfc(String arbfc) {
        this.arbfc = arbfc == null ? null : arbfc.trim();
    }

    public String getArbruletsc() {
        return arbruletsc;
    }

    public void setArbruletsc(String arbruletsc) {
        this.arbruletsc = arbruletsc == null ? null : arbruletsc.trim();
    }

    public String getArbruleno() {
        return arbruleno;
    }

    public void setArbruleno(String arbruleno) {
        this.arbruleno = arbruleno == null ? null : arbruleno.trim();
    }

    public String getArbruleapp() {
        return arbruleapp;
    }

    public void setArbruleapp(String arbruleapp) {
        this.arbruleapp = arbruleapp == null ? null : arbruleapp.trim();
    }

    public String getSamepttbl() {
        return samepttbl;
    }

    public void setSamepttbl(String samepttbl) {
        this.samepttbl = samepttbl == null ? null : samepttbl.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}