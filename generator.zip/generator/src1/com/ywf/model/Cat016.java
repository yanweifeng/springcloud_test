package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat016 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String aplvol;

    private String aplinv;

    private String aplcanx;

    private String tktnrf;

    private String condcanx;

    private String condfail;

    private String condchgr;

    private String condrep;

    private String condchgn;

    private String condtkt;

    private String condptr;

    private String geotblno;

    private String chgappl;

    private String chgpor;

    private BigDecimal chgamt;

    private String chgcur;

    private Integer chgdec;

    private BigDecimal chgamt2;

    private String chgcur2;

    private Integer chgdec2;

    private String percent;

    private String hilo;

    private String waivdthp;

    private String waivillp;

    private String waivdthf;

    private String waivillf;

    private String waivskdc;

    private String waivupgd;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAplvol() {
        return aplvol;
    }

    public void setAplvol(String aplvol) {
        this.aplvol = aplvol == null ? null : aplvol.trim();
    }

    public String getAplinv() {
        return aplinv;
    }

    public void setAplinv(String aplinv) {
        this.aplinv = aplinv == null ? null : aplinv.trim();
    }

    public String getAplcanx() {
        return aplcanx;
    }

    public void setAplcanx(String aplcanx) {
        this.aplcanx = aplcanx == null ? null : aplcanx.trim();
    }

    public String getTktnrf() {
        return tktnrf;
    }

    public void setTktnrf(String tktnrf) {
        this.tktnrf = tktnrf == null ? null : tktnrf.trim();
    }

    public String getCondcanx() {
        return condcanx;
    }

    public void setCondcanx(String condcanx) {
        this.condcanx = condcanx == null ? null : condcanx.trim();
    }

    public String getCondfail() {
        return condfail;
    }

    public void setCondfail(String condfail) {
        this.condfail = condfail == null ? null : condfail.trim();
    }

    public String getCondchgr() {
        return condchgr;
    }

    public void setCondchgr(String condchgr) {
        this.condchgr = condchgr == null ? null : condchgr.trim();
    }

    public String getCondrep() {
        return condrep;
    }

    public void setCondrep(String condrep) {
        this.condrep = condrep == null ? null : condrep.trim();
    }

    public String getCondchgn() {
        return condchgn;
    }

    public void setCondchgn(String condchgn) {
        this.condchgn = condchgn == null ? null : condchgn.trim();
    }

    public String getCondtkt() {
        return condtkt;
    }

    public void setCondtkt(String condtkt) {
        this.condtkt = condtkt == null ? null : condtkt.trim();
    }

    public String getCondptr() {
        return condptr;
    }

    public void setCondptr(String condptr) {
        this.condptr = condptr == null ? null : condptr.trim();
    }

    public String getGeotblno() {
        return geotblno;
    }

    public void setGeotblno(String geotblno) {
        this.geotblno = geotblno == null ? null : geotblno.trim();
    }

    public String getChgappl() {
        return chgappl;
    }

    public void setChgappl(String chgappl) {
        this.chgappl = chgappl == null ? null : chgappl.trim();
    }

    public String getChgpor() {
        return chgpor;
    }

    public void setChgpor(String chgpor) {
        this.chgpor = chgpor == null ? null : chgpor.trim();
    }

    public BigDecimal getChgamt() {
        return chgamt;
    }

    public void setChgamt(BigDecimal chgamt) {
        this.chgamt = chgamt;
    }

    public String getChgcur() {
        return chgcur;
    }

    public void setChgcur(String chgcur) {
        this.chgcur = chgcur == null ? null : chgcur.trim();
    }

    public Integer getChgdec() {
        return chgdec;
    }

    public void setChgdec(Integer chgdec) {
        this.chgdec = chgdec;
    }

    public BigDecimal getChgamt2() {
        return chgamt2;
    }

    public void setChgamt2(BigDecimal chgamt2) {
        this.chgamt2 = chgamt2;
    }

    public String getChgcur2() {
        return chgcur2;
    }

    public void setChgcur2(String chgcur2) {
        this.chgcur2 = chgcur2 == null ? null : chgcur2.trim();
    }

    public Integer getChgdec2() {
        return chgdec2;
    }

    public void setChgdec2(Integer chgdec2) {
        this.chgdec2 = chgdec2;
    }

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent == null ? null : percent.trim();
    }

    public String getHilo() {
        return hilo;
    }

    public void setHilo(String hilo) {
        this.hilo = hilo == null ? null : hilo.trim();
    }

    public String getWaivdthp() {
        return waivdthp;
    }

    public void setWaivdthp(String waivdthp) {
        this.waivdthp = waivdthp == null ? null : waivdthp.trim();
    }

    public String getWaivillp() {
        return waivillp;
    }

    public void setWaivillp(String waivillp) {
        this.waivillp = waivillp == null ? null : waivillp.trim();
    }

    public String getWaivdthf() {
        return waivdthf;
    }

    public void setWaivdthf(String waivdthf) {
        this.waivdthf = waivdthf == null ? null : waivdthf.trim();
    }

    public String getWaivillf() {
        return waivillf;
    }

    public void setWaivillf(String waivillf) {
        this.waivillf = waivillf == null ? null : waivillf.trim();
    }

    public String getWaivskdc() {
        return waivskdc;
    }

    public void setWaivskdc(String waivskdc) {
        this.waivskdc = waivskdc == null ? null : waivskdc.trim();
    }

    public String getWaivupgd() {
        return waivupgd;
    }

    public void setWaivupgd(String waivupgd) {
        this.waivupgd = waivupgd == null ? null : waivupgd.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}