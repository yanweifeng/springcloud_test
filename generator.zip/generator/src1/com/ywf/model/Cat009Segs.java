package com.ywf.model;

import java.util.Date;

public class Cat009Segs {
    private Long id;

    private String tblno;

    private Long createId;

    private String appl;

    private String xfernum;

    private String spare1;

    private String prmPrm;

    private String smeSme;

    private String prmOth;

    private String othOth;

    private String type;

    private String cxrappl;

    private String incxr;

    private String incxrtbl990;

    private String outcxr;

    private String outcxrtbl990;

    private String tsi;

    private String loctype;

    private String loc1code;

    private String loc2code;

    private String table978;

    private String between;

    private String gtwy;

    private String restr;

    private String ioind;

    private String chgind;

    private Date createtime;

    private Date updatetime;

    private Integer segorder;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getXfernum() {
        return xfernum;
    }

    public void setXfernum(String xfernum) {
        this.xfernum = xfernum == null ? null : xfernum.trim();
    }

    public String getSpare1() {
        return spare1;
    }

    public void setSpare1(String spare1) {
        this.spare1 = spare1 == null ? null : spare1.trim();
    }

    public String getPrmPrm() {
        return prmPrm;
    }

    public void setPrmPrm(String prmPrm) {
        this.prmPrm = prmPrm == null ? null : prmPrm.trim();
    }

    public String getSmeSme() {
        return smeSme;
    }

    public void setSmeSme(String smeSme) {
        this.smeSme = smeSme == null ? null : smeSme.trim();
    }

    public String getPrmOth() {
        return prmOth;
    }

    public void setPrmOth(String prmOth) {
        this.prmOth = prmOth == null ? null : prmOth.trim();
    }

    public String getOthOth() {
        return othOth;
    }

    public void setOthOth(String othOth) {
        this.othOth = othOth == null ? null : othOth.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getCxrappl() {
        return cxrappl;
    }

    public void setCxrappl(String cxrappl) {
        this.cxrappl = cxrappl == null ? null : cxrappl.trim();
    }

    public String getIncxr() {
        return incxr;
    }

    public void setIncxr(String incxr) {
        this.incxr = incxr == null ? null : incxr.trim();
    }

    public String getIncxrtbl990() {
        return incxrtbl990;
    }

    public void setIncxrtbl990(String incxrtbl990) {
        this.incxrtbl990 = incxrtbl990 == null ? null : incxrtbl990.trim();
    }

    public String getOutcxr() {
        return outcxr;
    }

    public void setOutcxr(String outcxr) {
        this.outcxr = outcxr == null ? null : outcxr.trim();
    }

    public String getOutcxrtbl990() {
        return outcxrtbl990;
    }

    public void setOutcxrtbl990(String outcxrtbl990) {
        this.outcxrtbl990 = outcxrtbl990 == null ? null : outcxrtbl990.trim();
    }

    public String getTsi() {
        return tsi;
    }

    public void setTsi(String tsi) {
        this.tsi = tsi == null ? null : tsi.trim();
    }

    public String getLoctype() {
        return loctype;
    }

    public void setLoctype(String loctype) {
        this.loctype = loctype == null ? null : loctype.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getTable978() {
        return table978;
    }

    public void setTable978(String table978) {
        this.table978 = table978 == null ? null : table978.trim();
    }

    public String getBetween() {
        return between;
    }

    public void setBetween(String between) {
        this.between = between == null ? null : between.trim();
    }

    public String getGtwy() {
        return gtwy;
    }

    public void setGtwy(String gtwy) {
        this.gtwy = gtwy == null ? null : gtwy.trim();
    }

    public String getRestr() {
        return restr;
    }

    public void setRestr(String restr) {
        this.restr = restr == null ? null : restr.trim();
    }

    public String getIoind() {
        return ioind;
    }

    public void setIoind(String ioind) {
        this.ioind = ioind == null ? null : ioind.trim();
    }

    public String getChgind() {
        return chgind;
    }

    public void setChgind(String chgind) {
        this.chgind = chgind == null ? null : chgind.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }
}