package com.ywf.model;

import java.util.Date;

public class Cat023 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String addonconstr;

    private String prorate;

    private String diffcalc;

    private String filler1;

    private String extfares;

    private String filler2;

    private String reserved;

    private String filler3;

    private String filler4;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAddonconstr() {
        return addonconstr;
    }

    public void setAddonconstr(String addonconstr) {
        this.addonconstr = addonconstr == null ? null : addonconstr.trim();
    }

    public String getProrate() {
        return prorate;
    }

    public void setProrate(String prorate) {
        this.prorate = prorate == null ? null : prorate.trim();
    }

    public String getDiffcalc() {
        return diffcalc;
    }

    public void setDiffcalc(String diffcalc) {
        this.diffcalc = diffcalc == null ? null : diffcalc.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getExtfares() {
        return extfares;
    }

    public void setExtfares(String extfares) {
        this.extfares = extfares == null ? null : extfares.trim();
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public String getFiller3() {
        return filler3;
    }

    public void setFiller3(String filler3) {
        this.filler3 = filler3 == null ? null : filler3.trim();
    }

    public String getFiller4() {
        return filler4;
    }

    public void setFiller4(String filler4) {
        this.filler4 = filler4 == null ? null : filler4.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}