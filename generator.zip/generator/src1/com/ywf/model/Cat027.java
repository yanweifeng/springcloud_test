package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat027 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String type;

    private String tourno;

    private String pkcxr;

    private Integer pknites;

    private String pkstay;

    private String pkminapl1;

    private BigDecimal pkminamt1;

    private String pkminapp1;

    private BigDecimal pkaddamt1;

    private String pkaddcur1;

    private Integer pkadddec1;

    private String pkminapl2;

    private BigDecimal pkminamt2;

    private String pkminapp2;

    private BigDecimal pkaddamt2;

    private String pkaddcur2;

    private Integer pkadddec2;

    private String pkpct;

    private BigDecimal prmintur1;

    private String prmincur1;

    private Integer prmindec1;

    private BigDecimal prmintur2;

    private String prmincur2;

    private Integer prmindec2;

    private String prepay;

    private String pyappl;

    private String pypsgrtyp;

    private Integer pymin;

    private Integer pymax;

    private String pypct;

    private String pywvr;

    private String pynonref;

    private BigDecimal rf1amt1;

    private String rf1cur1;

    private Integer rf1dec1;

    private BigDecimal rf1amt2;

    private String rf1cur2;

    private Integer rf1dec2;

    private String rf1pct;

    private String rf1appl;

    private Integer rf1days;

    private String rf1geotbl;

    private BigDecimal rf2amt1;

    private String rf2cur1;

    private Integer rf2dec1;

    private BigDecimal rf2amt2;

    private String rf2cur2;

    private Integer rf2dec2;

    private String rf2pct;

    private String rf2appl;

    private Integer rf2days;

    private String rf2geotbl;

    private String rfpctpsgr;

    private String rftktd;

    private String rfmingrp;

    private String rftravel;

    private String waivapp;

    private String waiv1;

    private String waiv2;

    private String waiv3;

    private String waiv4;

    private String waiv5;

    private String waiv6;

    private String waiv7;

    private String waiv8;

    private String waiv9;

    private String waiv10;

    private String waiv11;

    private String waiv12;

    private String waiv13;

    private String waiv14;

    private String waivres;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getTourno() {
        return tourno;
    }

    public void setTourno(String tourno) {
        this.tourno = tourno == null ? null : tourno.trim();
    }

    public String getPkcxr() {
        return pkcxr;
    }

    public void setPkcxr(String pkcxr) {
        this.pkcxr = pkcxr == null ? null : pkcxr.trim();
    }

    public Integer getPknites() {
        return pknites;
    }

    public void setPknites(Integer pknites) {
        this.pknites = pknites;
    }

    public String getPkstay() {
        return pkstay;
    }

    public void setPkstay(String pkstay) {
        this.pkstay = pkstay == null ? null : pkstay.trim();
    }

    public String getPkminapl1() {
        return pkminapl1;
    }

    public void setPkminapl1(String pkminapl1) {
        this.pkminapl1 = pkminapl1 == null ? null : pkminapl1.trim();
    }

    public BigDecimal getPkminamt1() {
        return pkminamt1;
    }

    public void setPkminamt1(BigDecimal pkminamt1) {
        this.pkminamt1 = pkminamt1;
    }

    public String getPkminapp1() {
        return pkminapp1;
    }

    public void setPkminapp1(String pkminapp1) {
        this.pkminapp1 = pkminapp1 == null ? null : pkminapp1.trim();
    }

    public BigDecimal getPkaddamt1() {
        return pkaddamt1;
    }

    public void setPkaddamt1(BigDecimal pkaddamt1) {
        this.pkaddamt1 = pkaddamt1;
    }

    public String getPkaddcur1() {
        return pkaddcur1;
    }

    public void setPkaddcur1(String pkaddcur1) {
        this.pkaddcur1 = pkaddcur1 == null ? null : pkaddcur1.trim();
    }

    public Integer getPkadddec1() {
        return pkadddec1;
    }

    public void setPkadddec1(Integer pkadddec1) {
        this.pkadddec1 = pkadddec1;
    }

    public String getPkminapl2() {
        return pkminapl2;
    }

    public void setPkminapl2(String pkminapl2) {
        this.pkminapl2 = pkminapl2 == null ? null : pkminapl2.trim();
    }

    public BigDecimal getPkminamt2() {
        return pkminamt2;
    }

    public void setPkminamt2(BigDecimal pkminamt2) {
        this.pkminamt2 = pkminamt2;
    }

    public String getPkminapp2() {
        return pkminapp2;
    }

    public void setPkminapp2(String pkminapp2) {
        this.pkminapp2 = pkminapp2 == null ? null : pkminapp2.trim();
    }

    public BigDecimal getPkaddamt2() {
        return pkaddamt2;
    }

    public void setPkaddamt2(BigDecimal pkaddamt2) {
        this.pkaddamt2 = pkaddamt2;
    }

    public String getPkaddcur2() {
        return pkaddcur2;
    }

    public void setPkaddcur2(String pkaddcur2) {
        this.pkaddcur2 = pkaddcur2 == null ? null : pkaddcur2.trim();
    }

    public Integer getPkadddec2() {
        return pkadddec2;
    }

    public void setPkadddec2(Integer pkadddec2) {
        this.pkadddec2 = pkadddec2;
    }

    public String getPkpct() {
        return pkpct;
    }

    public void setPkpct(String pkpct) {
        this.pkpct = pkpct == null ? null : pkpct.trim();
    }

    public BigDecimal getPrmintur1() {
        return prmintur1;
    }

    public void setPrmintur1(BigDecimal prmintur1) {
        this.prmintur1 = prmintur1;
    }

    public String getPrmincur1() {
        return prmincur1;
    }

    public void setPrmincur1(String prmincur1) {
        this.prmincur1 = prmincur1 == null ? null : prmincur1.trim();
    }

    public Integer getPrmindec1() {
        return prmindec1;
    }

    public void setPrmindec1(Integer prmindec1) {
        this.prmindec1 = prmindec1;
    }

    public BigDecimal getPrmintur2() {
        return prmintur2;
    }

    public void setPrmintur2(BigDecimal prmintur2) {
        this.prmintur2 = prmintur2;
    }

    public String getPrmincur2() {
        return prmincur2;
    }

    public void setPrmincur2(String prmincur2) {
        this.prmincur2 = prmincur2 == null ? null : prmincur2.trim();
    }

    public Integer getPrmindec2() {
        return prmindec2;
    }

    public void setPrmindec2(Integer prmindec2) {
        this.prmindec2 = prmindec2;
    }

    public String getPrepay() {
        return prepay;
    }

    public void setPrepay(String prepay) {
        this.prepay = prepay == null ? null : prepay.trim();
    }

    public String getPyappl() {
        return pyappl;
    }

    public void setPyappl(String pyappl) {
        this.pyappl = pyappl == null ? null : pyappl.trim();
    }

    public String getPypsgrtyp() {
        return pypsgrtyp;
    }

    public void setPypsgrtyp(String pypsgrtyp) {
        this.pypsgrtyp = pypsgrtyp == null ? null : pypsgrtyp.trim();
    }

    public Integer getPymin() {
        return pymin;
    }

    public void setPymin(Integer pymin) {
        this.pymin = pymin;
    }

    public Integer getPymax() {
        return pymax;
    }

    public void setPymax(Integer pymax) {
        this.pymax = pymax;
    }

    public String getPypct() {
        return pypct;
    }

    public void setPypct(String pypct) {
        this.pypct = pypct == null ? null : pypct.trim();
    }

    public String getPywvr() {
        return pywvr;
    }

    public void setPywvr(String pywvr) {
        this.pywvr = pywvr == null ? null : pywvr.trim();
    }

    public String getPynonref() {
        return pynonref;
    }

    public void setPynonref(String pynonref) {
        this.pynonref = pynonref == null ? null : pynonref.trim();
    }

    public BigDecimal getRf1amt1() {
        return rf1amt1;
    }

    public void setRf1amt1(BigDecimal rf1amt1) {
        this.rf1amt1 = rf1amt1;
    }

    public String getRf1cur1() {
        return rf1cur1;
    }

    public void setRf1cur1(String rf1cur1) {
        this.rf1cur1 = rf1cur1 == null ? null : rf1cur1.trim();
    }

    public Integer getRf1dec1() {
        return rf1dec1;
    }

    public void setRf1dec1(Integer rf1dec1) {
        this.rf1dec1 = rf1dec1;
    }

    public BigDecimal getRf1amt2() {
        return rf1amt2;
    }

    public void setRf1amt2(BigDecimal rf1amt2) {
        this.rf1amt2 = rf1amt2;
    }

    public String getRf1cur2() {
        return rf1cur2;
    }

    public void setRf1cur2(String rf1cur2) {
        this.rf1cur2 = rf1cur2 == null ? null : rf1cur2.trim();
    }

    public Integer getRf1dec2() {
        return rf1dec2;
    }

    public void setRf1dec2(Integer rf1dec2) {
        this.rf1dec2 = rf1dec2;
    }

    public String getRf1pct() {
        return rf1pct;
    }

    public void setRf1pct(String rf1pct) {
        this.rf1pct = rf1pct == null ? null : rf1pct.trim();
    }

    public String getRf1appl() {
        return rf1appl;
    }

    public void setRf1appl(String rf1appl) {
        this.rf1appl = rf1appl == null ? null : rf1appl.trim();
    }

    public Integer getRf1days() {
        return rf1days;
    }

    public void setRf1days(Integer rf1days) {
        this.rf1days = rf1days;
    }

    public String getRf1geotbl() {
        return rf1geotbl;
    }

    public void setRf1geotbl(String rf1geotbl) {
        this.rf1geotbl = rf1geotbl == null ? null : rf1geotbl.trim();
    }

    public BigDecimal getRf2amt1() {
        return rf2amt1;
    }

    public void setRf2amt1(BigDecimal rf2amt1) {
        this.rf2amt1 = rf2amt1;
    }

    public String getRf2cur1() {
        return rf2cur1;
    }

    public void setRf2cur1(String rf2cur1) {
        this.rf2cur1 = rf2cur1 == null ? null : rf2cur1.trim();
    }

    public Integer getRf2dec1() {
        return rf2dec1;
    }

    public void setRf2dec1(Integer rf2dec1) {
        this.rf2dec1 = rf2dec1;
    }

    public BigDecimal getRf2amt2() {
        return rf2amt2;
    }

    public void setRf2amt2(BigDecimal rf2amt2) {
        this.rf2amt2 = rf2amt2;
    }

    public String getRf2cur2() {
        return rf2cur2;
    }

    public void setRf2cur2(String rf2cur2) {
        this.rf2cur2 = rf2cur2 == null ? null : rf2cur2.trim();
    }

    public Integer getRf2dec2() {
        return rf2dec2;
    }

    public void setRf2dec2(Integer rf2dec2) {
        this.rf2dec2 = rf2dec2;
    }

    public String getRf2pct() {
        return rf2pct;
    }

    public void setRf2pct(String rf2pct) {
        this.rf2pct = rf2pct == null ? null : rf2pct.trim();
    }

    public String getRf2appl() {
        return rf2appl;
    }

    public void setRf2appl(String rf2appl) {
        this.rf2appl = rf2appl == null ? null : rf2appl.trim();
    }

    public Integer getRf2days() {
        return rf2days;
    }

    public void setRf2days(Integer rf2days) {
        this.rf2days = rf2days;
    }

    public String getRf2geotbl() {
        return rf2geotbl;
    }

    public void setRf2geotbl(String rf2geotbl) {
        this.rf2geotbl = rf2geotbl == null ? null : rf2geotbl.trim();
    }

    public String getRfpctpsgr() {
        return rfpctpsgr;
    }

    public void setRfpctpsgr(String rfpctpsgr) {
        this.rfpctpsgr = rfpctpsgr == null ? null : rfpctpsgr.trim();
    }

    public String getRftktd() {
        return rftktd;
    }

    public void setRftktd(String rftktd) {
        this.rftktd = rftktd == null ? null : rftktd.trim();
    }

    public String getRfmingrp() {
        return rfmingrp;
    }

    public void setRfmingrp(String rfmingrp) {
        this.rfmingrp = rfmingrp == null ? null : rfmingrp.trim();
    }

    public String getRftravel() {
        return rftravel;
    }

    public void setRftravel(String rftravel) {
        this.rftravel = rftravel == null ? null : rftravel.trim();
    }

    public String getWaivapp() {
        return waivapp;
    }

    public void setWaivapp(String waivapp) {
        this.waivapp = waivapp == null ? null : waivapp.trim();
    }

    public String getWaiv1() {
        return waiv1;
    }

    public void setWaiv1(String waiv1) {
        this.waiv1 = waiv1 == null ? null : waiv1.trim();
    }

    public String getWaiv2() {
        return waiv2;
    }

    public void setWaiv2(String waiv2) {
        this.waiv2 = waiv2 == null ? null : waiv2.trim();
    }

    public String getWaiv3() {
        return waiv3;
    }

    public void setWaiv3(String waiv3) {
        this.waiv3 = waiv3 == null ? null : waiv3.trim();
    }

    public String getWaiv4() {
        return waiv4;
    }

    public void setWaiv4(String waiv4) {
        this.waiv4 = waiv4 == null ? null : waiv4.trim();
    }

    public String getWaiv5() {
        return waiv5;
    }

    public void setWaiv5(String waiv5) {
        this.waiv5 = waiv5 == null ? null : waiv5.trim();
    }

    public String getWaiv6() {
        return waiv6;
    }

    public void setWaiv6(String waiv6) {
        this.waiv6 = waiv6 == null ? null : waiv6.trim();
    }

    public String getWaiv7() {
        return waiv7;
    }

    public void setWaiv7(String waiv7) {
        this.waiv7 = waiv7 == null ? null : waiv7.trim();
    }

    public String getWaiv8() {
        return waiv8;
    }

    public void setWaiv8(String waiv8) {
        this.waiv8 = waiv8 == null ? null : waiv8.trim();
    }

    public String getWaiv9() {
        return waiv9;
    }

    public void setWaiv9(String waiv9) {
        this.waiv9 = waiv9 == null ? null : waiv9.trim();
    }

    public String getWaiv10() {
        return waiv10;
    }

    public void setWaiv10(String waiv10) {
        this.waiv10 = waiv10 == null ? null : waiv10.trim();
    }

    public String getWaiv11() {
        return waiv11;
    }

    public void setWaiv11(String waiv11) {
        this.waiv11 = waiv11 == null ? null : waiv11.trim();
    }

    public String getWaiv12() {
        return waiv12;
    }

    public void setWaiv12(String waiv12) {
        this.waiv12 = waiv12 == null ? null : waiv12.trim();
    }

    public String getWaiv13() {
        return waiv13;
    }

    public void setWaiv13(String waiv13) {
        this.waiv13 = waiv13 == null ? null : waiv13.trim();
    }

    public String getWaiv14() {
        return waiv14;
    }

    public void setWaiv14(String waiv14) {
        this.waiv14 = waiv14 == null ? null : waiv14.trim();
    }

    public String getWaivres() {
        return waivres;
    }

    public void setWaivres(String waivres) {
        this.waivres = waivres == null ? null : waivres.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}