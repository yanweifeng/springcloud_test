package com.ywf.model;

import java.util.Date;

public class Cat013 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String sectall;

    private String sectout;

    private String sectone;

    private String cpmt;

    private String rule;

    private String reserved;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String appl;

    private String psgrtype;

    private String psgrid;

    private Integer minage;

    private Integer maxage;

    private Integer minacc;

    private Integer maxacc;

    private String fbind;

    private Date createtime;

    private Date updatetime;

    private Integer segcnt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getSectall() {
        return sectall;
    }

    public void setSectall(String sectall) {
        this.sectall = sectall == null ? null : sectall.trim();
    }

    public String getSectout() {
        return sectout;
    }

    public void setSectout(String sectout) {
        this.sectout = sectout == null ? null : sectout.trim();
    }

    public String getSectone() {
        return sectone;
    }

    public void setSectone(String sectone) {
        this.sectone = sectone == null ? null : sectone.trim();
    }

    public String getCpmt() {
        return cpmt;
    }

    public void setCpmt(String cpmt) {
        this.cpmt = cpmt == null ? null : cpmt.trim();
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule == null ? null : rule.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getPsgrtype() {
        return psgrtype;
    }

    public void setPsgrtype(String psgrtype) {
        this.psgrtype = psgrtype == null ? null : psgrtype.trim();
    }

    public String getPsgrid() {
        return psgrid;
    }

    public void setPsgrid(String psgrid) {
        this.psgrid = psgrid == null ? null : psgrid.trim();
    }

    public Integer getMinage() {
        return minage;
    }

    public void setMinage(Integer minage) {
        this.minage = minage;
    }

    public Integer getMaxage() {
        return maxage;
    }

    public void setMaxage(Integer maxage) {
        this.maxage = maxage;
    }

    public Integer getMinacc() {
        return minacc;
    }

    public void setMinacc(Integer minacc) {
        this.minacc = minacc;
    }

    public Integer getMaxacc() {
        return maxacc;
    }

    public void setMaxacc(Integer maxacc) {
        this.maxacc = maxacc;
    }

    public String getFbind() {
        return fbind;
    }

    public void setFbind(String fbind) {
        this.fbind = fbind == null ? null : fbind.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }
}