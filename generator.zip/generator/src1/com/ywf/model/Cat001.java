package com.ywf.model;

import java.util.Date;

public class Cat001 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String psgrtype;

    private String idtag;

    private Integer minage;

    private Integer maxage;

    private String psgrfrst;

    private String psgrlast;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String applstat;

    private String psgrstat;

    private String geotype;

    private String geoloc;

    private String account;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getPsgrtype() {
        return psgrtype;
    }

    public void setPsgrtype(String psgrtype) {
        this.psgrtype = psgrtype == null ? null : psgrtype.trim();
    }

    public String getIdtag() {
        return idtag;
    }

    public void setIdtag(String idtag) {
        this.idtag = idtag == null ? null : idtag.trim();
    }

    public Integer getMinage() {
        return minage;
    }

    public void setMinage(Integer minage) {
        this.minage = minage;
    }

    public Integer getMaxage() {
        return maxage;
    }

    public void setMaxage(Integer maxage) {
        this.maxage = maxage;
    }

    public String getPsgrfrst() {
        return psgrfrst;
    }

    public void setPsgrfrst(String psgrfrst) {
        this.psgrfrst = psgrfrst == null ? null : psgrfrst.trim();
    }

    public String getPsgrlast() {
        return psgrlast;
    }

    public void setPsgrlast(String psgrlast) {
        this.psgrlast = psgrlast == null ? null : psgrlast.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getApplstat() {
        return applstat;
    }

    public void setApplstat(String applstat) {
        this.applstat = applstat == null ? null : applstat.trim();
    }

    public String getPsgrstat() {
        return psgrstat;
    }

    public void setPsgrstat(String psgrstat) {
        this.psgrstat = psgrstat == null ? null : psgrstat.trim();
    }

    public String getGeotype() {
        return geotype;
    }

    public void setGeotype(String geotype) {
        this.geotype = geotype == null ? null : geotype.trim();
    }

    public String getGeoloc() {
        return geoloc;
    }

    public void setGeoloc(String geoloc) {
        this.geoloc = geoloc == null ? null : geoloc.trim();
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}