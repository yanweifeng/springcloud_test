package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat012 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String strtdate;

    private String stopdate;

    private String strttime;

    private String stoptime;

    private String timeappl;

    private String dayweek;

    private String surtype;

    private String eqpt;

    private String surappl;

    private String sectPrt;

    private String geotblno;

    private String btwgeotb;

    private String andgeotb;

    private String chgappl;

    private BigDecimal chgamt;

    private String chgcur;

    private Integer chgdec;

    private BigDecimal chgamt2;

    private String chgcur2;

    private Integer chgdec2;

    private String percent;

    private String base;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String rbd;

    private String tbl986;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getStrtdate() {
        return strtdate;
    }

    public void setStrtdate(String strtdate) {
        this.strtdate = strtdate == null ? null : strtdate.trim();
    }

    public String getStopdate() {
        return stopdate;
    }

    public void setStopdate(String stopdate) {
        this.stopdate = stopdate == null ? null : stopdate.trim();
    }

    public String getStrttime() {
        return strttime;
    }

    public void setStrttime(String strttime) {
        this.strttime = strttime == null ? null : strttime.trim();
    }

    public String getStoptime() {
        return stoptime;
    }

    public void setStoptime(String stoptime) {
        this.stoptime = stoptime == null ? null : stoptime.trim();
    }

    public String getTimeappl() {
        return timeappl;
    }

    public void setTimeappl(String timeappl) {
        this.timeappl = timeappl == null ? null : timeappl.trim();
    }

    public String getDayweek() {
        return dayweek;
    }

    public void setDayweek(String dayweek) {
        this.dayweek = dayweek == null ? null : dayweek.trim();
    }

    public String getSurtype() {
        return surtype;
    }

    public void setSurtype(String surtype) {
        this.surtype = surtype == null ? null : surtype.trim();
    }

    public String getEqpt() {
        return eqpt;
    }

    public void setEqpt(String eqpt) {
        this.eqpt = eqpt == null ? null : eqpt.trim();
    }

    public String getSurappl() {
        return surappl;
    }

    public void setSurappl(String surappl) {
        this.surappl = surappl == null ? null : surappl.trim();
    }

    public String getSectPrt() {
        return sectPrt;
    }

    public void setSectPrt(String sectPrt) {
        this.sectPrt = sectPrt == null ? null : sectPrt.trim();
    }

    public String getGeotblno() {
        return geotblno;
    }

    public void setGeotblno(String geotblno) {
        this.geotblno = geotblno == null ? null : geotblno.trim();
    }

    public String getBtwgeotb() {
        return btwgeotb;
    }

    public void setBtwgeotb(String btwgeotb) {
        this.btwgeotb = btwgeotb == null ? null : btwgeotb.trim();
    }

    public String getAndgeotb() {
        return andgeotb;
    }

    public void setAndgeotb(String andgeotb) {
        this.andgeotb = andgeotb == null ? null : andgeotb.trim();
    }

    public String getChgappl() {
        return chgappl;
    }

    public void setChgappl(String chgappl) {
        this.chgappl = chgappl == null ? null : chgappl.trim();
    }

    public BigDecimal getChgamt() {
        return chgamt;
    }

    public void setChgamt(BigDecimal chgamt) {
        this.chgamt = chgamt;
    }

    public String getChgcur() {
        return chgcur;
    }

    public void setChgcur(String chgcur) {
        this.chgcur = chgcur == null ? null : chgcur.trim();
    }

    public Integer getChgdec() {
        return chgdec;
    }

    public void setChgdec(Integer chgdec) {
        this.chgdec = chgdec;
    }

    public BigDecimal getChgamt2() {
        return chgamt2;
    }

    public void setChgamt2(BigDecimal chgamt2) {
        this.chgamt2 = chgamt2;
    }

    public String getChgcur2() {
        return chgcur2;
    }

    public void setChgcur2(String chgcur2) {
        this.chgcur2 = chgcur2 == null ? null : chgcur2.trim();
    }

    public Integer getChgdec2() {
        return chgdec2;
    }

    public void setChgdec2(Integer chgdec2) {
        this.chgdec2 = chgdec2;
    }

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent == null ? null : percent.trim();
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base == null ? null : base.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getRbd() {
        return rbd;
    }

    public void setRbd(String rbd) {
        this.rbd = rbd == null ? null : rbd.trim();
    }

    public String getTbl986() {
        return tbl986;
    }

    public void setTbl986(String tbl986) {
        this.tbl986 = tbl986 == null ? null : tbl986.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}