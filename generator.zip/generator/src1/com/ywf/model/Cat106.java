package com.ywf.model;

import java.util.Date;

public class Cat106 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String appl;

    private String cxr1;

    private String cxr2;

    private String cxr3;

    private String cxr4;

    private String cxr5;

    private String cxr6;

    private String ow;

    private String intl;

    private String io;

    private String constr;

    private String tsi;

    private String loc1type;

    private String loc1code;

    private String loc2type;

    private String loc2code;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getCxr1() {
        return cxr1;
    }

    public void setCxr1(String cxr1) {
        this.cxr1 = cxr1 == null ? null : cxr1.trim();
    }

    public String getCxr2() {
        return cxr2;
    }

    public void setCxr2(String cxr2) {
        this.cxr2 = cxr2 == null ? null : cxr2.trim();
    }

    public String getCxr3() {
        return cxr3;
    }

    public void setCxr3(String cxr3) {
        this.cxr3 = cxr3 == null ? null : cxr3.trim();
    }

    public String getCxr4() {
        return cxr4;
    }

    public void setCxr4(String cxr4) {
        this.cxr4 = cxr4 == null ? null : cxr4.trim();
    }

    public String getCxr5() {
        return cxr5;
    }

    public void setCxr5(String cxr5) {
        this.cxr5 = cxr5 == null ? null : cxr5.trim();
    }

    public String getCxr6() {
        return cxr6;
    }

    public void setCxr6(String cxr6) {
        this.cxr6 = cxr6 == null ? null : cxr6.trim();
    }

    public String getOw() {
        return ow;
    }

    public void setOw(String ow) {
        this.ow = ow == null ? null : ow.trim();
    }

    public String getIntl() {
        return intl;
    }

    public void setIntl(String intl) {
        this.intl = intl == null ? null : intl.trim();
    }

    public String getIo() {
        return io;
    }

    public void setIo(String io) {
        this.io = io == null ? null : io.trim();
    }

    public String getConstr() {
        return constr;
    }

    public void setConstr(String constr) {
        this.constr = constr == null ? null : constr.trim();
    }

    public String getTsi() {
        return tsi;
    }

    public void setTsi(String tsi) {
        this.tsi = tsi == null ? null : tsi.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}