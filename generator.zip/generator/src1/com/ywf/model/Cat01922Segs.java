package com.ywf.model;

import java.util.Date;

public class Cat01922Segs {
    private Long id;

    private String catno;

    private String tableno;

    private Long createId;

    private Integer minnum;

    private Integer maxnum;

    private String psgr1Type;

    private Integer psgr1Min;

    private Integer psgr1Max;

    private String psgr2Type;

    private Integer psgr2Min;

    private Integer psgr2Max;

    private String psgr3Type;

    private Integer psgr3Min;

    private Integer psgr3Max;

    private String fbcode;

    private Date createtime;

    private Date updatetime;

    private Integer segorder;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCatno() {
        return catno;
    }

    public void setCatno(String catno) {
        this.catno = catno == null ? null : catno.trim();
    }

    public String getTableno() {
        return tableno;
    }

    public void setTableno(String tableno) {
        this.tableno = tableno == null ? null : tableno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getMinnum() {
        return minnum;
    }

    public void setMinnum(Integer minnum) {
        this.minnum = minnum;
    }

    public Integer getMaxnum() {
        return maxnum;
    }

    public void setMaxnum(Integer maxnum) {
        this.maxnum = maxnum;
    }

    public String getPsgr1Type() {
        return psgr1Type;
    }

    public void setPsgr1Type(String psgr1Type) {
        this.psgr1Type = psgr1Type == null ? null : psgr1Type.trim();
    }

    public Integer getPsgr1Min() {
        return psgr1Min;
    }

    public void setPsgr1Min(Integer psgr1Min) {
        this.psgr1Min = psgr1Min;
    }

    public Integer getPsgr1Max() {
        return psgr1Max;
    }

    public void setPsgr1Max(Integer psgr1Max) {
        this.psgr1Max = psgr1Max;
    }

    public String getPsgr2Type() {
        return psgr2Type;
    }

    public void setPsgr2Type(String psgr2Type) {
        this.psgr2Type = psgr2Type == null ? null : psgr2Type.trim();
    }

    public Integer getPsgr2Min() {
        return psgr2Min;
    }

    public void setPsgr2Min(Integer psgr2Min) {
        this.psgr2Min = psgr2Min;
    }

    public Integer getPsgr2Max() {
        return psgr2Max;
    }

    public void setPsgr2Max(Integer psgr2Max) {
        this.psgr2Max = psgr2Max;
    }

    public String getPsgr3Type() {
        return psgr3Type;
    }

    public void setPsgr3Type(String psgr3Type) {
        this.psgr3Type = psgr3Type == null ? null : psgr3Type.trim();
    }

    public Integer getPsgr3Min() {
        return psgr3Min;
    }

    public void setPsgr3Min(Integer psgr3Min) {
        this.psgr3Min = psgr3Min;
    }

    public Integer getPsgr3Max() {
        return psgr3Max;
    }

    public void setPsgr3Max(Integer psgr3Max) {
        this.psgr3Max = psgr3Max;
    }

    public String getFbcode() {
        return fbcode;
    }

    public void setFbcode(String fbcode) {
        this.fbcode = fbcode == null ? null : fbcode.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }
}