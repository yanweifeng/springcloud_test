package com.ywf.model;

import java.util.Date;

public class Tbl986 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String mktngcxr;

    private String opercxr;

    private String fltnum1;

    private String fltnum2;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getMktngcxr() {
        return mktngcxr;
    }

    public void setMktngcxr(String mktngcxr) {
        this.mktngcxr = mktngcxr == null ? null : mktngcxr.trim();
    }

    public String getOpercxr() {
        return opercxr;
    }

    public void setOpercxr(String opercxr) {
        this.opercxr = opercxr == null ? null : opercxr.trim();
    }

    public String getFltnum1() {
        return fltnum1;
    }

    public void setFltnum1(String fltnum1) {
        this.fltnum1 = fltnum1 == null ? null : fltnum1.trim();
    }

    public String getFltnum2() {
        return fltnum2;
    }

    public void setFltnum2(String fltnum2) {
        this.fltnum2 = fltnum2 == null ? null : fltnum2.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}