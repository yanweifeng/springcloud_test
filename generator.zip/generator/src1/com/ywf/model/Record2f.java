package com.ywf.model;

import java.util.Date;

public class Record2f {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String action;

    private String ruletar;

    private String cxr;

    private String ruleno;

    private String cat;

    private String mcn;

    private String seqno;

    private String loc1type;

    private String loc1code;

    private String loc1tbl978;

    private String loc2type;

    private String loc2code;

    private String loc2tbl978;

    private String spare13;

    private String fareappl;

    private String jtcxrtbl;

    private Date effdate;

    private Date disdate;

    private String batchci;

    private String batchno;

    private String notappl;

    private String spare07;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }

    public String getRuletar() {
        return ruletar;
    }

    public void setRuletar(String ruletar) {
        this.ruletar = ruletar == null ? null : ruletar.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat == null ? null : cat.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc1tbl978() {
        return loc1tbl978;
    }

    public void setLoc1tbl978(String loc1tbl978) {
        this.loc1tbl978 = loc1tbl978 == null ? null : loc1tbl978.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getLoc2tbl978() {
        return loc2tbl978;
    }

    public void setLoc2tbl978(String loc2tbl978) {
        this.loc2tbl978 = loc2tbl978 == null ? null : loc2tbl978.trim();
    }

    public String getSpare13() {
        return spare13;
    }

    public void setSpare13(String spare13) {
        this.spare13 = spare13 == null ? null : spare13.trim();
    }

    public String getFareappl() {
        return fareappl;
    }

    public void setFareappl(String fareappl) {
        this.fareappl = fareappl == null ? null : fareappl.trim();
    }

    public String getJtcxrtbl() {
        return jtcxrtbl;
    }

    public void setJtcxrtbl(String jtcxrtbl) {
        this.jtcxrtbl = jtcxrtbl == null ? null : jtcxrtbl.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getNotappl() {
        return notappl;
    }

    public void setNotappl(String notappl) {
        this.notappl = notappl == null ? null : notappl.trim();
    }

    public String getSpare07() {
        return spare07;
    }

    public void setSpare07(String spare07) {
        this.spare07 = spare07 == null ? null : spare07.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}