package com.ywf.model;

import java.util.Date;

public class G16 {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String areacd;

    private String type;

    private String cxr;

    private String filler;

    private Date effdate;

    private Date disdate;

    private Date stamp;

    private String privateTag;

    private String filler1;

    private String papertariff;

    private String ntanum;

    private String dotnum;

    private String fcast;

    private String fctariffcd;

    private String fctariffnum;

    private String frast;

    private String frtariffcd;

    private String frtariffnum;

    private String grast;

    private String grtariffcd;

    private String grtariffnum;

    private String ff1ast;

    private String ff1tariffcd;

    private String ff1tariffnum;

    private String afz1ast;

    private String afz1tariffcd;

    private String afz1tariffnum;

    private String ff2ast;

    private String ff2tariffcd;

    private String ff2tariffnum;

    private String afz2ast;

    private String afz2tariffcd;

    private String afz2tariffnum;

    private String ff3ast;

    private String ff3tariffcd;

    private String ff3tariffnum;

    private String afz3ast;

    private String afz3tariffcd;

    private String afz3tariffnum;

    private String ff4ast;

    private String ff4tariffcd;

    private String ff4tariffnum;

    private String afz4ast;

    private String afz4tariffcd;

    private String afz4tariffnum;

    private String filler2;

    private String unpubast;

    private String unpubtariffcd;

    private String unpubtariffnum;

    private String rtg1ast;

    private String rtg1tariffcd;

    private String rtg1tariffnum;

    private String areacode1;

    private String areacode3;

    private String areacode2;

    private String areacode4;

    private String rtg2ast;

    private String rtg2tariffcd;

    private String rtg2tariffnum;

    private String filler3;

    private String filler4;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAreacd() {
        return areacd;
    }

    public void setAreacd(String areacd) {
        this.areacd = areacd == null ? null : areacd.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public Date getStamp() {
        return stamp;
    }

    public void setStamp(Date stamp) {
        this.stamp = stamp;
    }

    public String getPrivateTag() {
        return privateTag;
    }

    public void setPrivateTag(String privateTag) {
        this.privateTag = privateTag == null ? null : privateTag.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getPapertariff() {
        return papertariff;
    }

    public void setPapertariff(String papertariff) {
        this.papertariff = papertariff == null ? null : papertariff.trim();
    }

    public String getNtanum() {
        return ntanum;
    }

    public void setNtanum(String ntanum) {
        this.ntanum = ntanum == null ? null : ntanum.trim();
    }

    public String getDotnum() {
        return dotnum;
    }

    public void setDotnum(String dotnum) {
        this.dotnum = dotnum == null ? null : dotnum.trim();
    }

    public String getFcast() {
        return fcast;
    }

    public void setFcast(String fcast) {
        this.fcast = fcast == null ? null : fcast.trim();
    }

    public String getFctariffcd() {
        return fctariffcd;
    }

    public void setFctariffcd(String fctariffcd) {
        this.fctariffcd = fctariffcd == null ? null : fctariffcd.trim();
    }

    public String getFctariffnum() {
        return fctariffnum;
    }

    public void setFctariffnum(String fctariffnum) {
        this.fctariffnum = fctariffnum == null ? null : fctariffnum.trim();
    }

    public String getFrast() {
        return frast;
    }

    public void setFrast(String frast) {
        this.frast = frast == null ? null : frast.trim();
    }

    public String getFrtariffcd() {
        return frtariffcd;
    }

    public void setFrtariffcd(String frtariffcd) {
        this.frtariffcd = frtariffcd == null ? null : frtariffcd.trim();
    }

    public String getFrtariffnum() {
        return frtariffnum;
    }

    public void setFrtariffnum(String frtariffnum) {
        this.frtariffnum = frtariffnum == null ? null : frtariffnum.trim();
    }

    public String getGrast() {
        return grast;
    }

    public void setGrast(String grast) {
        this.grast = grast == null ? null : grast.trim();
    }

    public String getGrtariffcd() {
        return grtariffcd;
    }

    public void setGrtariffcd(String grtariffcd) {
        this.grtariffcd = grtariffcd == null ? null : grtariffcd.trim();
    }

    public String getGrtariffnum() {
        return grtariffnum;
    }

    public void setGrtariffnum(String grtariffnum) {
        this.grtariffnum = grtariffnum == null ? null : grtariffnum.trim();
    }

    public String getFf1ast() {
        return ff1ast;
    }

    public void setFf1ast(String ff1ast) {
        this.ff1ast = ff1ast == null ? null : ff1ast.trim();
    }

    public String getFf1tariffcd() {
        return ff1tariffcd;
    }

    public void setFf1tariffcd(String ff1tariffcd) {
        this.ff1tariffcd = ff1tariffcd == null ? null : ff1tariffcd.trim();
    }

    public String getFf1tariffnum() {
        return ff1tariffnum;
    }

    public void setFf1tariffnum(String ff1tariffnum) {
        this.ff1tariffnum = ff1tariffnum == null ? null : ff1tariffnum.trim();
    }

    public String getAfz1ast() {
        return afz1ast;
    }

    public void setAfz1ast(String afz1ast) {
        this.afz1ast = afz1ast == null ? null : afz1ast.trim();
    }

    public String getAfz1tariffcd() {
        return afz1tariffcd;
    }

    public void setAfz1tariffcd(String afz1tariffcd) {
        this.afz1tariffcd = afz1tariffcd == null ? null : afz1tariffcd.trim();
    }

    public String getAfz1tariffnum() {
        return afz1tariffnum;
    }

    public void setAfz1tariffnum(String afz1tariffnum) {
        this.afz1tariffnum = afz1tariffnum == null ? null : afz1tariffnum.trim();
    }

    public String getFf2ast() {
        return ff2ast;
    }

    public void setFf2ast(String ff2ast) {
        this.ff2ast = ff2ast == null ? null : ff2ast.trim();
    }

    public String getFf2tariffcd() {
        return ff2tariffcd;
    }

    public void setFf2tariffcd(String ff2tariffcd) {
        this.ff2tariffcd = ff2tariffcd == null ? null : ff2tariffcd.trim();
    }

    public String getFf2tariffnum() {
        return ff2tariffnum;
    }

    public void setFf2tariffnum(String ff2tariffnum) {
        this.ff2tariffnum = ff2tariffnum == null ? null : ff2tariffnum.trim();
    }

    public String getAfz2ast() {
        return afz2ast;
    }

    public void setAfz2ast(String afz2ast) {
        this.afz2ast = afz2ast == null ? null : afz2ast.trim();
    }

    public String getAfz2tariffcd() {
        return afz2tariffcd;
    }

    public void setAfz2tariffcd(String afz2tariffcd) {
        this.afz2tariffcd = afz2tariffcd == null ? null : afz2tariffcd.trim();
    }

    public String getAfz2tariffnum() {
        return afz2tariffnum;
    }

    public void setAfz2tariffnum(String afz2tariffnum) {
        this.afz2tariffnum = afz2tariffnum == null ? null : afz2tariffnum.trim();
    }

    public String getFf3ast() {
        return ff3ast;
    }

    public void setFf3ast(String ff3ast) {
        this.ff3ast = ff3ast == null ? null : ff3ast.trim();
    }

    public String getFf3tariffcd() {
        return ff3tariffcd;
    }

    public void setFf3tariffcd(String ff3tariffcd) {
        this.ff3tariffcd = ff3tariffcd == null ? null : ff3tariffcd.trim();
    }

    public String getFf3tariffnum() {
        return ff3tariffnum;
    }

    public void setFf3tariffnum(String ff3tariffnum) {
        this.ff3tariffnum = ff3tariffnum == null ? null : ff3tariffnum.trim();
    }

    public String getAfz3ast() {
        return afz3ast;
    }

    public void setAfz3ast(String afz3ast) {
        this.afz3ast = afz3ast == null ? null : afz3ast.trim();
    }

    public String getAfz3tariffcd() {
        return afz3tariffcd;
    }

    public void setAfz3tariffcd(String afz3tariffcd) {
        this.afz3tariffcd = afz3tariffcd == null ? null : afz3tariffcd.trim();
    }

    public String getAfz3tariffnum() {
        return afz3tariffnum;
    }

    public void setAfz3tariffnum(String afz3tariffnum) {
        this.afz3tariffnum = afz3tariffnum == null ? null : afz3tariffnum.trim();
    }

    public String getFf4ast() {
        return ff4ast;
    }

    public void setFf4ast(String ff4ast) {
        this.ff4ast = ff4ast == null ? null : ff4ast.trim();
    }

    public String getFf4tariffcd() {
        return ff4tariffcd;
    }

    public void setFf4tariffcd(String ff4tariffcd) {
        this.ff4tariffcd = ff4tariffcd == null ? null : ff4tariffcd.trim();
    }

    public String getFf4tariffnum() {
        return ff4tariffnum;
    }

    public void setFf4tariffnum(String ff4tariffnum) {
        this.ff4tariffnum = ff4tariffnum == null ? null : ff4tariffnum.trim();
    }

    public String getAfz4ast() {
        return afz4ast;
    }

    public void setAfz4ast(String afz4ast) {
        this.afz4ast = afz4ast == null ? null : afz4ast.trim();
    }

    public String getAfz4tariffcd() {
        return afz4tariffcd;
    }

    public void setAfz4tariffcd(String afz4tariffcd) {
        this.afz4tariffcd = afz4tariffcd == null ? null : afz4tariffcd.trim();
    }

    public String getAfz4tariffnum() {
        return afz4tariffnum;
    }

    public void setAfz4tariffnum(String afz4tariffnum) {
        this.afz4tariffnum = afz4tariffnum == null ? null : afz4tariffnum.trim();
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public String getUnpubast() {
        return unpubast;
    }

    public void setUnpubast(String unpubast) {
        this.unpubast = unpubast == null ? null : unpubast.trim();
    }

    public String getUnpubtariffcd() {
        return unpubtariffcd;
    }

    public void setUnpubtariffcd(String unpubtariffcd) {
        this.unpubtariffcd = unpubtariffcd == null ? null : unpubtariffcd.trim();
    }

    public String getUnpubtariffnum() {
        return unpubtariffnum;
    }

    public void setUnpubtariffnum(String unpubtariffnum) {
        this.unpubtariffnum = unpubtariffnum == null ? null : unpubtariffnum.trim();
    }

    public String getRtg1ast() {
        return rtg1ast;
    }

    public void setRtg1ast(String rtg1ast) {
        this.rtg1ast = rtg1ast == null ? null : rtg1ast.trim();
    }

    public String getRtg1tariffcd() {
        return rtg1tariffcd;
    }

    public void setRtg1tariffcd(String rtg1tariffcd) {
        this.rtg1tariffcd = rtg1tariffcd == null ? null : rtg1tariffcd.trim();
    }

    public String getRtg1tariffnum() {
        return rtg1tariffnum;
    }

    public void setRtg1tariffnum(String rtg1tariffnum) {
        this.rtg1tariffnum = rtg1tariffnum == null ? null : rtg1tariffnum.trim();
    }

    public String getAreacode1() {
        return areacode1;
    }

    public void setAreacode1(String areacode1) {
        this.areacode1 = areacode1 == null ? null : areacode1.trim();
    }

    public String getAreacode3() {
        return areacode3;
    }

    public void setAreacode3(String areacode3) {
        this.areacode3 = areacode3 == null ? null : areacode3.trim();
    }

    public String getAreacode2() {
        return areacode2;
    }

    public void setAreacode2(String areacode2) {
        this.areacode2 = areacode2 == null ? null : areacode2.trim();
    }

    public String getAreacode4() {
        return areacode4;
    }

    public void setAreacode4(String areacode4) {
        this.areacode4 = areacode4 == null ? null : areacode4.trim();
    }

    public String getRtg2ast() {
        return rtg2ast;
    }

    public void setRtg2ast(String rtg2ast) {
        this.rtg2ast = rtg2ast == null ? null : rtg2ast.trim();
    }

    public String getRtg2tariffcd() {
        return rtg2tariffcd;
    }

    public void setRtg2tariffcd(String rtg2tariffcd) {
        this.rtg2tariffcd = rtg2tariffcd == null ? null : rtg2tariffcd.trim();
    }

    public String getRtg2tariffnum() {
        return rtg2tariffnum;
    }

    public void setRtg2tariffnum(String rtg2tariffnum) {
        this.rtg2tariffnum = rtg2tariffnum == null ? null : rtg2tariffnum.trim();
    }

    public String getFiller3() {
        return filler3;
    }

    public void setFiller3(String filler3) {
        this.filler3 = filler3 == null ? null : filler3.trim();
    }

    public String getFiller4() {
        return filler4;
    }

    public void setFiller4(String filler4) {
        this.filler4 = filler4 == null ? null : filler4.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}