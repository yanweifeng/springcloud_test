package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Tbl979 {
    private Long id;

    private String tblno;

    private Long createId;

    private String seqno;

    private Long deleteId;

    private String dirind;

    private String loc1type;

    private String loc1code;

    private String loc1zone;

    private String loc2type;

    private String loc2code;

    private String loc2zone;

    private String bundled;

    private String sellind;

    private String fareind;

    private String farepct;

    private BigDecimal fare1amt;

    private String fare1cur;

    private Integer fare1dec;

    private BigDecimal fare2amt;

    private String fare2cur;

    private Integer fare2dec;

    private String r1minpct;

    private String r1maxpct;

    private BigDecimal r1minfare;

    private BigDecimal r1maxfare;

    private String r1cur;

    private Integer r1dec;

    private BigDecimal r2minfare;

    private BigDecimal r2maxfare;

    private String r2cur;

    private Integer r2dec;

    private String reserved1;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getDirind() {
        return dirind;
    }

    public void setDirind(String dirind) {
        this.dirind = dirind == null ? null : dirind.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc1zone() {
        return loc1zone;
    }

    public void setLoc1zone(String loc1zone) {
        this.loc1zone = loc1zone == null ? null : loc1zone.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getLoc2zone() {
        return loc2zone;
    }

    public void setLoc2zone(String loc2zone) {
        this.loc2zone = loc2zone == null ? null : loc2zone.trim();
    }

    public String getBundled() {
        return bundled;
    }

    public void setBundled(String bundled) {
        this.bundled = bundled == null ? null : bundled.trim();
    }

    public String getSellind() {
        return sellind;
    }

    public void setSellind(String sellind) {
        this.sellind = sellind == null ? null : sellind.trim();
    }

    public String getFareind() {
        return fareind;
    }

    public void setFareind(String fareind) {
        this.fareind = fareind == null ? null : fareind.trim();
    }

    public String getFarepct() {
        return farepct;
    }

    public void setFarepct(String farepct) {
        this.farepct = farepct == null ? null : farepct.trim();
    }

    public BigDecimal getFare1amt() {
        return fare1amt;
    }

    public void setFare1amt(BigDecimal fare1amt) {
        this.fare1amt = fare1amt;
    }

    public String getFare1cur() {
        return fare1cur;
    }

    public void setFare1cur(String fare1cur) {
        this.fare1cur = fare1cur == null ? null : fare1cur.trim();
    }

    public Integer getFare1dec() {
        return fare1dec;
    }

    public void setFare1dec(Integer fare1dec) {
        this.fare1dec = fare1dec;
    }

    public BigDecimal getFare2amt() {
        return fare2amt;
    }

    public void setFare2amt(BigDecimal fare2amt) {
        this.fare2amt = fare2amt;
    }

    public String getFare2cur() {
        return fare2cur;
    }

    public void setFare2cur(String fare2cur) {
        this.fare2cur = fare2cur == null ? null : fare2cur.trim();
    }

    public Integer getFare2dec() {
        return fare2dec;
    }

    public void setFare2dec(Integer fare2dec) {
        this.fare2dec = fare2dec;
    }

    public String getR1minpct() {
        return r1minpct;
    }

    public void setR1minpct(String r1minpct) {
        this.r1minpct = r1minpct == null ? null : r1minpct.trim();
    }

    public String getR1maxpct() {
        return r1maxpct;
    }

    public void setR1maxpct(String r1maxpct) {
        this.r1maxpct = r1maxpct == null ? null : r1maxpct.trim();
    }

    public BigDecimal getR1minfare() {
        return r1minfare;
    }

    public void setR1minfare(BigDecimal r1minfare) {
        this.r1minfare = r1minfare;
    }

    public BigDecimal getR1maxfare() {
        return r1maxfare;
    }

    public void setR1maxfare(BigDecimal r1maxfare) {
        this.r1maxfare = r1maxfare;
    }

    public String getR1cur() {
        return r1cur;
    }

    public void setR1cur(String r1cur) {
        this.r1cur = r1cur == null ? null : r1cur.trim();
    }

    public Integer getR1dec() {
        return r1dec;
    }

    public void setR1dec(Integer r1dec) {
        this.r1dec = r1dec;
    }

    public BigDecimal getR2minfare() {
        return r2minfare;
    }

    public void setR2minfare(BigDecimal r2minfare) {
        this.r2minfare = r2minfare;
    }

    public BigDecimal getR2maxfare() {
        return r2maxfare;
    }

    public void setR2maxfare(BigDecimal r2maxfare) {
        this.r2maxfare = r2maxfare;
    }

    public String getR2cur() {
        return r2cur;
    }

    public void setR2cur(String r2cur) {
        this.r2cur = r2cur == null ? null : r2cur.trim();
    }

    public Integer getR2dec() {
        return r2dec;
    }

    public void setR2dec(Integer r2dec) {
        this.r2dec = r2dec;
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1 == null ? null : reserved1.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}