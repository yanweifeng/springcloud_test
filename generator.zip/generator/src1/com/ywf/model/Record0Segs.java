package com.ywf.model;

import java.util.Date;

public class Record0Segs {
    private Long id;

    private Long record0Id;

    private Long createId;

    private Integer segorder;

    private String ruleno;

    private String srctar;

    private String cat;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecord0Id() {
        return record0Id;
    }

    public void setRecord0Id(Long record0Id) {
        this.record0Id = record0Id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getSrctar() {
        return srctar;
    }

    public void setSrctar(String srctar) {
        this.srctar = srctar == null ? null : srctar.trim();
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat == null ? null : cat.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}