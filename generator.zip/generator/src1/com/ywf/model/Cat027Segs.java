package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat027Segs {
    private Long id;

    private String tblno;

    private Long createId;

    private BigDecimal ginamt1;

    private String gincur1;

    private Integer gindec1;

    private BigDecimal ginamt2;

    private String gincur2;

    private Integer gindec2;

    private String gappl;

    private Integer gtransno;

    private Integer ginski;

    private Integer gincar;

    private Integer ginpark;

    private Integer ginresort;

    private Integer ginship;

    private Integer gother;

    private Integer gfree;

    private String gbettblno;

    private String gandtblno;

    private Date createtime;

    private Date updatetime;

    private Integer segorder;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public BigDecimal getGinamt1() {
        return ginamt1;
    }

    public void setGinamt1(BigDecimal ginamt1) {
        this.ginamt1 = ginamt1;
    }

    public String getGincur1() {
        return gincur1;
    }

    public void setGincur1(String gincur1) {
        this.gincur1 = gincur1 == null ? null : gincur1.trim();
    }

    public Integer getGindec1() {
        return gindec1;
    }

    public void setGindec1(Integer gindec1) {
        this.gindec1 = gindec1;
    }

    public BigDecimal getGinamt2() {
        return ginamt2;
    }

    public void setGinamt2(BigDecimal ginamt2) {
        this.ginamt2 = ginamt2;
    }

    public String getGincur2() {
        return gincur2;
    }

    public void setGincur2(String gincur2) {
        this.gincur2 = gincur2 == null ? null : gincur2.trim();
    }

    public Integer getGindec2() {
        return gindec2;
    }

    public void setGindec2(Integer gindec2) {
        this.gindec2 = gindec2;
    }

    public String getGappl() {
        return gappl;
    }

    public void setGappl(String gappl) {
        this.gappl = gappl == null ? null : gappl.trim();
    }

    public Integer getGtransno() {
        return gtransno;
    }

    public void setGtransno(Integer gtransno) {
        this.gtransno = gtransno;
    }

    public Integer getGinski() {
        return ginski;
    }

    public void setGinski(Integer ginski) {
        this.ginski = ginski;
    }

    public Integer getGincar() {
        return gincar;
    }

    public void setGincar(Integer gincar) {
        this.gincar = gincar;
    }

    public Integer getGinpark() {
        return ginpark;
    }

    public void setGinpark(Integer ginpark) {
        this.ginpark = ginpark;
    }

    public Integer getGinresort() {
        return ginresort;
    }

    public void setGinresort(Integer ginresort) {
        this.ginresort = ginresort;
    }

    public Integer getGinship() {
        return ginship;
    }

    public void setGinship(Integer ginship) {
        this.ginship = ginship;
    }

    public Integer getGother() {
        return gother;
    }

    public void setGother(Integer gother) {
        this.gother = gother;
    }

    public Integer getGfree() {
        return gfree;
    }

    public void setGfree(Integer gfree) {
        this.gfree = gfree;
    }

    public String getGbettblno() {
        return gbettblno;
    }

    public void setGbettblno(String gbettblno) {
        this.gbettblno = gbettblno == null ? null : gbettblno.trim();
    }

    public String getGandtblno() {
        return gandtblno;
    }

    public void setGandtblno(String gandtblno) {
        this.gandtblno = gandtblno == null ? null : gandtblno.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }
}