package com.ywf.model;

import java.util.Date;

public class Tbl997 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String cxr1;

    private String cxr2;

    private String cxr3;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getCxr1() {
        return cxr1;
    }

    public void setCxr1(String cxr1) {
        this.cxr1 = cxr1 == null ? null : cxr1.trim();
    }

    public String getCxr2() {
        return cxr2;
    }

    public void setCxr2(String cxr2) {
        this.cxr2 = cxr2 == null ? null : cxr2.trim();
    }

    public String getCxr3() {
        return cxr3;
    }

    public void setCxr3(String cxr3) {
        this.cxr3 = cxr3 == null ? null : cxr3.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}