package com.ywf.model;

import java.util.Date;

public class Cat002 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String strtime;

    private String stptime;

    private String applcd;

    private String dayweek;

    private String sameind;

    private String dowoccur;

    private String geotblno;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String negtag;

    private String appl;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getStrtime() {
        return strtime;
    }

    public void setStrtime(String strtime) {
        this.strtime = strtime == null ? null : strtime.trim();
    }

    public String getStptime() {
        return stptime;
    }

    public void setStptime(String stptime) {
        this.stptime = stptime == null ? null : stptime.trim();
    }

    public String getApplcd() {
        return applcd;
    }

    public void setApplcd(String applcd) {
        this.applcd = applcd == null ? null : applcd.trim();
    }

    public String getDayweek() {
        return dayweek;
    }

    public void setDayweek(String dayweek) {
        this.dayweek = dayweek == null ? null : dayweek.trim();
    }

    public String getSameind() {
        return sameind;
    }

    public void setSameind(String sameind) {
        this.sameind = sameind == null ? null : sameind.trim();
    }

    public String getDowoccur() {
        return dowoccur;
    }

    public void setDowoccur(String dowoccur) {
        this.dowoccur = dowoccur == null ? null : dowoccur.trim();
    }

    public String getGeotblno() {
        return geotblno;
    }

    public void setGeotblno(String geotblno) {
        this.geotblno = geotblno == null ? null : geotblno.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getNegtag() {
        return negtag;
    }

    public void setNegtag(String negtag) {
        this.negtag = negtag == null ? null : negtag.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}