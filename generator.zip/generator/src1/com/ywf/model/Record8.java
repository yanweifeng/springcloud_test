package com.ywf.model;

import java.util.Date;

public class Record8 {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String action;

    private String recid;

    private String cat35;

    private String cxr;

    private String primpass;

    private String appl;

    private String psgr;

    private String loc0type;

    private String loc0code;

    private String id1;

    private Integer min;

    private Integer max;

    private Integer psgrmin;

    private Integer psgrmax;

    private String acctcode;

    private String tktdesig;

    private String tar;

    private String ruleno;

    private String jtcxrtbl;

    private String samecxrind;

    private String tbl986;

    private String resrv1;

    private String di;

    private String global;

    private String loc1type;

    private String loc1code;

    private String loc1tbl978;

    private String loc2type;

    private String loc2code;

    private String loc2tbl978;

    private String loc3type;

    private String loc3code;

    private String tsi;

    private String loc4type;

    private String loc4code;

    private String resrv2;

    private String batchci;

    private String batchno;

    private String mcn;

    private Date effdate;

    private Date disdate;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }

    public String getRecid() {
        return recid;
    }

    public void setRecid(String recid) {
        this.recid = recid == null ? null : recid.trim();
    }

    public String getCat35() {
        return cat35;
    }

    public void setCat35(String cat35) {
        this.cat35 = cat35 == null ? null : cat35.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getPrimpass() {
        return primpass;
    }

    public void setPrimpass(String primpass) {
        this.primpass = primpass == null ? null : primpass.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getPsgr() {
        return psgr;
    }

    public void setPsgr(String psgr) {
        this.psgr = psgr == null ? null : psgr.trim();
    }

    public String getLoc0type() {
        return loc0type;
    }

    public void setLoc0type(String loc0type) {
        this.loc0type = loc0type == null ? null : loc0type.trim();
    }

    public String getLoc0code() {
        return loc0code;
    }

    public void setLoc0code(String loc0code) {
        this.loc0code = loc0code == null ? null : loc0code.trim();
    }

    public String getId1() {
        return id1;
    }

    public void setId1(String id1) {
        this.id1 = id1 == null ? null : id1.trim();
    }

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        this.max = max;
    }

    public Integer getPsgrmin() {
        return psgrmin;
    }

    public void setPsgrmin(Integer psgrmin) {
        this.psgrmin = psgrmin;
    }

    public Integer getPsgrmax() {
        return psgrmax;
    }

    public void setPsgrmax(Integer psgrmax) {
        this.psgrmax = psgrmax;
    }

    public String getAcctcode() {
        return acctcode;
    }

    public void setAcctcode(String acctcode) {
        this.acctcode = acctcode == null ? null : acctcode.trim();
    }

    public String getTktdesig() {
        return tktdesig;
    }

    public void setTktdesig(String tktdesig) {
        this.tktdesig = tktdesig == null ? null : tktdesig.trim();
    }

    public String getTar() {
        return tar;
    }

    public void setTar(String tar) {
        this.tar = tar == null ? null : tar.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getJtcxrtbl() {
        return jtcxrtbl;
    }

    public void setJtcxrtbl(String jtcxrtbl) {
        this.jtcxrtbl = jtcxrtbl == null ? null : jtcxrtbl.trim();
    }

    public String getSamecxrind() {
        return samecxrind;
    }

    public void setSamecxrind(String samecxrind) {
        this.samecxrind = samecxrind == null ? null : samecxrind.trim();
    }

    public String getTbl986() {
        return tbl986;
    }

    public void setTbl986(String tbl986) {
        this.tbl986 = tbl986 == null ? null : tbl986.trim();
    }

    public String getResrv1() {
        return resrv1;
    }

    public void setResrv1(String resrv1) {
        this.resrv1 = resrv1 == null ? null : resrv1.trim();
    }

    public String getDi() {
        return di;
    }

    public void setDi(String di) {
        this.di = di == null ? null : di.trim();
    }

    public String getGlobal() {
        return global;
    }

    public void setGlobal(String global) {
        this.global = global == null ? null : global.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc1tbl978() {
        return loc1tbl978;
    }

    public void setLoc1tbl978(String loc1tbl978) {
        this.loc1tbl978 = loc1tbl978 == null ? null : loc1tbl978.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getLoc2tbl978() {
        return loc2tbl978;
    }

    public void setLoc2tbl978(String loc2tbl978) {
        this.loc2tbl978 = loc2tbl978 == null ? null : loc2tbl978.trim();
    }

    public String getLoc3type() {
        return loc3type;
    }

    public void setLoc3type(String loc3type) {
        this.loc3type = loc3type == null ? null : loc3type.trim();
    }

    public String getLoc3code() {
        return loc3code;
    }

    public void setLoc3code(String loc3code) {
        this.loc3code = loc3code == null ? null : loc3code.trim();
    }

    public String getTsi() {
        return tsi;
    }

    public void setTsi(String tsi) {
        this.tsi = tsi == null ? null : tsi.trim();
    }

    public String getLoc4type() {
        return loc4type;
    }

    public void setLoc4type(String loc4type) {
        this.loc4type = loc4type == null ? null : loc4type.trim();
    }

    public String getLoc4code() {
        return loc4code;
    }

    public void setLoc4code(String loc4code) {
        this.loc4code = loc4code == null ? null : loc4code.trim();
    }

    public String getResrv2() {
        return resrv2;
    }

    public void setResrv2(String resrv2) {
        this.resrv2 = resrv2 == null ? null : resrv2.trim();
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}