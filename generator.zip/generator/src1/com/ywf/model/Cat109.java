package com.ywf.model;

import java.util.Date;

public class Cat109 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String appl1;

    private String loc1type1;

    private String loc1code1;

    private String loc2type1;

    private String loc2code1;

    private String appl2;

    private String loc1type2;

    private String loc1code2;

    private String loc2type2;

    private String loc2code2;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAppl1() {
        return appl1;
    }

    public void setAppl1(String appl1) {
        this.appl1 = appl1 == null ? null : appl1.trim();
    }

    public String getLoc1type1() {
        return loc1type1;
    }

    public void setLoc1type1(String loc1type1) {
        this.loc1type1 = loc1type1 == null ? null : loc1type1.trim();
    }

    public String getLoc1code1() {
        return loc1code1;
    }

    public void setLoc1code1(String loc1code1) {
        this.loc1code1 = loc1code1 == null ? null : loc1code1.trim();
    }

    public String getLoc2type1() {
        return loc2type1;
    }

    public void setLoc2type1(String loc2type1) {
        this.loc2type1 = loc2type1 == null ? null : loc2type1.trim();
    }

    public String getLoc2code1() {
        return loc2code1;
    }

    public void setLoc2code1(String loc2code1) {
        this.loc2code1 = loc2code1 == null ? null : loc2code1.trim();
    }

    public String getAppl2() {
        return appl2;
    }

    public void setAppl2(String appl2) {
        this.appl2 = appl2 == null ? null : appl2.trim();
    }

    public String getLoc1type2() {
        return loc1type2;
    }

    public void setLoc1type2(String loc1type2) {
        this.loc1type2 = loc1type2 == null ? null : loc1type2.trim();
    }

    public String getLoc1code2() {
        return loc1code2;
    }

    public void setLoc1code2(String loc1code2) {
        this.loc1code2 = loc1code2 == null ? null : loc1code2.trim();
    }

    public String getLoc2type2() {
        return loc2type2;
    }

    public void setLoc2type2(String loc2type2) {
        this.loc2type2 = loc2type2 == null ? null : loc2type2.trim();
    }

    public String getLoc2code2() {
        return loc2code2;
    }

    public void setLoc2code2(String loc2code2) {
        this.loc2code2 = loc2code2 == null ? null : loc2code2.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}