package com.ywf.model;

import java.util.Date;

public class Cat007 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String rtncode;

    private String rtntime;

    private String maxstay;

    private String maxunit;

    private String tktiss;

    private String fmgeotbl;

    private String togeotbl;

    private String waiver;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date maxstydt;

    private String maxstyel;

    private Date waivdate;

    private String waivel;

    private Integer waivper;

    private String waivunit;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getRtncode() {
        return rtncode;
    }

    public void setRtncode(String rtncode) {
        this.rtncode = rtncode == null ? null : rtncode.trim();
    }

    public String getRtntime() {
        return rtntime;
    }

    public void setRtntime(String rtntime) {
        this.rtntime = rtntime == null ? null : rtntime.trim();
    }

    public String getMaxstay() {
        return maxstay;
    }

    public void setMaxstay(String maxstay) {
        this.maxstay = maxstay == null ? null : maxstay.trim();
    }

    public String getMaxunit() {
        return maxunit;
    }

    public void setMaxunit(String maxunit) {
        this.maxunit = maxunit == null ? null : maxunit.trim();
    }

    public String getTktiss() {
        return tktiss;
    }

    public void setTktiss(String tktiss) {
        this.tktiss = tktiss == null ? null : tktiss.trim();
    }

    public String getFmgeotbl() {
        return fmgeotbl;
    }

    public void setFmgeotbl(String fmgeotbl) {
        this.fmgeotbl = fmgeotbl == null ? null : fmgeotbl.trim();
    }

    public String getTogeotbl() {
        return togeotbl;
    }

    public void setTogeotbl(String togeotbl) {
        this.togeotbl = togeotbl == null ? null : togeotbl.trim();
    }

    public String getWaiver() {
        return waiver;
    }

    public void setWaiver(String waiver) {
        this.waiver = waiver == null ? null : waiver.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getMaxstydt() {
        return maxstydt;
    }

    public void setMaxstydt(Date maxstydt) {
        this.maxstydt = maxstydt;
    }

    public String getMaxstyel() {
        return maxstyel;
    }

    public void setMaxstyel(String maxstyel) {
        this.maxstyel = maxstyel == null ? null : maxstyel.trim();
    }

    public Date getWaivdate() {
        return waivdate;
    }

    public void setWaivdate(Date waivdate) {
        this.waivdate = waivdate;
    }

    public String getWaivel() {
        return waivel;
    }

    public void setWaivel(String waivel) {
        this.waivel = waivel == null ? null : waivel.trim();
    }

    public Integer getWaivper() {
        return waivper;
    }

    public void setWaivper(Integer waivper) {
        this.waivper = waivper;
    }

    public String getWaivunit() {
        return waivunit;
    }

    public void setWaivunit(String waivunit) {
        this.waivunit = waivunit == null ? null : waivunit.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}