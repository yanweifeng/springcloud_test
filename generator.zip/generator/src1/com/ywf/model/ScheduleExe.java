package com.ywf.model;

import java.util.Date;

public class ScheduleExe {
    private Long id;

    private String status;

    private String iserror;

    private Long preScheduleId;

    private Date startTime;

    private Date endTime;

    private String holded;

    private Integer exeTime;

    private String remark;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getIserror() {
        return iserror;
    }

    public void setIserror(String iserror) {
        this.iserror = iserror == null ? null : iserror.trim();
    }

    public Long getPreScheduleId() {
        return preScheduleId;
    }

    public void setPreScheduleId(Long preScheduleId) {
        this.preScheduleId = preScheduleId;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getHolded() {
        return holded;
    }

    public void setHolded(String holded) {
        this.holded = holded == null ? null : holded.trim();
    }

    public Integer getExeTime() {
        return exeTime;
    }

    public void setExeTime(Integer exeTime) {
        this.exeTime = exeTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}