package com.ywf.model;

import java.util.Date;

public class Cat006 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String origday;

    private String rtntime;

    private String minstay;

    private String minunit;

    private String fmgeotbl;

    private String togeotbl;

    private String waiver;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Date minstydt;

    private String minstyel;

    private Date waivdate;

    private String waivel;

    private Integer waivper;

    private String waivunit;

    private String reserve;

    private Date createtime;

    private Date updatetime;

    private String filler;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getOrigday() {
        return origday;
    }

    public void setOrigday(String origday) {
        this.origday = origday == null ? null : origday.trim();
    }

    public String getRtntime() {
        return rtntime;
    }

    public void setRtntime(String rtntime) {
        this.rtntime = rtntime == null ? null : rtntime.trim();
    }

    public String getMinstay() {
        return minstay;
    }

    public void setMinstay(String minstay) {
        this.minstay = minstay == null ? null : minstay.trim();
    }

    public String getMinunit() {
        return minunit;
    }

    public void setMinunit(String minunit) {
        this.minunit = minunit == null ? null : minunit.trim();
    }

    public String getFmgeotbl() {
        return fmgeotbl;
    }

    public void setFmgeotbl(String fmgeotbl) {
        this.fmgeotbl = fmgeotbl == null ? null : fmgeotbl.trim();
    }

    public String getTogeotbl() {
        return togeotbl;
    }

    public void setTogeotbl(String togeotbl) {
        this.togeotbl = togeotbl == null ? null : togeotbl.trim();
    }

    public String getWaiver() {
        return waiver;
    }

    public void setWaiver(String waiver) {
        this.waiver = waiver == null ? null : waiver.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getMinstydt() {
        return minstydt;
    }

    public void setMinstydt(Date minstydt) {
        this.minstydt = minstydt;
    }

    public String getMinstyel() {
        return minstyel;
    }

    public void setMinstyel(String minstyel) {
        this.minstyel = minstyel == null ? null : minstyel.trim();
    }

    public Date getWaivdate() {
        return waivdate;
    }

    public void setWaivdate(Date waivdate) {
        this.waivdate = waivdate;
    }

    public String getWaivel() {
        return waivel;
    }

    public void setWaivel(String waivel) {
        this.waivel = waivel == null ? null : waivel.trim();
    }

    public Integer getWaivper() {
        return waivper;
    }

    public void setWaivper(Integer waivper) {
        this.waivper = waivper;
    }

    public String getWaivunit() {
        return waivunit;
    }

    public void setWaivunit(String waivunit) {
        this.waivunit = waivunit == null ? null : waivunit.trim();
    }

    public String getReserve() {
        return reserve;
    }

    public void setReserve(String reserve) {
        this.reserve = reserve == null ? null : reserve.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }
}