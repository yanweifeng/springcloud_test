package com.ywf.model;

import java.util.Date;

public class RoutingType1 {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String link;

    private String actioncode;

    private String mcn;

    private String batchid;

    private String batchcn;

    private String tariff;

    private String carrier;

    private String routingnum;

    private Integer type1num;

    private Integer type2num;

    private Integer type3num;

    private Integer type4num;

    private Date effdate;

    private Date disdate;

    private String direction;

    private String validation;

    private String commonpoint;

    private String intermedpoint;

    private String untktedpoint;

    private String reserved;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link == null ? null : link.trim();
    }

    public String getActioncode() {
        return actioncode;
    }

    public void setActioncode(String actioncode) {
        this.actioncode = actioncode == null ? null : actioncode.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public String getBatchid() {
        return batchid;
    }

    public void setBatchid(String batchid) {
        this.batchid = batchid == null ? null : batchid.trim();
    }

    public String getBatchcn() {
        return batchcn;
    }

    public void setBatchcn(String batchcn) {
        this.batchcn = batchcn == null ? null : batchcn.trim();
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff == null ? null : tariff.trim();
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    public String getRoutingnum() {
        return routingnum;
    }

    public void setRoutingnum(String routingnum) {
        this.routingnum = routingnum == null ? null : routingnum.trim();
    }

    public Integer getType1num() {
        return type1num;
    }

    public void setType1num(Integer type1num) {
        this.type1num = type1num;
    }

    public Integer getType2num() {
        return type2num;
    }

    public void setType2num(Integer type2num) {
        this.type2num = type2num;
    }

    public Integer getType3num() {
        return type3num;
    }

    public void setType3num(Integer type3num) {
        this.type3num = type3num;
    }

    public Integer getType4num() {
        return type4num;
    }

    public void setType4num(Integer type4num) {
        this.type4num = type4num;
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction == null ? null : direction.trim();
    }

    public String getValidation() {
        return validation;
    }

    public void setValidation(String validation) {
        this.validation = validation == null ? null : validation.trim();
    }

    public String getCommonpoint() {
        return commonpoint;
    }

    public void setCommonpoint(String commonpoint) {
        this.commonpoint = commonpoint == null ? null : commonpoint.trim();
    }

    public String getIntermedpoint() {
        return intermedpoint;
    }

    public void setIntermedpoint(String intermedpoint) {
        this.intermedpoint = intermedpoint == null ? null : intermedpoint.trim();
    }

    public String getUntktedpoint() {
        return untktedpoint;
    }

    public void setUntktedpoint(String untktedpoint) {
        this.untktedpoint = untktedpoint == null ? null : untktedpoint.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}