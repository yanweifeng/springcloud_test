package com.ywf.model;

import java.util.Date;

public class Cat008Segs {
    private Long id;

    private String tblno;

    private Long createId;

    private String cxr;

    private String stopnum;

    private String incxr;

    private String appl;

    private String loctype;

    private String loc1code;

    private String loc2code;

    private String outcxr;

    private String ioind;

    private String chgind;

    private Date createtime;

    private Date updatetime;

    private Integer segorder;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getStopnum() {
        return stopnum;
    }

    public void setStopnum(String stopnum) {
        this.stopnum = stopnum == null ? null : stopnum.trim();
    }

    public String getIncxr() {
        return incxr;
    }

    public void setIncxr(String incxr) {
        this.incxr = incxr == null ? null : incxr.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getLoctype() {
        return loctype;
    }

    public void setLoctype(String loctype) {
        this.loctype = loctype == null ? null : loctype.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getOutcxr() {
        return outcxr;
    }

    public void setOutcxr(String outcxr) {
        this.outcxr = outcxr == null ? null : outcxr.trim();
    }

    public String getIoind() {
        return ioind;
    }

    public void setIoind(String ioind) {
        this.ioind = ioind == null ? null : ioind.trim();
    }

    public String getChgind() {
        return chgind;
    }

    public void setChgind(String chgind) {
        this.chgind = chgind == null ? null : chgind.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }
}