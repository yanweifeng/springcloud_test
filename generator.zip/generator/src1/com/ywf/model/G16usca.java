package com.ywf.model;

import java.util.Date;

public class G16usca {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String areacd;

    private String type;

    private String cxr;

    private String filler;

    private Date effdate;

    private Date disdate;

    private Date stamp;

    private String privateTag;

    private String filler1;

    private String papertariff;

    private String ntanum;

    private String dotnum;

    private String fcast;

    private String fctariffcd;

    private String fctariffnum;

    private String frast;

    private String frtariffcd;

    private String frtariffnum;

    private String grast;

    private String grtariffcd;

    private String grtariffnum;

    private String ffamp;

    private String ffast;

    private String fftariffcd;

    private String fftariffnum;

    private String filler2;

    private String rtg1ast;

    private String rtg1tariffcd;

    private String rtg1tariffnum;

    private String filler3;

    private String rtg2ast;

    private String rtg2tariffcd;

    private String rtg2tariffnum;

    private String filler4;

    private Date createtime;

    private Date updatetime;

    private String ffast2;

    private String fftariffcd2;

    private String fftariffnum2;

    private String filler5;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAreacd() {
        return areacd;
    }

    public void setAreacd(String areacd) {
        this.areacd = areacd == null ? null : areacd.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public Date getStamp() {
        return stamp;
    }

    public void setStamp(Date stamp) {
        this.stamp = stamp;
    }

    public String getPrivateTag() {
        return privateTag;
    }

    public void setPrivateTag(String privateTag) {
        this.privateTag = privateTag == null ? null : privateTag.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getPapertariff() {
        return papertariff;
    }

    public void setPapertariff(String papertariff) {
        this.papertariff = papertariff == null ? null : papertariff.trim();
    }

    public String getNtanum() {
        return ntanum;
    }

    public void setNtanum(String ntanum) {
        this.ntanum = ntanum == null ? null : ntanum.trim();
    }

    public String getDotnum() {
        return dotnum;
    }

    public void setDotnum(String dotnum) {
        this.dotnum = dotnum == null ? null : dotnum.trim();
    }

    public String getFcast() {
        return fcast;
    }

    public void setFcast(String fcast) {
        this.fcast = fcast == null ? null : fcast.trim();
    }

    public String getFctariffcd() {
        return fctariffcd;
    }

    public void setFctariffcd(String fctariffcd) {
        this.fctariffcd = fctariffcd == null ? null : fctariffcd.trim();
    }

    public String getFctariffnum() {
        return fctariffnum;
    }

    public void setFctariffnum(String fctariffnum) {
        this.fctariffnum = fctariffnum == null ? null : fctariffnum.trim();
    }

    public String getFrast() {
        return frast;
    }

    public void setFrast(String frast) {
        this.frast = frast == null ? null : frast.trim();
    }

    public String getFrtariffcd() {
        return frtariffcd;
    }

    public void setFrtariffcd(String frtariffcd) {
        this.frtariffcd = frtariffcd == null ? null : frtariffcd.trim();
    }

    public String getFrtariffnum() {
        return frtariffnum;
    }

    public void setFrtariffnum(String frtariffnum) {
        this.frtariffnum = frtariffnum == null ? null : frtariffnum.trim();
    }

    public String getGrast() {
        return grast;
    }

    public void setGrast(String grast) {
        this.grast = grast == null ? null : grast.trim();
    }

    public String getGrtariffcd() {
        return grtariffcd;
    }

    public void setGrtariffcd(String grtariffcd) {
        this.grtariffcd = grtariffcd == null ? null : grtariffcd.trim();
    }

    public String getGrtariffnum() {
        return grtariffnum;
    }

    public void setGrtariffnum(String grtariffnum) {
        this.grtariffnum = grtariffnum == null ? null : grtariffnum.trim();
    }

    public String getFfamp() {
        return ffamp;
    }

    public void setFfamp(String ffamp) {
        this.ffamp = ffamp == null ? null : ffamp.trim();
    }

    public String getFfast() {
        return ffast;
    }

    public void setFfast(String ffast) {
        this.ffast = ffast == null ? null : ffast.trim();
    }

    public String getFftariffcd() {
        return fftariffcd;
    }

    public void setFftariffcd(String fftariffcd) {
        this.fftariffcd = fftariffcd == null ? null : fftariffcd.trim();
    }

    public String getFftariffnum() {
        return fftariffnum;
    }

    public void setFftariffnum(String fftariffnum) {
        this.fftariffnum = fftariffnum == null ? null : fftariffnum.trim();
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public String getRtg1ast() {
        return rtg1ast;
    }

    public void setRtg1ast(String rtg1ast) {
        this.rtg1ast = rtg1ast == null ? null : rtg1ast.trim();
    }

    public String getRtg1tariffcd() {
        return rtg1tariffcd;
    }

    public void setRtg1tariffcd(String rtg1tariffcd) {
        this.rtg1tariffcd = rtg1tariffcd == null ? null : rtg1tariffcd.trim();
    }

    public String getRtg1tariffnum() {
        return rtg1tariffnum;
    }

    public void setRtg1tariffnum(String rtg1tariffnum) {
        this.rtg1tariffnum = rtg1tariffnum == null ? null : rtg1tariffnum.trim();
    }

    public String getFiller3() {
        return filler3;
    }

    public void setFiller3(String filler3) {
        this.filler3 = filler3 == null ? null : filler3.trim();
    }

    public String getRtg2ast() {
        return rtg2ast;
    }

    public void setRtg2ast(String rtg2ast) {
        this.rtg2ast = rtg2ast == null ? null : rtg2ast.trim();
    }

    public String getRtg2tariffcd() {
        return rtg2tariffcd;
    }

    public void setRtg2tariffcd(String rtg2tariffcd) {
        this.rtg2tariffcd = rtg2tariffcd == null ? null : rtg2tariffcd.trim();
    }

    public String getRtg2tariffnum() {
        return rtg2tariffnum;
    }

    public void setRtg2tariffnum(String rtg2tariffnum) {
        this.rtg2tariffnum = rtg2tariffnum == null ? null : rtg2tariffnum.trim();
    }

    public String getFiller4() {
        return filler4;
    }

    public void setFiller4(String filler4) {
        this.filler4 = filler4 == null ? null : filler4.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getFfast2() {
        return ffast2;
    }

    public void setFfast2(String ffast2) {
        this.ffast2 = ffast2 == null ? null : ffast2.trim();
    }

    public String getFftariffcd2() {
        return fftariffcd2;
    }

    public void setFftariffcd2(String fftariffcd2) {
        this.fftariffcd2 = fftariffcd2 == null ? null : fftariffcd2.trim();
    }

    public String getFftariffnum2() {
        return fftariffnum2;
    }

    public void setFftariffnum2(String fftariffnum2) {
        this.fftariffnum2 = fftariffnum2 == null ? null : fftariffnum2.trim();
    }

    public String getFiller5() {
        return filler5;
    }

    public void setFiller5(String filler5) {
        this.filler5 = filler5 == null ? null : filler5.trim();
    }
}