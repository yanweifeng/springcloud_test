package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat008 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String minstops;

    private String maxstops;

    private String outstops;

    private String instops;

    private String stporind;

    private String filler1;

    private String ojind;

    private String ct2ind;

    private String ct2plus;

    private String gtwyperm;

    private String gtwgeotb;

    private Integer mintime;

    private String minunit;

    private Integer maxtime;

    private String maxunit;

    private Integer samestp;

    private Integer sametrt;

    private Integer samecnx;

    private String sametbl;

    private String chg1appl;

    private String filler2;

    private String chg1numf;

    private BigDecimal chg1amtf;

    private String chg1numa;

    private BigDecimal chg1amta;

    private String chg1cur;

    private Integer chg1dec;

    private String filler3;

    private BigDecimal chg2amtf;

    private String filler4;

    private BigDecimal chg2amta;

    private String chg2cur;

    private Integer chg2dec;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getMinstops() {
        return minstops;
    }

    public void setMinstops(String minstops) {
        this.minstops = minstops == null ? null : minstops.trim();
    }

    public String getMaxstops() {
        return maxstops;
    }

    public void setMaxstops(String maxstops) {
        this.maxstops = maxstops == null ? null : maxstops.trim();
    }

    public String getOutstops() {
        return outstops;
    }

    public void setOutstops(String outstops) {
        this.outstops = outstops == null ? null : outstops.trim();
    }

    public String getInstops() {
        return instops;
    }

    public void setInstops(String instops) {
        this.instops = instops == null ? null : instops.trim();
    }

    public String getStporind() {
        return stporind;
    }

    public void setStporind(String stporind) {
        this.stporind = stporind == null ? null : stporind.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getOjind() {
        return ojind;
    }

    public void setOjind(String ojind) {
        this.ojind = ojind == null ? null : ojind.trim();
    }

    public String getCt2ind() {
        return ct2ind;
    }

    public void setCt2ind(String ct2ind) {
        this.ct2ind = ct2ind == null ? null : ct2ind.trim();
    }

    public String getCt2plus() {
        return ct2plus;
    }

    public void setCt2plus(String ct2plus) {
        this.ct2plus = ct2plus == null ? null : ct2plus.trim();
    }

    public String getGtwyperm() {
        return gtwyperm;
    }

    public void setGtwyperm(String gtwyperm) {
        this.gtwyperm = gtwyperm == null ? null : gtwyperm.trim();
    }

    public String getGtwgeotb() {
        return gtwgeotb;
    }

    public void setGtwgeotb(String gtwgeotb) {
        this.gtwgeotb = gtwgeotb == null ? null : gtwgeotb.trim();
    }

    public Integer getMintime() {
        return mintime;
    }

    public void setMintime(Integer mintime) {
        this.mintime = mintime;
    }

    public String getMinunit() {
        return minunit;
    }

    public void setMinunit(String minunit) {
        this.minunit = minunit == null ? null : minunit.trim();
    }

    public Integer getMaxtime() {
        return maxtime;
    }

    public void setMaxtime(Integer maxtime) {
        this.maxtime = maxtime;
    }

    public String getMaxunit() {
        return maxunit;
    }

    public void setMaxunit(String maxunit) {
        this.maxunit = maxunit == null ? null : maxunit.trim();
    }

    public Integer getSamestp() {
        return samestp;
    }

    public void setSamestp(Integer samestp) {
        this.samestp = samestp;
    }

    public Integer getSametrt() {
        return sametrt;
    }

    public void setSametrt(Integer sametrt) {
        this.sametrt = sametrt;
    }

    public Integer getSamecnx() {
        return samecnx;
    }

    public void setSamecnx(Integer samecnx) {
        this.samecnx = samecnx;
    }

    public String getSametbl() {
        return sametbl;
    }

    public void setSametbl(String sametbl) {
        this.sametbl = sametbl == null ? null : sametbl.trim();
    }

    public String getChg1appl() {
        return chg1appl;
    }

    public void setChg1appl(String chg1appl) {
        this.chg1appl = chg1appl == null ? null : chg1appl.trim();
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public String getChg1numf() {
        return chg1numf;
    }

    public void setChg1numf(String chg1numf) {
        this.chg1numf = chg1numf == null ? null : chg1numf.trim();
    }

    public BigDecimal getChg1amtf() {
        return chg1amtf;
    }

    public void setChg1amtf(BigDecimal chg1amtf) {
        this.chg1amtf = chg1amtf;
    }

    public String getChg1numa() {
        return chg1numa;
    }

    public void setChg1numa(String chg1numa) {
        this.chg1numa = chg1numa == null ? null : chg1numa.trim();
    }

    public BigDecimal getChg1amta() {
        return chg1amta;
    }

    public void setChg1amta(BigDecimal chg1amta) {
        this.chg1amta = chg1amta;
    }

    public String getChg1cur() {
        return chg1cur;
    }

    public void setChg1cur(String chg1cur) {
        this.chg1cur = chg1cur == null ? null : chg1cur.trim();
    }

    public Integer getChg1dec() {
        return chg1dec;
    }

    public void setChg1dec(Integer chg1dec) {
        this.chg1dec = chg1dec;
    }

    public String getFiller3() {
        return filler3;
    }

    public void setFiller3(String filler3) {
        this.filler3 = filler3 == null ? null : filler3.trim();
    }

    public BigDecimal getChg2amtf() {
        return chg2amtf;
    }

    public void setChg2amtf(BigDecimal chg2amtf) {
        this.chg2amtf = chg2amtf;
    }

    public String getFiller4() {
        return filler4;
    }

    public void setFiller4(String filler4) {
        this.filler4 = filler4 == null ? null : filler4.trim();
    }

    public BigDecimal getChg2amta() {
        return chg2amta;
    }

    public void setChg2amta(BigDecimal chg2amta) {
        this.chg2amta = chg2amta;
    }

    public String getChg2cur() {
        return chg2cur;
    }

    public void setChg2cur(String chg2cur) {
        this.chg2cur = chg2cur == null ? null : chg2cur.trim();
    }

    public Integer getChg2dec() {
        return chg2dec;
    }

    public void setChg2dec(Integer chg2dec) {
        this.chg2dec = chg2dec;
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}