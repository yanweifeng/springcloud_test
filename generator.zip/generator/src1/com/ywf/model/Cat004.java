package com.ywf.model;

import java.util.Date;

public class Cat004 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String fltappl;

    private String fltnum1;

    private String cxr1;

    private String cxrtblno1;

    private String relind12;

    private String fltnum2;

    private String cxr2;

    private String cxrtblno2;

    private String relind23;

    private String fltnum3;

    private String cxr3;

    private String dayweek;

    private String tvldirind;

    private String tvlappl;

    private String tvlloc;

    private String betviatbl;

    private String andviatbl;

    private String viaind;

    private String viageotbl;

    private String hidden;

    private String fltnon;

    private String fltdir;

    private String fltmul;

    private String fltone;

    private String fltonl;

    private String fltint;

    private String fltsame;

    private String eqpapp;

    private String eqpcode;

    private String reserved;

    private String datetblno;

    private String txttblno;

    private String unavail;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getFltappl() {
        return fltappl;
    }

    public void setFltappl(String fltappl) {
        this.fltappl = fltappl == null ? null : fltappl.trim();
    }

    public String getFltnum1() {
        return fltnum1;
    }

    public void setFltnum1(String fltnum1) {
        this.fltnum1 = fltnum1 == null ? null : fltnum1.trim();
    }

    public String getCxr1() {
        return cxr1;
    }

    public void setCxr1(String cxr1) {
        this.cxr1 = cxr1 == null ? null : cxr1.trim();
    }

    public String getCxrtblno1() {
        return cxrtblno1;
    }

    public void setCxrtblno1(String cxrtblno1) {
        this.cxrtblno1 = cxrtblno1 == null ? null : cxrtblno1.trim();
    }

    public String getRelind12() {
        return relind12;
    }

    public void setRelind12(String relind12) {
        this.relind12 = relind12 == null ? null : relind12.trim();
    }

    public String getFltnum2() {
        return fltnum2;
    }

    public void setFltnum2(String fltnum2) {
        this.fltnum2 = fltnum2 == null ? null : fltnum2.trim();
    }

    public String getCxr2() {
        return cxr2;
    }

    public void setCxr2(String cxr2) {
        this.cxr2 = cxr2 == null ? null : cxr2.trim();
    }

    public String getCxrtblno2() {
        return cxrtblno2;
    }

    public void setCxrtblno2(String cxrtblno2) {
        this.cxrtblno2 = cxrtblno2 == null ? null : cxrtblno2.trim();
    }

    public String getRelind23() {
        return relind23;
    }

    public void setRelind23(String relind23) {
        this.relind23 = relind23 == null ? null : relind23.trim();
    }

    public String getFltnum3() {
        return fltnum3;
    }

    public void setFltnum3(String fltnum3) {
        this.fltnum3 = fltnum3 == null ? null : fltnum3.trim();
    }

    public String getCxr3() {
        return cxr3;
    }

    public void setCxr3(String cxr3) {
        this.cxr3 = cxr3 == null ? null : cxr3.trim();
    }

    public String getDayweek() {
        return dayweek;
    }

    public void setDayweek(String dayweek) {
        this.dayweek = dayweek == null ? null : dayweek.trim();
    }

    public String getTvldirind() {
        return tvldirind;
    }

    public void setTvldirind(String tvldirind) {
        this.tvldirind = tvldirind == null ? null : tvldirind.trim();
    }

    public String getTvlappl() {
        return tvlappl;
    }

    public void setTvlappl(String tvlappl) {
        this.tvlappl = tvlappl == null ? null : tvlappl.trim();
    }

    public String getTvlloc() {
        return tvlloc;
    }

    public void setTvlloc(String tvlloc) {
        this.tvlloc = tvlloc == null ? null : tvlloc.trim();
    }

    public String getBetviatbl() {
        return betviatbl;
    }

    public void setBetviatbl(String betviatbl) {
        this.betviatbl = betviatbl == null ? null : betviatbl.trim();
    }

    public String getAndviatbl() {
        return andviatbl;
    }

    public void setAndviatbl(String andviatbl) {
        this.andviatbl = andviatbl == null ? null : andviatbl.trim();
    }

    public String getViaind() {
        return viaind;
    }

    public void setViaind(String viaind) {
        this.viaind = viaind == null ? null : viaind.trim();
    }

    public String getViageotbl() {
        return viageotbl;
    }

    public void setViageotbl(String viageotbl) {
        this.viageotbl = viageotbl == null ? null : viageotbl.trim();
    }

    public String getHidden() {
        return hidden;
    }

    public void setHidden(String hidden) {
        this.hidden = hidden == null ? null : hidden.trim();
    }

    public String getFltnon() {
        return fltnon;
    }

    public void setFltnon(String fltnon) {
        this.fltnon = fltnon == null ? null : fltnon.trim();
    }

    public String getFltdir() {
        return fltdir;
    }

    public void setFltdir(String fltdir) {
        this.fltdir = fltdir == null ? null : fltdir.trim();
    }

    public String getFltmul() {
        return fltmul;
    }

    public void setFltmul(String fltmul) {
        this.fltmul = fltmul == null ? null : fltmul.trim();
    }

    public String getFltone() {
        return fltone;
    }

    public void setFltone(String fltone) {
        this.fltone = fltone == null ? null : fltone.trim();
    }

    public String getFltonl() {
        return fltonl;
    }

    public void setFltonl(String fltonl) {
        this.fltonl = fltonl == null ? null : fltonl.trim();
    }

    public String getFltint() {
        return fltint;
    }

    public void setFltint(String fltint) {
        this.fltint = fltint == null ? null : fltint.trim();
    }

    public String getFltsame() {
        return fltsame;
    }

    public void setFltsame(String fltsame) {
        this.fltsame = fltsame == null ? null : fltsame.trim();
    }

    public String getEqpapp() {
        return eqpapp;
    }

    public void setEqpapp(String eqpapp) {
        this.eqpapp = eqpapp == null ? null : eqpapp.trim();
    }

    public String getEqpcode() {
        return eqpcode;
    }

    public void setEqpcode(String eqpcode) {
        this.eqpcode = eqpcode == null ? null : eqpcode.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public String getDatetblno() {
        return datetblno;
    }

    public void setDatetblno(String datetblno) {
        this.datetblno = datetblno == null ? null : datetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}