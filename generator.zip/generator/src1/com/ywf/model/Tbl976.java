package com.ywf.model;

import java.util.Date;

public class Tbl976 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer index;

    private Long deleteId;

    private String restr;

    private String oD;

    private String farebreakloctype;

    private String farebreakloccode;

    private String surfaceloctype;

    private String surfaceloccode;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getRestr() {
        return restr;
    }

    public void setRestr(String restr) {
        this.restr = restr == null ? null : restr.trim();
    }

    public String getoD() {
        return oD;
    }

    public void setoD(String oD) {
        this.oD = oD == null ? null : oD.trim();
    }

    public String getFarebreakloctype() {
        return farebreakloctype;
    }

    public void setFarebreakloctype(String farebreakloctype) {
        this.farebreakloctype = farebreakloctype == null ? null : farebreakloctype.trim();
    }

    public String getFarebreakloccode() {
        return farebreakloccode;
    }

    public void setFarebreakloccode(String farebreakloccode) {
        this.farebreakloccode = farebreakloccode == null ? null : farebreakloccode.trim();
    }

    public String getSurfaceloctype() {
        return surfaceloctype;
    }

    public void setSurfaceloctype(String surfaceloctype) {
        this.surfaceloctype = surfaceloctype == null ? null : surfaceloctype.trim();
    }

    public String getSurfaceloccode() {
        return surfaceloccode;
    }

    public void setSurfaceloccode(String surfaceloccode) {
        this.surfaceloccode = surfaceloccode == null ? null : surfaceloccode.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}