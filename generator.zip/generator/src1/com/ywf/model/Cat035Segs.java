package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat035Segs {
    private Long id;

    private String tblno;

    private Long createId;

    private String coupon;

    private String type;

    private String tourcode;

    private String tktdesig;

    private String reserved1;

    private String tktdata;

    private String owrt;

    private String globalind;

    private String ruletar;

    private String carrier;

    private String ruleno;

    private String farefam;

    private String faretype;

    private String seasontype;

    private String dowtype;

    private String betwcity1;

    private String betwcity2;

    private String fbtext;

    private BigDecimal fbamt;

    private String fbcur;

    private Integer fbdec;

    private String reserved2;

    private Date createtime;

    private Date updatetime;

    private Integer segorder;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getCoupon() {
        return coupon;
    }

    public void setCoupon(String coupon) {
        this.coupon = coupon == null ? null : coupon.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getTourcode() {
        return tourcode;
    }

    public void setTourcode(String tourcode) {
        this.tourcode = tourcode == null ? null : tourcode.trim();
    }

    public String getTktdesig() {
        return tktdesig;
    }

    public void setTktdesig(String tktdesig) {
        this.tktdesig = tktdesig == null ? null : tktdesig.trim();
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1 == null ? null : reserved1.trim();
    }

    public String getTktdata() {
        return tktdata;
    }

    public void setTktdata(String tktdata) {
        this.tktdata = tktdata == null ? null : tktdata.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getGlobalind() {
        return globalind;
    }

    public void setGlobalind(String globalind) {
        this.globalind = globalind == null ? null : globalind.trim();
    }

    public String getRuletar() {
        return ruletar;
    }

    public void setRuletar(String ruletar) {
        this.ruletar = ruletar == null ? null : ruletar.trim();
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getFarefam() {
        return farefam;
    }

    public void setFarefam(String farefam) {
        this.farefam = farefam == null ? null : farefam.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getSeasontype() {
        return seasontype;
    }

    public void setSeasontype(String seasontype) {
        this.seasontype = seasontype == null ? null : seasontype.trim();
    }

    public String getDowtype() {
        return dowtype;
    }

    public void setDowtype(String dowtype) {
        this.dowtype = dowtype == null ? null : dowtype.trim();
    }

    public String getBetwcity1() {
        return betwcity1;
    }

    public void setBetwcity1(String betwcity1) {
        this.betwcity1 = betwcity1 == null ? null : betwcity1.trim();
    }

    public String getBetwcity2() {
        return betwcity2;
    }

    public void setBetwcity2(String betwcity2) {
        this.betwcity2 = betwcity2 == null ? null : betwcity2.trim();
    }

    public String getFbtext() {
        return fbtext;
    }

    public void setFbtext(String fbtext) {
        this.fbtext = fbtext == null ? null : fbtext.trim();
    }

    public BigDecimal getFbamt() {
        return fbamt;
    }

    public void setFbamt(BigDecimal fbamt) {
        this.fbamt = fbamt;
    }

    public String getFbcur() {
        return fbcur;
    }

    public void setFbcur(String fbcur) {
        this.fbcur = fbcur == null ? null : fbcur.trim();
    }

    public Integer getFbdec() {
        return fbdec;
    }

    public void setFbdec(Integer fbdec) {
        this.fbdec = fbdec;
    }

    public String getReserved2() {
        return reserved2;
    }

    public void setReserved2(String reserved2) {
        this.reserved2 = reserved2 == null ? null : reserved2.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }
}