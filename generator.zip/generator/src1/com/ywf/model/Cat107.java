package com.ywf.model;

import java.util.Date;

public class Cat107 {
    private Long id;

    private String tblno;

    private Long createId;

    private Integer segIndex;

    private Long deleteId;

    private String prime;

    private String def;

    private String appl;

    private String same;

    private String tarno;

    private String ruleno;

    private String global;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegIndex() {
        return segIndex;
    }

    public void setSegIndex(Integer segIndex) {
        this.segIndex = segIndex;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getPrime() {
        return prime;
    }

    public void setPrime(String prime) {
        this.prime = prime == null ? null : prime.trim();
    }

    public String getDef() {
        return def;
    }

    public void setDef(String def) {
        this.def = def == null ? null : def.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getSame() {
        return same;
    }

    public void setSame(String same) {
        this.same = same == null ? null : same.trim();
    }

    public String getTarno() {
        return tarno;
    }

    public void setTarno(String tarno) {
        this.tarno = tarno == null ? null : tarno.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getGlobal() {
        return global;
    }

    public void setGlobal(String global) {
        this.global = global == null ? null : global.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}