package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Cat01922 {
    private Long id;

    private String catno;

    private String tableno;

    private Long createId;

    private Long deleteId;

    private String noappl;

    private String psgrtype;

    private String psgrtypeId;

    private Integer minage;

    private Integer maxage;

    private Integer occfirst;

    private Integer occlast;

    private String fareind;

    private String percent;

    private String baseowrt;

    private String basetype;

    private String basecode;

    private String baseappl;

    private String basebkcd;

    private String city1;

    private String city2;

    private BigDecimal fareamt1;

    private String cur1;

    private Integer dec1;

    private BigDecimal fareamt2;

    private String cur2;

    private Integer dec2;

    private String fareowrt;

    private String fcl;

    private String farebkcd;

    private String tktcode;

    private String tcm;

    private String tktdesig;

    private String tdm;

    private String dtetblno;

    private String txttblno;

    private String unavail;

    private String eor;

    private String secall;

    private String secout;

    private String secone;

    private String cmpt;

    private String rule;

    private String geotblno;

    private String accappl;

    private String fbind;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    private String identification;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCatno() {
        return catno;
    }

    public void setCatno(String catno) {
        this.catno = catno == null ? null : catno.trim();
    }

    public String getTableno() {
        return tableno;
    }

    public void setTableno(String tableno) {
        this.tableno = tableno == null ? null : tableno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getNoappl() {
        return noappl;
    }

    public void setNoappl(String noappl) {
        this.noappl = noappl == null ? null : noappl.trim();
    }

    public String getPsgrtype() {
        return psgrtype;
    }

    public void setPsgrtype(String psgrtype) {
        this.psgrtype = psgrtype == null ? null : psgrtype.trim();
    }

    public String getPsgrtypeId() {
        return psgrtypeId;
    }

    public void setPsgrtypeId(String psgrtypeId) {
        this.psgrtypeId = psgrtypeId == null ? null : psgrtypeId.trim();
    }

    public Integer getMinage() {
        return minage;
    }

    public void setMinage(Integer minage) {
        this.minage = minage;
    }

    public Integer getMaxage() {
        return maxage;
    }

    public void setMaxage(Integer maxage) {
        this.maxage = maxage;
    }

    public Integer getOccfirst() {
        return occfirst;
    }

    public void setOccfirst(Integer occfirst) {
        this.occfirst = occfirst;
    }

    public Integer getOcclast() {
        return occlast;
    }

    public void setOcclast(Integer occlast) {
        this.occlast = occlast;
    }

    public String getFareind() {
        return fareind;
    }

    public void setFareind(String fareind) {
        this.fareind = fareind == null ? null : fareind.trim();
    }

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent == null ? null : percent.trim();
    }

    public String getBaseowrt() {
        return baseowrt;
    }

    public void setBaseowrt(String baseowrt) {
        this.baseowrt = baseowrt == null ? null : baseowrt.trim();
    }

    public String getBasetype() {
        return basetype;
    }

    public void setBasetype(String basetype) {
        this.basetype = basetype == null ? null : basetype.trim();
    }

    public String getBasecode() {
        return basecode;
    }

    public void setBasecode(String basecode) {
        this.basecode = basecode == null ? null : basecode.trim();
    }

    public String getBaseappl() {
        return baseappl;
    }

    public void setBaseappl(String baseappl) {
        this.baseappl = baseappl == null ? null : baseappl.trim();
    }

    public String getBasebkcd() {
        return basebkcd;
    }

    public void setBasebkcd(String basebkcd) {
        this.basebkcd = basebkcd == null ? null : basebkcd.trim();
    }

    public String getCity1() {
        return city1;
    }

    public void setCity1(String city1) {
        this.city1 = city1 == null ? null : city1.trim();
    }

    public String getCity2() {
        return city2;
    }

    public void setCity2(String city2) {
        this.city2 = city2 == null ? null : city2.trim();
    }

    public BigDecimal getFareamt1() {
        return fareamt1;
    }

    public void setFareamt1(BigDecimal fareamt1) {
        this.fareamt1 = fareamt1;
    }

    public String getCur1() {
        return cur1;
    }

    public void setCur1(String cur1) {
        this.cur1 = cur1 == null ? null : cur1.trim();
    }

    public Integer getDec1() {
        return dec1;
    }

    public void setDec1(Integer dec1) {
        this.dec1 = dec1;
    }

    public BigDecimal getFareamt2() {
        return fareamt2;
    }

    public void setFareamt2(BigDecimal fareamt2) {
        this.fareamt2 = fareamt2;
    }

    public String getCur2() {
        return cur2;
    }

    public void setCur2(String cur2) {
        this.cur2 = cur2 == null ? null : cur2.trim();
    }

    public Integer getDec2() {
        return dec2;
    }

    public void setDec2(Integer dec2) {
        this.dec2 = dec2;
    }

    public String getFareowrt() {
        return fareowrt;
    }

    public void setFareowrt(String fareowrt) {
        this.fareowrt = fareowrt == null ? null : fareowrt.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getFarebkcd() {
        return farebkcd;
    }

    public void setFarebkcd(String farebkcd) {
        this.farebkcd = farebkcd == null ? null : farebkcd.trim();
    }

    public String getTktcode() {
        return tktcode;
    }

    public void setTktcode(String tktcode) {
        this.tktcode = tktcode == null ? null : tktcode.trim();
    }

    public String getTcm() {
        return tcm;
    }

    public void setTcm(String tcm) {
        this.tcm = tcm == null ? null : tcm.trim();
    }

    public String getTktdesig() {
        return tktdesig;
    }

    public void setTktdesig(String tktdesig) {
        this.tktdesig = tktdesig == null ? null : tktdesig.trim();
    }

    public String getTdm() {
        return tdm;
    }

    public void setTdm(String tdm) {
        this.tdm = tdm == null ? null : tdm.trim();
    }

    public String getDtetblno() {
        return dtetblno;
    }

    public void setDtetblno(String dtetblno) {
        this.dtetblno = dtetblno == null ? null : dtetblno.trim();
    }

    public String getTxttblno() {
        return txttblno;
    }

    public void setTxttblno(String txttblno) {
        this.txttblno = txttblno == null ? null : txttblno.trim();
    }

    public String getUnavail() {
        return unavail;
    }

    public void setUnavail(String unavail) {
        this.unavail = unavail == null ? null : unavail.trim();
    }

    public String getEor() {
        return eor;
    }

    public void setEor(String eor) {
        this.eor = eor == null ? null : eor.trim();
    }

    public String getSecall() {
        return secall;
    }

    public void setSecall(String secall) {
        this.secall = secall == null ? null : secall.trim();
    }

    public String getSecout() {
        return secout;
    }

    public void setSecout(String secout) {
        this.secout = secout == null ? null : secout.trim();
    }

    public String getSecone() {
        return secone;
    }

    public void setSecone(String secone) {
        this.secone = secone == null ? null : secone.trim();
    }

    public String getCmpt() {
        return cmpt;
    }

    public void setCmpt(String cmpt) {
        this.cmpt = cmpt == null ? null : cmpt.trim();
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule == null ? null : rule.trim();
    }

    public String getGeotblno() {
        return geotblno;
    }

    public void setGeotblno(String geotblno) {
        this.geotblno = geotblno == null ? null : geotblno.trim();
    }

    public String getAccappl() {
        return accappl;
    }

    public void setAccappl(String accappl) {
        this.accappl = accappl == null ? null : accappl.trim();
    }

    public String getFbind() {
        return fbind;
    }

    public void setFbind(String fbind) {
        this.fbind = fbind == null ? null : fbind.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification == null ? null : identification.trim();
    }
}