package com.ywf.dao;

import com.ywf.model.Cat01922;

public interface Cat01922Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat01922 record);

    int insertSelective(Cat01922 record);

    Cat01922 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat01922 record);

    int updateByPrimaryKey(Cat01922 record);
}