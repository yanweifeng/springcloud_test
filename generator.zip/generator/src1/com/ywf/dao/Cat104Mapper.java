package com.ywf.dao;

import com.ywf.model.Cat104;

public interface Cat104Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat104 record);

    int insertSelective(Cat104 record);

    Cat104 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat104 record);

    int updateByPrimaryKey(Cat104 record);
}