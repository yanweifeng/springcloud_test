package com.ywf.dao;

import com.ywf.model.Tbl994;

public interface Tbl994Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl994 record);

    int insertSelective(Tbl994 record);

    Tbl994 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl994 record);

    int updateByPrimaryKey(Tbl994 record);
}