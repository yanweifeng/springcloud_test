package com.ywf.dao;

import com.ywf.model.RollBackLogStep;

public interface RollBackLogStepMapper {
    int deleteByPrimaryKey(Long id);

    int insert(RollBackLogStep record);

    int insertSelective(RollBackLogStep record);

    RollBackLogStep selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RollBackLogStep record);

    int updateByPrimaryKey(RollBackLogStep record);
}