package com.ywf.dao;

import com.ywf.model.RoutingType4;

public interface RoutingType4Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(RoutingType4 record);

    int insertSelective(RoutingType4 record);

    RoutingType4 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RoutingType4 record);

    int updateByPrimaryKey(RoutingType4 record);
}