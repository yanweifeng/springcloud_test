package com.ywf.dao;

import com.ywf.model.Cat101;

public interface Cat101Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat101 record);

    int insertSelective(Cat101 record);

    Cat101 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat101 record);

    int updateByPrimaryKey(Cat101 record);
}