package com.ywf.dao;

import com.ywf.model.Cat025;

public interface Cat025Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat025 record);

    int insertSelective(Cat025 record);

    Cat025 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat025 record);

    int updateByPrimaryKey(Cat025 record);
}