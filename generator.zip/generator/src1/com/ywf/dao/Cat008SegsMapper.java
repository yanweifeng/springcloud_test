package com.ywf.dao;

import com.ywf.model.Cat008Segs;

public interface Cat008SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat008Segs record);

    int insertSelective(Cat008Segs record);

    Cat008Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat008Segs record);

    int updateByPrimaryKey(Cat008Segs record);
}