package com.ywf.dao;

import com.ywf.model.Cat109;

public interface Cat109Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat109 record);

    int insertSelective(Cat109 record);

    Cat109 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat109 record);

    int updateByPrimaryKey(Cat109 record);
}