package com.ywf.dao;

import com.ywf.model.Cat102;

public interface Cat102Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat102 record);

    int insertSelective(Cat102 record);

    Cat102 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat102 record);

    int updateByPrimaryKey(Cat102 record);
}