package com.ywf.dao;

import com.ywf.model.P06Segs;

public interface P06SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(P06Segs record);

    int insertSelective(P06Segs record);

    P06Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(P06Segs record);

    int updateByPrimaryKey(P06Segs record);
}