package com.ywf.dao;

import com.ywf.model.Cat001;

public interface Cat001Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat001 record);

    int insertSelective(Cat001 record);

    Cat001 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat001 record);

    int updateByPrimaryKey(Cat001 record);
}