package com.ywf.dao;

import com.ywf.model.Tbl986;

public interface Tbl986Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl986 record);

    int insertSelective(Tbl986 record);

    Tbl986 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl986 record);

    int updateByPrimaryKey(Tbl986 record);
}