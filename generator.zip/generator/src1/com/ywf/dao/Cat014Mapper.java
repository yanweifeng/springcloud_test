package com.ywf.dao;

import com.ywf.model.Cat014;

public interface Cat014Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat014 record);

    int insertSelective(Cat014 record);

    Cat014 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat014 record);

    int updateByPrimaryKey(Cat014 record);
}