package com.ywf.dao;

import com.ywf.model.Cat004;

public interface Cat004Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat004 record);

    int insertSelective(Cat004 record);

    Cat004 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat004 record);

    int updateByPrimaryKey(Cat004 record);
}