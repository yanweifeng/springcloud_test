package com.ywf.dao;

import com.ywf.model.Tbl993;

public interface Tbl993Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl993 record);

    int insertSelective(Tbl993 record);

    Tbl993 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl993 record);

    int updateByPrimaryKey(Tbl993 record);
}