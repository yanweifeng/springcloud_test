package com.ywf.dao;

import com.ywf.model.Cat016;

public interface Cat016Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat016 record);

    int insertSelective(Cat016 record);

    Cat016 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat016 record);

    int updateByPrimaryKey(Cat016 record);
}