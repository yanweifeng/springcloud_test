package com.ywf.dao;

import com.ywf.model.Cat107;

public interface Cat107Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat107 record);

    int insertSelective(Cat107 record);

    Cat107 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat107 record);

    int updateByPrimaryKey(Cat107 record);
}