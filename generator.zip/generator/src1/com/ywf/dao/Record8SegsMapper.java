package com.ywf.dao;

import com.ywf.model.Record8Segs;

public interface Record8SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record8Segs record);

    int insertSelective(Record8Segs record);

    Record8Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record8Segs record);

    int updateByPrimaryKey(Record8Segs record);
}