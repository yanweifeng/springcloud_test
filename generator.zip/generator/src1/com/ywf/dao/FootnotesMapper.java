package com.ywf.dao;

import com.ywf.model.Footnotes;

public interface FootnotesMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Footnotes record);

    int insertSelective(Footnotes record);

    Footnotes selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Footnotes record);

    int updateByPrimaryKey(Footnotes record);
}