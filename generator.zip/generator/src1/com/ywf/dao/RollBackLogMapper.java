package com.ywf.dao;

import com.ywf.model.Rollbacklog;

public interface RollbacklogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Rollbacklog record);

    int insertSelective(Rollbacklog record);

    Rollbacklog selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Rollbacklog record);

    int updateByPrimaryKey(Rollbacklog record);
}