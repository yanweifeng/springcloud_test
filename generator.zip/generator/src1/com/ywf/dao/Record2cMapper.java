package com.ywf.dao;

import com.ywf.model.Record2c;

public interface Record2cMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2c record);

    int insertSelective(Record2c record);

    Record2c selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2c record);

    int updateByPrimaryKey(Record2c record);
}