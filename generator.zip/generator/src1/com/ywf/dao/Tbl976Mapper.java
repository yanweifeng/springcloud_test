package com.ywf.dao;

import com.ywf.model.Tbl976;

public interface Tbl976Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl976 record);

    int insertSelective(Tbl976 record);

    Tbl976 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl976 record);

    int updateByPrimaryKey(Tbl976 record);
}