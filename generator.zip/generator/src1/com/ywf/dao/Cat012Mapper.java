package com.ywf.dao;

import com.ywf.model.Cat012;

public interface Cat012Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat012 record);

    int insertSelective(Cat012 record);

    Cat012 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat012 record);

    int updateByPrimaryKey(Cat012 record);
}