package com.ywf.dao;

import com.ywf.model.Tbl978;

public interface Tbl978Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl978 record);

    int insertSelective(Tbl978 record);

    Tbl978 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl978 record);

    int updateByPrimaryKey(Tbl978 record);
}