package com.ywf.dao;

import com.ywf.model.Cat027;

public interface Cat027Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat027 record);

    int insertSelective(Cat027 record);

    Cat027 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat027 record);

    int updateByPrimaryKey(Cat027 record);
}