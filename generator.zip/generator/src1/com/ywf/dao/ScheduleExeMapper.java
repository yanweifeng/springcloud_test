package com.ywf.dao;

import com.ywf.model.ScheduleExe;

public interface ScheduleExeMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ScheduleExe record);

    int insertSelective(ScheduleExe record);

    ScheduleExe selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScheduleExe record);

    int updateByPrimaryKey(ScheduleExe record);
}