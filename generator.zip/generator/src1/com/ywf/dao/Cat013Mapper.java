package com.ywf.dao;

import com.ywf.model.Cat013;

public interface Cat013Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat013 record);

    int insertSelective(Cat013 record);

    Cat013 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat013 record);

    int updateByPrimaryKey(Cat013 record);
}