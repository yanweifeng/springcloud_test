package com.ywf.dao;

import com.ywf.model.Cat035Segs;

public interface Cat035SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat035Segs record);

    int insertSelective(Cat035Segs record);

    Cat035Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat035Segs record);

    int updateByPrimaryKey(Cat035Segs record);
}