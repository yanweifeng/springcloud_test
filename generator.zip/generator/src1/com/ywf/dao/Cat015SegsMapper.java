package com.ywf.dao;

import com.ywf.model.Cat015Segs;

public interface Cat015SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat015Segs record);

    int insertSelective(Cat015Segs record);

    Cat015Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat015Segs record);

    int updateByPrimaryKey(Cat015Segs record);
}