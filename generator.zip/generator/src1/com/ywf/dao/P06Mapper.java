package com.ywf.dao;

import com.ywf.model.P06;

public interface P06Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(P06 record);

    int insertSelective(P06 record);

    P06 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(P06 record);

    int updateByPrimaryKey(P06 record);
}