package com.ywf.dao;

import com.ywf.model.Record0Segs;

public interface Record0SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record0Segs record);

    int insertSelective(Record0Segs record);

    Record0Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record0Segs record);

    int updateByPrimaryKey(Record0Segs record);
}