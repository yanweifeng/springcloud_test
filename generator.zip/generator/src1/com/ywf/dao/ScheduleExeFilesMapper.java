package com.ywf.dao;

import com.ywf.model.ScheduleExeFiles;

public interface ScheduleExeFilesMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ScheduleExeFiles record);

    int insertSelective(ScheduleExeFiles record);

    ScheduleExeFiles selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScheduleExeFiles record);

    int updateByPrimaryKey(ScheduleExeFiles record);
}