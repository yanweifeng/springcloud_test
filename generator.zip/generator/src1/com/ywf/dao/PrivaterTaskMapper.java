package com.ywf.dao;

import com.ywf.model.PrivaterTask;

public interface PrivaterTaskMapper {
    int deleteByPrimaryKey(Long id);

    int insert(PrivaterTask record);

    int insertSelective(PrivaterTask record);

    PrivaterTask selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PrivaterTask record);

    int updateByPrimaryKeyWithBLOBs(PrivaterTask record);

    int updateByPrimaryKey(PrivaterTask record);
}