package com.ywf.dao;

import com.ywf.model.Record8;

public interface Record8Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record8 record);

    int insertSelective(Record8 record);

    Record8 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record8 record);

    int updateByPrimaryKey(Record8 record);
}