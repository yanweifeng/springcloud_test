package com.ywf.dao;

import com.ywf.model.Cat009;

public interface Cat009Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat009 record);

    int insertSelective(Cat009 record);

    Cat009 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat009 record);

    int updateByPrimaryKey(Cat009 record);
}