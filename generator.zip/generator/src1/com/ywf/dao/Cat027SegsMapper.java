package com.ywf.dao;

import com.ywf.model.Cat027Segs;

public interface Cat027SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat027Segs record);

    int insertSelective(Cat027Segs record);

    Cat027Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat027Segs record);

    int updateByPrimaryKey(Cat027Segs record);
}