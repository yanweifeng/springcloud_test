package com.ywf.dao;

import com.ywf.model.Cat003;

public interface Cat003Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat003 record);

    int insertSelective(Cat003 record);

    Cat003 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat003 record);

    int updateByPrimaryKey(Cat003 record);
}