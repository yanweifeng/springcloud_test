package com.ywf.dao;

import com.ywf.model.Cat005;

public interface Cat005Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat005 record);

    int insertSelective(Cat005 record);

    Cat005 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat005 record);

    int updateByPrimaryKey(Cat005 record);
}