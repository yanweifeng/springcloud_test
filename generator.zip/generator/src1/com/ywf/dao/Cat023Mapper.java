package com.ywf.dao;

import com.ywf.model.Cat023;

public interface Cat023Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat023 record);

    int insertSelective(Cat023 record);

    Cat023 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat023 record);

    int updateByPrimaryKey(Cat023 record);
}