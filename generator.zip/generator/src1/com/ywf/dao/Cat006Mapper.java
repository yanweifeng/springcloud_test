package com.ywf.dao;

import com.ywf.model.Cat006;

public interface Cat006Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat006 record);

    int insertSelective(Cat006 record);

    Cat006 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat006 record);

    int updateByPrimaryKey(Cat006 record);
}