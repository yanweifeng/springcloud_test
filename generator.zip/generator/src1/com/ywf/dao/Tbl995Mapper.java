package com.ywf.dao;

import com.ywf.model.Tbl995;

public interface Tbl995Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl995 record);

    int insertSelective(Tbl995 record);

    Tbl995 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl995 record);

    int updateByPrimaryKey(Tbl995 record);
}