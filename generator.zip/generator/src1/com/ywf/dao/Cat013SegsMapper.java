package com.ywf.dao;

import com.ywf.model.Cat013Segs;

public interface Cat013SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat013Segs record);

    int insertSelective(Cat013Segs record);

    Cat013Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat013Segs record);

    int updateByPrimaryKey(Cat013Segs record);
}