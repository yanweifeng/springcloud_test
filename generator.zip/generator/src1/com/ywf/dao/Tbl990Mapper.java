package com.ywf.dao;

import com.ywf.model.Tbl990;

public interface Tbl990Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl990 record);

    int insertSelective(Tbl990 record);

    Tbl990 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl990 record);

    int updateByPrimaryKey(Tbl990 record);
}