package com.ywf.dao;

import com.ywf.model.Cat026;

public interface Cat026Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat026 record);

    int insertSelective(Cat026 record);

    Cat026 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat026 record);

    int updateByPrimaryKey(Cat026 record);
}