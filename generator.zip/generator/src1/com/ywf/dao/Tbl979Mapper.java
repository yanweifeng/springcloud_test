package com.ywf.dao;

import com.ywf.model.Tbl979;

public interface Tbl979Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl979 record);

    int insertSelective(Tbl979 record);

    Tbl979 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl979 record);

    int updateByPrimaryKey(Tbl979 record);
}