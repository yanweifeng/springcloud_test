package com.ywf.dao;

import com.ywf.model.Cat015;

public interface Cat015Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat015 record);

    int insertSelective(Cat015 record);

    Cat015 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat015 record);

    int updateByPrimaryKey(Cat015 record);
}