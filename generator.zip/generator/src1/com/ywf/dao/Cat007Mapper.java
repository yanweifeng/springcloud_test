package com.ywf.dao;

import com.ywf.model.Cat007;

public interface Cat007Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat007 record);

    int insertSelective(Cat007 record);

    Cat007 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat007 record);

    int updateByPrimaryKey(Cat007 record);
}