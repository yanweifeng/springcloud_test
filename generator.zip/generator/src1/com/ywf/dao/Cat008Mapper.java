package com.ywf.dao;

import com.ywf.model.Cat008;

public interface Cat008Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat008 record);

    int insertSelective(Cat008 record);

    Cat008 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat008 record);

    int updateByPrimaryKey(Cat008 record);
}