package com.ywf.dao;

import com.ywf.model.Cat01922Segs;

public interface Cat01922SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat01922Segs record);

    int insertSelective(Cat01922Segs record);

    Cat01922Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat01922Segs record);

    int updateByPrimaryKey(Cat01922Segs record);
}