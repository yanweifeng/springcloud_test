package com.ywf.dao;

import com.ywf.model.G16usca;

public interface G16uscaMapper {
    int deleteByPrimaryKey(Long id);

    int insert(G16usca record);

    int insertSelective(G16usca record);

    G16usca selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(G16usca record);

    int updateByPrimaryKey(G16usca record);
}