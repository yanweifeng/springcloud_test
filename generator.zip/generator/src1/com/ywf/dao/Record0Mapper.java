package com.ywf.dao;

import com.ywf.model.Record0;

public interface Record0Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record0 record);

    int insertSelective(Record0 record);

    Record0 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record0 record);

    int updateByPrimaryKey(Record0 record);
}