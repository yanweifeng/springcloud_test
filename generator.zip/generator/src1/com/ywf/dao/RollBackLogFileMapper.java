package com.ywf.dao;

import com.ywf.model.RollBackLogFile;

public interface RollBackLogFileMapper {
    int deleteByPrimaryKey(Long id);

    int insert(RollBackLogFile record);

    int insertSelective(RollBackLogFile record);

    RollBackLogFile selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RollBackLogFile record);

    int updateByPrimaryKey(RollBackLogFile record);
}