package com.ywf.dao;

import com.ywf.model.G16;

public interface G16Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(G16 record);

    int insertSelective(G16 record);

    G16 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(G16 record);

    int updateByPrimaryKey(G16 record);
}