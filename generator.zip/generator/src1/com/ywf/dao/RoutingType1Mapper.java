package com.ywf.dao;

import com.ywf.model.RoutingType1;

public interface RoutingType1Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(RoutingType1 record);

    int insertSelective(RoutingType1 record);

    RoutingType1 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RoutingType1 record);

    int updateByPrimaryKey(RoutingType1 record);
}