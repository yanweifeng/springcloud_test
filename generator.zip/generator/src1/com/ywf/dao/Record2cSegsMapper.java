package com.ywf.dao;

import com.ywf.model.Record2cSegs;

public interface Record2cSegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2cSegs record);

    int insertSelective(Record2cSegs record);

    Record2cSegs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2cSegs record);

    int updateByPrimaryKey(Record2cSegs record);
}