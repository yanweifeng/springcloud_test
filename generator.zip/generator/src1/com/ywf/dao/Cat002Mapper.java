package com.ywf.dao;

import com.ywf.model.Cat002;

public interface Cat002Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat002 record);

    int insertSelective(Cat002 record);

    Cat002 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat002 record);

    int updateByPrimaryKey(Cat002 record);
}