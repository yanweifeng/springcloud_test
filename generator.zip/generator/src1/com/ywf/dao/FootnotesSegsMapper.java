package com.ywf.dao;

import com.ywf.model.FootnotesSegs;

public interface FootnotesSegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(FootnotesSegs record);

    int insertSelective(FootnotesSegs record);

    FootnotesSegs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(FootnotesSegs record);

    int updateByPrimaryKey(FootnotesSegs record);
}