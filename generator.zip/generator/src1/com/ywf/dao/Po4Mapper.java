package com.ywf.dao;

import com.ywf.model.Po4;

public interface Po4Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Po4 record);

    int insertSelective(Po4 record);

    Po4 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Po4 record);

    int updateByPrimaryKey(Po4 record);
}