package com.ywf.dao;

import com.ywf.model.Po4Segs;

public interface Po4SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Po4Segs record);

    int insertSelective(Po4Segs record);

    Po4Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Po4Segs record);

    int updateByPrimaryKey(Po4Segs record);
}