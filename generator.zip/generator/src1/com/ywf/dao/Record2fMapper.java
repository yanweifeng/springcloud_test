package com.ywf.dao;

import com.ywf.model.Record2f;

public interface Record2fMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2f record);

    int insertSelective(Record2f record);

    Record2f selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2f record);

    int updateByPrimaryKey(Record2f record);
}