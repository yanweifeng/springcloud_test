package com.ywf.dao;

import com.ywf.model.Cat108;

public interface Cat108Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat108 record);

    int insertSelective(Cat108 record);

    Cat108 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat108 record);

    int updateByPrimaryKey(Cat108 record);
}