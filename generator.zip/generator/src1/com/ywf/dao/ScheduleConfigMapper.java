package com.ywf.dao;

import com.ywf.model.ScheduleConfig;

public interface ScheduleConfigMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ScheduleConfig record);

    int insertSelective(ScheduleConfig record);

    ScheduleConfig selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ScheduleConfig record);

    int updateByPrimaryKey(ScheduleConfig record);
}