package com.ywf.dao;

import com.ywf.model.Record6;

public interface Record6Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record6 record);

    int insertSelective(Record6 record);

    Record6 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record6 record);

    int updateByPrimaryKey(Record6 record);
}