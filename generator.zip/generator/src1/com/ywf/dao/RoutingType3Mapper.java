package com.ywf.dao;

import com.ywf.model.RoutingType3;

public interface RoutingType3Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(RoutingType3 record);

    int insertSelective(RoutingType3 record);

    RoutingType3 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RoutingType3 record);

    int updateByPrimaryKey(RoutingType3 record);
}