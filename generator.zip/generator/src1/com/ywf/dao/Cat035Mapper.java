package com.ywf.dao;

import com.ywf.model.Cat035;

public interface Cat035Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat035 record);

    int insertSelective(Cat035 record);

    Cat035 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat035 record);

    int updateByPrimaryKey(Cat035 record);
}