package com.ywf.dao;

import com.ywf.model.Cat009Segs;

public interface Cat009SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat009Segs record);

    int insertSelective(Cat009Segs record);

    Cat009Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat009Segs record);

    int updateByPrimaryKey(Cat009Segs record);
}