package com.ywf.dao;

import com.ywf.model.Record2fSegs;

public interface Record2fSegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2fSegs record);

    int insertSelective(Record2fSegs record);

    Record2fSegs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2fSegs record);

    int updateByPrimaryKey(Record2fSegs record);
}