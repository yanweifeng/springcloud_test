package com.ywf.dao;

import com.ywf.model.Tbl997;

public interface Tbl997Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl997 record);

    int insertSelective(Tbl997 record);

    Tbl997 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl997 record);

    int updateByPrimaryKey(Tbl997 record);
}