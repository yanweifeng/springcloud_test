package com.ywf.dao;

import com.ywf.model.Cat106;

public interface Cat106Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat106 record);

    int insertSelective(Cat106 record);

    Cat106 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat106 record);

    int updateByPrimaryKey(Cat106 record);
}