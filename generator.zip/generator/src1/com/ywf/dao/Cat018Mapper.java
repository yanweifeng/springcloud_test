package com.ywf.dao;

import com.ywf.model.Cat018;

public interface Cat018Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat018 record);

    int insertSelective(Cat018 record);

    Cat018 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat018 record);

    int updateByPrimaryKey(Cat018 record);
}