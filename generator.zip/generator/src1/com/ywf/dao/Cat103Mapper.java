package com.ywf.dao;

import com.ywf.model.Cat103;

public interface Cat103Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Cat103 record);

    int insertSelective(Cat103 record);

    Cat103 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Cat103 record);

    int updateByPrimaryKey(Cat103 record);
}