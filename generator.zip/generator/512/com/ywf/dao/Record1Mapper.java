package com.ywf.dao;

import com.ywf.model.Record1;

public interface Record1Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record1 record);

    int insertSelective(Record1 record);

    Record1 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record1 record);

    int updateByPrimaryKey(Record1 record);
}