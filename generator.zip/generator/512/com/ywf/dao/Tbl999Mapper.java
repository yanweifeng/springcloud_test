package com.ywf.dao;

import com.ywf.model.Tbl999;

public interface Tbl999Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl999 record);

    int insertSelective(Tbl999 record);

    Tbl999 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl999 record);

    int updateByPrimaryKey(Tbl999 record);
}