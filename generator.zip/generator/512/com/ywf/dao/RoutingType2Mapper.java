package com.ywf.dao;

import com.ywf.model.RoutingType2;

public interface RoutingType2Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(RoutingType2 record);

    int insertSelective(RoutingType2 record);

    RoutingType2 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RoutingType2 record);

    int updateByPrimaryKey(RoutingType2 record);
}