package com.ywf.dao;

import com.ywf.model.Record1Segs;

public interface Record1SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record1Segs record);

    int insertSelective(Record1Segs record);

    Record1Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record1Segs record);

    int updateByPrimaryKey(Record1Segs record);
}