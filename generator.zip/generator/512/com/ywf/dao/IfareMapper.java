package com.ywf.dao;

import com.ywf.model.Ifare;

public interface IfareMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Ifare record);

    int insertSelective(Ifare record);

    Ifare selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Ifare record);

    int updateByPrimaryKey(Ifare record);
}