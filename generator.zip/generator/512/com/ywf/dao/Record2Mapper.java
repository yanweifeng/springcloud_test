package com.ywf.dao;

import com.ywf.model.Record2;

public interface Record2Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2 record);

    int insertSelective(Record2 record);

    Record2 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2 record);

    int updateByPrimaryKey(Record2 record);
}