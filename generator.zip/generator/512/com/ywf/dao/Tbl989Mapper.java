package com.ywf.dao;

import com.ywf.model.Tbl989;

public interface Tbl989Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl989 record);

    int insertSelective(Tbl989 record);

    Tbl989 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl989 record);

    int updateByPrimaryKey(Tbl989 record);
}