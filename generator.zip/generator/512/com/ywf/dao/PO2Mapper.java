package com.ywf.dao;

import com.ywf.model.PO2;

public interface PO2Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(PO2 record);

    int insertSelective(PO2 record);

    PO2 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(PO2 record);

    int updateByPrimaryKey(PO2 record);
}