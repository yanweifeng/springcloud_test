package com.ywf.dao;

import com.ywf.model.AFare;

public interface AFareMapper {
    int deleteByPrimaryKey(Long id);

    int insert(AFare record);

    int insertSelective(AFare record);

    AFare selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(AFare record);

    int updateByPrimaryKey(AFare record);
}