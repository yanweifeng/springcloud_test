package com.ywf.dao;

import com.ywf.model.Tbl999Segs;

public interface Tbl999SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl999Segs record);

    int insertSelective(Tbl999Segs record);

    Tbl999Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl999Segs record);

    int updateByPrimaryKey(Tbl999Segs record);
}