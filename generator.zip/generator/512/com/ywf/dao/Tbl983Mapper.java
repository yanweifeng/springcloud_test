package com.ywf.dao;

import com.ywf.model.Tbl983;

public interface Tbl983Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl983 record);

    int insertSelective(Tbl983 record);

    Tbl983 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl983 record);

    int updateByPrimaryKey(Tbl983 record);
}