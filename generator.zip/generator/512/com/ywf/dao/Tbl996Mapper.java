package com.ywf.dao;

import com.ywf.model.Tbl996;

public interface Tbl996Mapper {
    int deleteByPrimaryKey(Long id);

    int insert(Tbl996 record);

    int insertSelective(Tbl996 record);

    Tbl996 selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Tbl996 record);

    int updateByPrimaryKey(Tbl996 record);
}