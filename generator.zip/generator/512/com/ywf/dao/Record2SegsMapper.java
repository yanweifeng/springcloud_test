package com.ywf.dao;

import com.ywf.model.Record2Segs;

public interface Record2SegsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Record2Segs record);

    int insertSelective(Record2Segs record);

    Record2Segs selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Record2Segs record);

    int updateByPrimaryKey(Record2Segs record);
}