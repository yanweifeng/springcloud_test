package com.ywf.model;

import java.util.Date;

public class Tbl999 {
    private Long id;

    private String tblno;

    private Long createId;

    private Long deleteId;

    private String prime;

    private String tbltype;

    private String seqno;

    private String cstag;

    private String appl;

    private String iftag;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getPrime() {
        return prime;
    }

    public void setPrime(String prime) {
        this.prime = prime == null ? null : prime.trim();
    }

    public String getTbltype() {
        return tbltype;
    }

    public void setTbltype(String tbltype) {
        this.tbltype = tbltype == null ? null : tbltype.trim();
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public String getCstag() {
        return cstag;
    }

    public void setCstag(String cstag) {
        this.cstag = cstag == null ? null : cstag.trim();
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getIftag() {
        return iftag;
    }

    public void setIftag(String iftag) {
        this.iftag = iftag == null ? null : iftag.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}