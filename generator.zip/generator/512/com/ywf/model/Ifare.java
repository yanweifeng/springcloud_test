package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Ifare {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String tariff;

    private String carrier;

    private String orig;

    private String origctry;

    private String dest;

    private String destctry;

    private String fcl;

    private Date effdate;

    private Date disdate;

    private String rule;

    private String rtg;

    private String owrt;

    private String fareSource;

    private BigDecimal fareamt1;

    private String curcode1;

    private Integer dec1;

    private BigDecimal fareamt2;

    private String curcode2;

    private Integer dec2;

    private BigDecimal fareamt3;

    private String curcode3;

    private Integer dec3;

    private String airport1;

    private String airport2;

    private String ftnt;

    private String direction;

    private String globaldir;

    private Date tareffdate;

    private Integer maxmileage;

    private String cabotage;

    private String addfcl1;

    private String addrtg1;

    private String addftnt1;

    private String addgateway1;

    private BigDecimal addamt1;

    private String addsign1;

    private String addcurcode1;

    private Integer adddec1;

    private String addfcl2;

    private String addrtg2;

    private String addftnt2;

    private String addgateway2;

    private BigDecimal addamt2;

    private String addsign2;

    private String addcurcode2;

    private Integer adddec2;

    private String pubftnt;

    private BigDecimal pubamt;

    private String pubcurcode;

    private Integer pubdec;

    private Date salesfirst;

    private Date saleslast;

    private String opAction;

    private String mcnnew;

    private String mcnold;

    private String batchci;

    private String batchno;

    private String pro;

    private String link;

    private String seq;

    private String faretype;

    private String chgtype;

    private Date gfsdate;

    private String gfsno;

    private Date createtime;

    private Date updatetime;

    private String md5;

    private Integer crc32;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff == null ? null : tariff.trim();
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    public String getOrig() {
        return orig;
    }

    public void setOrig(String orig) {
        this.orig = orig == null ? null : orig.trim();
    }

    public String getOrigctry() {
        return origctry;
    }

    public void setOrigctry(String origctry) {
        this.origctry = origctry == null ? null : origctry.trim();
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest == null ? null : dest.trim();
    }

    public String getDestctry() {
        return destctry;
    }

    public void setDestctry(String destctry) {
        this.destctry = destctry == null ? null : destctry.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getRule() {
        return rule;
    }

    public void setRule(String rule) {
        this.rule = rule == null ? null : rule.trim();
    }

    public String getRtg() {
        return rtg;
    }

    public void setRtg(String rtg) {
        this.rtg = rtg == null ? null : rtg.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getFareSource() {
        return fareSource;
    }

    public void setFareSource(String fareSource) {
        this.fareSource = fareSource == null ? null : fareSource.trim();
    }

    public BigDecimal getFareamt1() {
        return fareamt1;
    }

    public void setFareamt1(BigDecimal fareamt1) {
        this.fareamt1 = fareamt1;
    }

    public String getCurcode1() {
        return curcode1;
    }

    public void setCurcode1(String curcode1) {
        this.curcode1 = curcode1 == null ? null : curcode1.trim();
    }

    public Integer getDec1() {
        return dec1;
    }

    public void setDec1(Integer dec1) {
        this.dec1 = dec1;
    }

    public BigDecimal getFareamt2() {
        return fareamt2;
    }

    public void setFareamt2(BigDecimal fareamt2) {
        this.fareamt2 = fareamt2;
    }

    public String getCurcode2() {
        return curcode2;
    }

    public void setCurcode2(String curcode2) {
        this.curcode2 = curcode2 == null ? null : curcode2.trim();
    }

    public Integer getDec2() {
        return dec2;
    }

    public void setDec2(Integer dec2) {
        this.dec2 = dec2;
    }

    public BigDecimal getFareamt3() {
        return fareamt3;
    }

    public void setFareamt3(BigDecimal fareamt3) {
        this.fareamt3 = fareamt3;
    }

    public String getCurcode3() {
        return curcode3;
    }

    public void setCurcode3(String curcode3) {
        this.curcode3 = curcode3 == null ? null : curcode3.trim();
    }

    public Integer getDec3() {
        return dec3;
    }

    public void setDec3(Integer dec3) {
        this.dec3 = dec3;
    }

    public String getAirport1() {
        return airport1;
    }

    public void setAirport1(String airport1) {
        this.airport1 = airport1 == null ? null : airport1.trim();
    }

    public String getAirport2() {
        return airport2;
    }

    public void setAirport2(String airport2) {
        this.airport2 = airport2 == null ? null : airport2.trim();
    }

    public String getFtnt() {
        return ftnt;
    }

    public void setFtnt(String ftnt) {
        this.ftnt = ftnt == null ? null : ftnt.trim();
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction == null ? null : direction.trim();
    }

    public String getGlobaldir() {
        return globaldir;
    }

    public void setGlobaldir(String globaldir) {
        this.globaldir = globaldir == null ? null : globaldir.trim();
    }

    public Date getTareffdate() {
        return tareffdate;
    }

    public void setTareffdate(Date tareffdate) {
        this.tareffdate = tareffdate;
    }

    public Integer getMaxmileage() {
        return maxmileage;
    }

    public void setMaxmileage(Integer maxmileage) {
        this.maxmileage = maxmileage;
    }

    public String getCabotage() {
        return cabotage;
    }

    public void setCabotage(String cabotage) {
        this.cabotage = cabotage == null ? null : cabotage.trim();
    }

    public String getAddfcl1() {
        return addfcl1;
    }

    public void setAddfcl1(String addfcl1) {
        this.addfcl1 = addfcl1 == null ? null : addfcl1.trim();
    }

    public String getAddrtg1() {
        return addrtg1;
    }

    public void setAddrtg1(String addrtg1) {
        this.addrtg1 = addrtg1 == null ? null : addrtg1.trim();
    }

    public String getAddftnt1() {
        return addftnt1;
    }

    public void setAddftnt1(String addftnt1) {
        this.addftnt1 = addftnt1 == null ? null : addftnt1.trim();
    }

    public String getAddgateway1() {
        return addgateway1;
    }

    public void setAddgateway1(String addgateway1) {
        this.addgateway1 = addgateway1 == null ? null : addgateway1.trim();
    }

    public BigDecimal getAddamt1() {
        return addamt1;
    }

    public void setAddamt1(BigDecimal addamt1) {
        this.addamt1 = addamt1;
    }

    public String getAddsign1() {
        return addsign1;
    }

    public void setAddsign1(String addsign1) {
        this.addsign1 = addsign1 == null ? null : addsign1.trim();
    }

    public String getAddcurcode1() {
        return addcurcode1;
    }

    public void setAddcurcode1(String addcurcode1) {
        this.addcurcode1 = addcurcode1 == null ? null : addcurcode1.trim();
    }

    public Integer getAdddec1() {
        return adddec1;
    }

    public void setAdddec1(Integer adddec1) {
        this.adddec1 = adddec1;
    }

    public String getAddfcl2() {
        return addfcl2;
    }

    public void setAddfcl2(String addfcl2) {
        this.addfcl2 = addfcl2 == null ? null : addfcl2.trim();
    }

    public String getAddrtg2() {
        return addrtg2;
    }

    public void setAddrtg2(String addrtg2) {
        this.addrtg2 = addrtg2 == null ? null : addrtg2.trim();
    }

    public String getAddftnt2() {
        return addftnt2;
    }

    public void setAddftnt2(String addftnt2) {
        this.addftnt2 = addftnt2 == null ? null : addftnt2.trim();
    }

    public String getAddgateway2() {
        return addgateway2;
    }

    public void setAddgateway2(String addgateway2) {
        this.addgateway2 = addgateway2 == null ? null : addgateway2.trim();
    }

    public BigDecimal getAddamt2() {
        return addamt2;
    }

    public void setAddamt2(BigDecimal addamt2) {
        this.addamt2 = addamt2;
    }

    public String getAddsign2() {
        return addsign2;
    }

    public void setAddsign2(String addsign2) {
        this.addsign2 = addsign2 == null ? null : addsign2.trim();
    }

    public String getAddcurcode2() {
        return addcurcode2;
    }

    public void setAddcurcode2(String addcurcode2) {
        this.addcurcode2 = addcurcode2 == null ? null : addcurcode2.trim();
    }

    public Integer getAdddec2() {
        return adddec2;
    }

    public void setAdddec2(Integer adddec2) {
        this.adddec2 = adddec2;
    }

    public String getPubftnt() {
        return pubftnt;
    }

    public void setPubftnt(String pubftnt) {
        this.pubftnt = pubftnt == null ? null : pubftnt.trim();
    }

    public BigDecimal getPubamt() {
        return pubamt;
    }

    public void setPubamt(BigDecimal pubamt) {
        this.pubamt = pubamt;
    }

    public String getPubcurcode() {
        return pubcurcode;
    }

    public void setPubcurcode(String pubcurcode) {
        this.pubcurcode = pubcurcode == null ? null : pubcurcode.trim();
    }

    public Integer getPubdec() {
        return pubdec;
    }

    public void setPubdec(Integer pubdec) {
        this.pubdec = pubdec;
    }

    public Date getSalesfirst() {
        return salesfirst;
    }

    public void setSalesfirst(Date salesfirst) {
        this.salesfirst = salesfirst;
    }

    public Date getSaleslast() {
        return saleslast;
    }

    public void setSaleslast(Date saleslast) {
        this.saleslast = saleslast;
    }

    public String getOpAction() {
        return opAction;
    }

    public void setOpAction(String opAction) {
        this.opAction = opAction == null ? null : opAction.trim();
    }

    public String getMcnnew() {
        return mcnnew;
    }

    public void setMcnnew(String mcnnew) {
        this.mcnnew = mcnnew == null ? null : mcnnew.trim();
    }

    public String getMcnold() {
        return mcnold;
    }

    public void setMcnold(String mcnold) {
        this.mcnold = mcnold == null ? null : mcnold.trim();
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getPro() {
        return pro;
    }

    public void setPro(String pro) {
        this.pro = pro == null ? null : pro.trim();
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link == null ? null : link.trim();
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq == null ? null : seq.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getChgtype() {
        return chgtype;
    }

    public void setChgtype(String chgtype) {
        this.chgtype = chgtype == null ? null : chgtype.trim();
    }

    public Date getGfsdate() {
        return gfsdate;
    }

    public void setGfsdate(Date gfsdate) {
        this.gfsdate = gfsdate;
    }

    public String getGfsno() {
        return gfsno;
    }

    public void setGfsno(String gfsno) {
        this.gfsno = gfsno == null ? null : gfsno.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5 == null ? null : md5.trim();
    }

    public Integer getCrc32() {
        return crc32;
    }

    public void setCrc32(Integer crc32) {
        this.crc32 = crc32;
    }
}