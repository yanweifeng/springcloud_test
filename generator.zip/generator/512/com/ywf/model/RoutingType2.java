package com.ywf.model;

import java.util.Date;

public class RoutingType2 {
    private Long id;

    private Long routingtype1Id;

    private Long createId;

    private String link;

    private String city1no;

    private String city1id;

    private String city1name;

    private String city1tag;

    private String nextcity;

    private String altcity;

    private String locroute;

    private String reserved;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRoutingtype1Id() {
        return routingtype1Id;
    }

    public void setRoutingtype1Id(Long routingtype1Id) {
        this.routingtype1Id = routingtype1Id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link == null ? null : link.trim();
    }

    public String getCity1no() {
        return city1no;
    }

    public void setCity1no(String city1no) {
        this.city1no = city1no == null ? null : city1no.trim();
    }

    public String getCity1id() {
        return city1id;
    }

    public void setCity1id(String city1id) {
        this.city1id = city1id == null ? null : city1id.trim();
    }

    public String getCity1name() {
        return city1name;
    }

    public void setCity1name(String city1name) {
        this.city1name = city1name == null ? null : city1name.trim();
    }

    public String getCity1tag() {
        return city1tag;
    }

    public void setCity1tag(String city1tag) {
        this.city1tag = city1tag == null ? null : city1tag.trim();
    }

    public String getNextcity() {
        return nextcity;
    }

    public void setNextcity(String nextcity) {
        this.nextcity = nextcity == null ? null : nextcity.trim();
    }

    public String getAltcity() {
        return altcity;
    }

    public void setAltcity(String altcity) {
        this.altcity = altcity == null ? null : altcity.trim();
    }

    public String getLocroute() {
        return locroute;
    }

    public void setLocroute(String locroute) {
        this.locroute = locroute == null ? null : locroute.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}