package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class Tbl989 {
    private Long id;

    private String tblno;

    private Long createId;

    private String seqno;

    private Long deleteId;

    private String appl;

    private String owrt;

    private String global;

    private String cxrcode;

    private String pubcalc;

    private String ruletar;

    private String ruleno;

    private String fareclas;

    private String faretype;

    private String psgrtype;

    private String season;

    private String daytype;

    private String prccat;

    private String rtgno;

    private String ftnote;

    private String bookcd;

    private String reserved1;

    private String btwncty;

    private String andcty;

    private BigDecimal rnge1min;

    private BigDecimal rnge1max;

    private String rnge1cur;

    private Integer rnge1dec;

    private BigDecimal rnge2min;

    private BigDecimal rnge2max;

    private String rnge2cur;

    private Integer rnge2dec;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getGlobal() {
        return global;
    }

    public void setGlobal(String global) {
        this.global = global == null ? null : global.trim();
    }

    public String getCxrcode() {
        return cxrcode;
    }

    public void setCxrcode(String cxrcode) {
        this.cxrcode = cxrcode == null ? null : cxrcode.trim();
    }

    public String getPubcalc() {
        return pubcalc;
    }

    public void setPubcalc(String pubcalc) {
        this.pubcalc = pubcalc == null ? null : pubcalc.trim();
    }

    public String getRuletar() {
        return ruletar;
    }

    public void setRuletar(String ruletar) {
        this.ruletar = ruletar == null ? null : ruletar.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getFareclas() {
        return fareclas;
    }

    public void setFareclas(String fareclas) {
        this.fareclas = fareclas == null ? null : fareclas.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getPsgrtype() {
        return psgrtype;
    }

    public void setPsgrtype(String psgrtype) {
        this.psgrtype = psgrtype == null ? null : psgrtype.trim();
    }

    public String getSeason() {
        return season;
    }

    public void setSeason(String season) {
        this.season = season == null ? null : season.trim();
    }

    public String getDaytype() {
        return daytype;
    }

    public void setDaytype(String daytype) {
        this.daytype = daytype == null ? null : daytype.trim();
    }

    public String getPrccat() {
        return prccat;
    }

    public void setPrccat(String prccat) {
        this.prccat = prccat == null ? null : prccat.trim();
    }

    public String getRtgno() {
        return rtgno;
    }

    public void setRtgno(String rtgno) {
        this.rtgno = rtgno == null ? null : rtgno.trim();
    }

    public String getFtnote() {
        return ftnote;
    }

    public void setFtnote(String ftnote) {
        this.ftnote = ftnote == null ? null : ftnote.trim();
    }

    public String getBookcd() {
        return bookcd;
    }

    public void setBookcd(String bookcd) {
        this.bookcd = bookcd == null ? null : bookcd.trim();
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1 == null ? null : reserved1.trim();
    }

    public String getBtwncty() {
        return btwncty;
    }

    public void setBtwncty(String btwncty) {
        this.btwncty = btwncty == null ? null : btwncty.trim();
    }

    public String getAndcty() {
        return andcty;
    }

    public void setAndcty(String andcty) {
        this.andcty = andcty == null ? null : andcty.trim();
    }

    public BigDecimal getRnge1min() {
        return rnge1min;
    }

    public void setRnge1min(BigDecimal rnge1min) {
        this.rnge1min = rnge1min;
    }

    public BigDecimal getRnge1max() {
        return rnge1max;
    }

    public void setRnge1max(BigDecimal rnge1max) {
        this.rnge1max = rnge1max;
    }

    public String getRnge1cur() {
        return rnge1cur;
    }

    public void setRnge1cur(String rnge1cur) {
        this.rnge1cur = rnge1cur == null ? null : rnge1cur.trim();
    }

    public Integer getRnge1dec() {
        return rnge1dec;
    }

    public void setRnge1dec(Integer rnge1dec) {
        this.rnge1dec = rnge1dec;
    }

    public BigDecimal getRnge2min() {
        return rnge2min;
    }

    public void setRnge2min(BigDecimal rnge2min) {
        this.rnge2min = rnge2min;
    }

    public BigDecimal getRnge2max() {
        return rnge2max;
    }

    public void setRnge2max(BigDecimal rnge2max) {
        this.rnge2max = rnge2max;
    }

    public String getRnge2cur() {
        return rnge2cur;
    }

    public void setRnge2cur(String rnge2cur) {
        this.rnge2cur = rnge2cur == null ? null : rnge2cur.trim();
    }

    public Integer getRnge2dec() {
        return rnge2dec;
    }

    public void setRnge2dec(Integer rnge2dec) {
        this.rnge2dec = rnge2dec;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}