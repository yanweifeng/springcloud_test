package com.ywf.model;

import java.util.Date;

public class Tbl999Segs {
    private Long id;

    private String tblno;

    private Long createId;

    private String seqno;

    private String negcxr;

    private String viacxr;

    private String primesec;

    private String irind;

    private String flt1;

    private String flt2;

    private String eqptype;

    private String portions;

    private String loctsi;

    private String di;

    private String loc1type;

    private String loc1code;

    private String loc2type;

    private String loc2code;

    private String postsi;

    private String posloctyp;

    private String poslocode;

    private String sold;

    private String strtdate;

    private String stopdate;

    private String dayweek;

    private String reserved;

    private String strttime;

    private String stoptime;

    private String fcltype;

    private String fcl;

    private String arbrtgno;

    private String arbzone;

    private String rest;

    private String bkcode1;

    private String bkcode2;

    private Date createtime;

    private Date updatetime;

    private String md5;

    private Integer crc32;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public String getNegcxr() {
        return negcxr;
    }

    public void setNegcxr(String negcxr) {
        this.negcxr = negcxr == null ? null : negcxr.trim();
    }

    public String getViacxr() {
        return viacxr;
    }

    public void setViacxr(String viacxr) {
        this.viacxr = viacxr == null ? null : viacxr.trim();
    }

    public String getPrimesec() {
        return primesec;
    }

    public void setPrimesec(String primesec) {
        this.primesec = primesec == null ? null : primesec.trim();
    }

    public String getIrind() {
        return irind;
    }

    public void setIrind(String irind) {
        this.irind = irind == null ? null : irind.trim();
    }

    public String getFlt1() {
        return flt1;
    }

    public void setFlt1(String flt1) {
        this.flt1 = flt1 == null ? null : flt1.trim();
    }

    public String getFlt2() {
        return flt2;
    }

    public void setFlt2(String flt2) {
        this.flt2 = flt2 == null ? null : flt2.trim();
    }

    public String getEqptype() {
        return eqptype;
    }

    public void setEqptype(String eqptype) {
        this.eqptype = eqptype == null ? null : eqptype.trim();
    }

    public String getPortions() {
        return portions;
    }

    public void setPortions(String portions) {
        this.portions = portions == null ? null : portions.trim();
    }

    public String getLoctsi() {
        return loctsi;
    }

    public void setLoctsi(String loctsi) {
        this.loctsi = loctsi == null ? null : loctsi.trim();
    }

    public String getDi() {
        return di;
    }

    public void setDi(String di) {
        this.di = di == null ? null : di.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getPostsi() {
        return postsi;
    }

    public void setPostsi(String postsi) {
        this.postsi = postsi == null ? null : postsi.trim();
    }

    public String getPosloctyp() {
        return posloctyp;
    }

    public void setPosloctyp(String posloctyp) {
        this.posloctyp = posloctyp == null ? null : posloctyp.trim();
    }

    public String getPoslocode() {
        return poslocode;
    }

    public void setPoslocode(String poslocode) {
        this.poslocode = poslocode == null ? null : poslocode.trim();
    }

    public String getSold() {
        return sold;
    }

    public void setSold(String sold) {
        this.sold = sold == null ? null : sold.trim();
    }

    public String getStrtdate() {
        return strtdate;
    }

    public void setStrtdate(String strtdate) {
        this.strtdate = strtdate == null ? null : strtdate.trim();
    }

    public String getStopdate() {
        return stopdate;
    }

    public void setStopdate(String stopdate) {
        this.stopdate = stopdate == null ? null : stopdate.trim();
    }

    public String getDayweek() {
        return dayweek;
    }

    public void setDayweek(String dayweek) {
        this.dayweek = dayweek == null ? null : dayweek.trim();
    }

    public String getReserved() {
        return reserved;
    }

    public void setReserved(String reserved) {
        this.reserved = reserved == null ? null : reserved.trim();
    }

    public String getStrttime() {
        return strttime;
    }

    public void setStrttime(String strttime) {
        this.strttime = strttime == null ? null : strttime.trim();
    }

    public String getStoptime() {
        return stoptime;
    }

    public void setStoptime(String stoptime) {
        this.stoptime = stoptime == null ? null : stoptime.trim();
    }

    public String getFcltype() {
        return fcltype;
    }

    public void setFcltype(String fcltype) {
        this.fcltype = fcltype == null ? null : fcltype.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getArbrtgno() {
        return arbrtgno;
    }

    public void setArbrtgno(String arbrtgno) {
        this.arbrtgno = arbrtgno == null ? null : arbrtgno.trim();
    }

    public String getArbzone() {
        return arbzone;
    }

    public void setArbzone(String arbzone) {
        this.arbzone = arbzone == null ? null : arbzone.trim();
    }

    public String getRest() {
        return rest;
    }

    public void setRest(String rest) {
        this.rest = rest == null ? null : rest.trim();
    }

    public String getBkcode1() {
        return bkcode1;
    }

    public void setBkcode1(String bkcode1) {
        this.bkcode1 = bkcode1 == null ? null : bkcode1.trim();
    }

    public String getBkcode2() {
        return bkcode2;
    }

    public void setBkcode2(String bkcode2) {
        this.bkcode2 = bkcode2 == null ? null : bkcode2.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5 == null ? null : md5.trim();
    }

    public Integer getCrc32() {
        return crc32;
    }

    public void setCrc32(Integer crc32) {
        this.crc32 = crc32;
    }
}