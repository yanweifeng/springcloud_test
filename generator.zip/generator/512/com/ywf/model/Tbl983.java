package com.ywf.model;

import java.util.Date;

public class Tbl983 {
    private Long id;

    private String tblno;

    private Long createId;

    private String seqno;

    private Long deleteId;

    private String appl;

    private String tvlagncy;

    private String cxrcrs;

    private String dutyfunc;

    private String loc1type;

    private String loc1code;

    private String loc2type;

    private String loc2code;

    private String loctype;

    private String loccode;

    private String isUpdate;

    private String redist;

    private String sell;

    private String ticket;

    private String changes;

    private String sellid;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTblno() {
        return tblno;
    }

    public void setTblno(String tblno) {
        this.tblno = tblno == null ? null : tblno.trim();
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAppl() {
        return appl;
    }

    public void setAppl(String appl) {
        this.appl = appl == null ? null : appl.trim();
    }

    public String getTvlagncy() {
        return tvlagncy;
    }

    public void setTvlagncy(String tvlagncy) {
        this.tvlagncy = tvlagncy == null ? null : tvlagncy.trim();
    }

    public String getCxrcrs() {
        return cxrcrs;
    }

    public void setCxrcrs(String cxrcrs) {
        this.cxrcrs = cxrcrs == null ? null : cxrcrs.trim();
    }

    public String getDutyfunc() {
        return dutyfunc;
    }

    public void setDutyfunc(String dutyfunc) {
        this.dutyfunc = dutyfunc == null ? null : dutyfunc.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getLoctype() {
        return loctype;
    }

    public void setLoctype(String loctype) {
        this.loctype = loctype == null ? null : loctype.trim();
    }

    public String getLoccode() {
        return loccode;
    }

    public void setLoccode(String loccode) {
        this.loccode = loccode == null ? null : loccode.trim();
    }

    public String getIsUpdate() {
        return isUpdate;
    }

    public void setIsUpdate(String isUpdate) {
        this.isUpdate = isUpdate == null ? null : isUpdate.trim();
    }

    public String getRedist() {
        return redist;
    }

    public void setRedist(String redist) {
        this.redist = redist == null ? null : redist.trim();
    }

    public String getSell() {
        return sell;
    }

    public void setSell(String sell) {
        this.sell = sell == null ? null : sell.trim();
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket == null ? null : ticket.trim();
    }

    public String getChanges() {
        return changes;
    }

    public void setChanges(String changes) {
        this.changes = changes == null ? null : changes.trim();
    }

    public String getSellid() {
        return sellid;
    }

    public void setSellid(String sellid) {
        this.sellid = sellid == null ? null : sellid.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}