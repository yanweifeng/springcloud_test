package com.ywf.model;

import java.util.Date;

public class PO2 {
    private Long id;

    private Long createId;

    private Long updateId;

    private String tariff;

    private String filler1;

    private String cxr;

    private String fcl;

    private String operateAction;

    private String owrt;

    private String usall;

    private String usgen;

    private String nusall;

    private String nusgen;

    private String nuc;

    private Date effdate;

    private Date disdate;

    private String filler2;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff == null ? null : tariff.trim();
    }

    public String getFiller1() {
        return filler1;
    }

    public void setFiller1(String filler1) {
        this.filler1 = filler1 == null ? null : filler1.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getOperateAction() {
        return operateAction;
    }

    public void setOperateAction(String operateAction) {
        this.operateAction = operateAction == null ? null : operateAction.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getUsall() {
        return usall;
    }

    public void setUsall(String usall) {
        this.usall = usall == null ? null : usall.trim();
    }

    public String getUsgen() {
        return usgen;
    }

    public void setUsgen(String usgen) {
        this.usgen = usgen == null ? null : usgen.trim();
    }

    public String getNusall() {
        return nusall;
    }

    public void setNusall(String nusall) {
        this.nusall = nusall == null ? null : nusall.trim();
    }

    public String getNusgen() {
        return nusgen;
    }

    public void setNusgen(String nusgen) {
        this.nusgen = nusgen == null ? null : nusgen.trim();
    }

    public String getNuc() {
        return nuc;
    }

    public void setNuc(String nuc) {
        this.nuc = nuc == null ? null : nuc.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getFiller2() {
        return filler2;
    }

    public void setFiller2(String filler2) {
        this.filler2 = filler2 == null ? null : filler2.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}