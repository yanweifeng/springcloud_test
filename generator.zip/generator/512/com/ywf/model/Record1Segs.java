package com.ywf.model;

import java.util.Date;

public class Record1Segs {
    private Long id;

    private Long record1Id;

    private Long createId;

    private Integer segorder;

    private String di;

    private String farebasis;

    private String tcm;

    private String designator;

    private String tdm;

    private String pax;

    private Integer minage;

    private Integer maxage;

    private String filler;

    private String datetblno;

    private String bkcodes;

    private String cxrtblno;

    private String rbdtblno;

    private String commname;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecord1Id() {
        return record1Id;
    }

    public void setRecord1Id(Long record1Id) {
        this.record1Id = record1Id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getSegorder() {
        return segorder;
    }

    public void setSegorder(Integer segorder) {
        this.segorder = segorder;
    }

    public String getDi() {
        return di;
    }

    public void setDi(String di) {
        this.di = di == null ? null : di.trim();
    }

    public String getFarebasis() {
        return farebasis;
    }

    public void setFarebasis(String farebasis) {
        this.farebasis = farebasis == null ? null : farebasis.trim();
    }

    public String getTcm() {
        return tcm;
    }

    public void setTcm(String tcm) {
        this.tcm = tcm == null ? null : tcm.trim();
    }

    public String getDesignator() {
        return designator;
    }

    public void setDesignator(String designator) {
        this.designator = designator == null ? null : designator.trim();
    }

    public String getTdm() {
        return tdm;
    }

    public void setTdm(String tdm) {
        this.tdm = tdm == null ? null : tdm.trim();
    }

    public String getPax() {
        return pax;
    }

    public void setPax(String pax) {
        this.pax = pax == null ? null : pax.trim();
    }

    public Integer getMinage() {
        return minage;
    }

    public void setMinage(Integer minage) {
        this.minage = minage;
    }

    public Integer getMaxage() {
        return maxage;
    }

    public void setMaxage(Integer maxage) {
        this.maxage = maxage;
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }

    public String getDatetblno() {
        return datetblno;
    }

    public void setDatetblno(String datetblno) {
        this.datetblno = datetblno == null ? null : datetblno.trim();
    }

    public String getBkcodes() {
        return bkcodes;
    }

    public void setBkcodes(String bkcodes) {
        this.bkcodes = bkcodes == null ? null : bkcodes.trim();
    }

    public String getCxrtblno() {
        return cxrtblno;
    }

    public void setCxrtblno(String cxrtblno) {
        this.cxrtblno = cxrtblno == null ? null : cxrtblno.trim();
    }

    public String getRbdtblno() {
        return rbdtblno;
    }

    public void setRbdtblno(String rbdtblno) {
        this.rbdtblno = rbdtblno == null ? null : rbdtblno.trim();
    }

    public String getCommname() {
        return commname;
    }

    public void setCommname(String commname) {
        this.commname = commname == null ? null : commname.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}