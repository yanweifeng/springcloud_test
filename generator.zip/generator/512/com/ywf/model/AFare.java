package com.ywf.model;

import java.math.BigDecimal;
import java.util.Date;

public class AFare {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String opAction;

    private String carrier;

    private String orig;

    private String dest;

    private String fcl;

    private String tariff;

    private String mcn;

    private String batchci;

    private String batchno;

    private String pro;

    private BigDecimal fareamt;

    private String curcode;

    private Integer decp;

    private Date effdate;

    private Date disdate;

    private Date tareffdate;

    private String link;

    private String seq;

    private Integer numrecs;

    private String tags;

    private String owrt;

    private String rtg;

    private String ftnt;

    private String geoorig;

    private String geodest;

    private String origctry;

    private String destctry;

    private String zone;

    private Date gfsdate;

    private String gfsno;

    private String filler;

    private Date createtime;

    private Date updatetime;

    private String md5;

    private Integer crc32;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getOpAction() {
        return opAction;
    }

    public void setOpAction(String opAction) {
        this.opAction = opAction == null ? null : opAction.trim();
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier == null ? null : carrier.trim();
    }

    public String getOrig() {
        return orig;
    }

    public void setOrig(String orig) {
        this.orig = orig == null ? null : orig.trim();
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest == null ? null : dest.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getTariff() {
        return tariff;
    }

    public void setTariff(String tariff) {
        this.tariff = tariff == null ? null : tariff.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getPro() {
        return pro;
    }

    public void setPro(String pro) {
        this.pro = pro == null ? null : pro.trim();
    }

    public BigDecimal getFareamt() {
        return fareamt;
    }

    public void setFareamt(BigDecimal fareamt) {
        this.fareamt = fareamt;
    }

    public String getCurcode() {
        return curcode;
    }

    public void setCurcode(String curcode) {
        this.curcode = curcode == null ? null : curcode.trim();
    }

    public Integer getDecp() {
        return decp;
    }

    public void setDecp(Integer decp) {
        this.decp = decp;
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public Date getTareffdate() {
        return tareffdate;
    }

    public void setTareffdate(Date tareffdate) {
        this.tareffdate = tareffdate;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link == null ? null : link.trim();
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq == null ? null : seq.trim();
    }

    public Integer getNumrecs() {
        return numrecs;
    }

    public void setNumrecs(Integer numrecs) {
        this.numrecs = numrecs;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags == null ? null : tags.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getRtg() {
        return rtg;
    }

    public void setRtg(String rtg) {
        this.rtg = rtg == null ? null : rtg.trim();
    }

    public String getFtnt() {
        return ftnt;
    }

    public void setFtnt(String ftnt) {
        this.ftnt = ftnt == null ? null : ftnt.trim();
    }

    public String getGeoorig() {
        return geoorig;
    }

    public void setGeoorig(String geoorig) {
        this.geoorig = geoorig == null ? null : geoorig.trim();
    }

    public String getGeodest() {
        return geodest;
    }

    public void setGeodest(String geodest) {
        this.geodest = geodest == null ? null : geodest.trim();
    }

    public String getOrigctry() {
        return origctry;
    }

    public void setOrigctry(String origctry) {
        this.origctry = origctry == null ? null : origctry.trim();
    }

    public String getDestctry() {
        return destctry;
    }

    public void setDestctry(String destctry) {
        this.destctry = destctry == null ? null : destctry.trim();
    }

    public String getZone() {
        return zone;
    }

    public void setZone(String zone) {
        this.zone = zone == null ? null : zone.trim();
    }

    public Date getGfsdate() {
        return gfsdate;
    }

    public void setGfsdate(Date gfsdate) {
        this.gfsdate = gfsdate;
    }

    public String getGfsno() {
        return gfsno;
    }

    public void setGfsno(String gfsno) {
        this.gfsno = gfsno == null ? null : gfsno.trim();
    }

    public String getFiller() {
        return filler;
    }

    public void setFiller(String filler) {
        this.filler = filler == null ? null : filler.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5 == null ? null : md5.trim();
    }

    public Integer getCrc32() {
        return crc32;
    }

    public void setCrc32(Integer crc32) {
        this.crc32 = crc32;
    }
}