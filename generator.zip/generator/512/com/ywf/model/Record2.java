package com.ywf.model;

import java.util.Date;

public class Record2 {
    private Long id;

    private Long createId;

    private Long deleteId;

    private String action;

    private String ruletar;

    private String cxr;

    private String ruleno;

    private String cat;

    private String mcn;

    private String seqno;

    private String loc1type;

    private String loc1code;

    private String loc2type;

    private String loc2code;

    private String fcl;

    private String faretype;

    private String seatype;

    private String dowtype;

    private String owrt;

    private String rtgno;

    private String ftnt;

    private String jtcxrtbl;

    private Date effdate;

    private Date disdate;

    private String batchci;

    private String batchno;

    private String notappl;

    private String gruletsc;

    private String gruleno;

    private String genappl;

    private Integer segcnt;

    private Date createtime;

    private Date updatetime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getDeleteId() {
        return deleteId;
    }

    public void setDeleteId(Long deleteId) {
        this.deleteId = deleteId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action == null ? null : action.trim();
    }

    public String getRuletar() {
        return ruletar;
    }

    public void setRuletar(String ruletar) {
        this.ruletar = ruletar == null ? null : ruletar.trim();
    }

    public String getCxr() {
        return cxr;
    }

    public void setCxr(String cxr) {
        this.cxr = cxr == null ? null : cxr.trim();
    }

    public String getRuleno() {
        return ruleno;
    }

    public void setRuleno(String ruleno) {
        this.ruleno = ruleno == null ? null : ruleno.trim();
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat == null ? null : cat.trim();
    }

    public String getMcn() {
        return mcn;
    }

    public void setMcn(String mcn) {
        this.mcn = mcn == null ? null : mcn.trim();
    }

    public String getSeqno() {
        return seqno;
    }

    public void setSeqno(String seqno) {
        this.seqno = seqno == null ? null : seqno.trim();
    }

    public String getLoc1type() {
        return loc1type;
    }

    public void setLoc1type(String loc1type) {
        this.loc1type = loc1type == null ? null : loc1type.trim();
    }

    public String getLoc1code() {
        return loc1code;
    }

    public void setLoc1code(String loc1code) {
        this.loc1code = loc1code == null ? null : loc1code.trim();
    }

    public String getLoc2type() {
        return loc2type;
    }

    public void setLoc2type(String loc2type) {
        this.loc2type = loc2type == null ? null : loc2type.trim();
    }

    public String getLoc2code() {
        return loc2code;
    }

    public void setLoc2code(String loc2code) {
        this.loc2code = loc2code == null ? null : loc2code.trim();
    }

    public String getFcl() {
        return fcl;
    }

    public void setFcl(String fcl) {
        this.fcl = fcl == null ? null : fcl.trim();
    }

    public String getFaretype() {
        return faretype;
    }

    public void setFaretype(String faretype) {
        this.faretype = faretype == null ? null : faretype.trim();
    }

    public String getSeatype() {
        return seatype;
    }

    public void setSeatype(String seatype) {
        this.seatype = seatype == null ? null : seatype.trim();
    }

    public String getDowtype() {
        return dowtype;
    }

    public void setDowtype(String dowtype) {
        this.dowtype = dowtype == null ? null : dowtype.trim();
    }

    public String getOwrt() {
        return owrt;
    }

    public void setOwrt(String owrt) {
        this.owrt = owrt == null ? null : owrt.trim();
    }

    public String getRtgno() {
        return rtgno;
    }

    public void setRtgno(String rtgno) {
        this.rtgno = rtgno == null ? null : rtgno.trim();
    }

    public String getFtnt() {
        return ftnt;
    }

    public void setFtnt(String ftnt) {
        this.ftnt = ftnt == null ? null : ftnt.trim();
    }

    public String getJtcxrtbl() {
        return jtcxrtbl;
    }

    public void setJtcxrtbl(String jtcxrtbl) {
        this.jtcxrtbl = jtcxrtbl == null ? null : jtcxrtbl.trim();
    }

    public Date getEffdate() {
        return effdate;
    }

    public void setEffdate(Date effdate) {
        this.effdate = effdate;
    }

    public Date getDisdate() {
        return disdate;
    }

    public void setDisdate(Date disdate) {
        this.disdate = disdate;
    }

    public String getBatchci() {
        return batchci;
    }

    public void setBatchci(String batchci) {
        this.batchci = batchci == null ? null : batchci.trim();
    }

    public String getBatchno() {
        return batchno;
    }

    public void setBatchno(String batchno) {
        this.batchno = batchno == null ? null : batchno.trim();
    }

    public String getNotappl() {
        return notappl;
    }

    public void setNotappl(String notappl) {
        this.notappl = notappl == null ? null : notappl.trim();
    }

    public String getGruletsc() {
        return gruletsc;
    }

    public void setGruletsc(String gruletsc) {
        this.gruletsc = gruletsc == null ? null : gruletsc.trim();
    }

    public String getGruleno() {
        return gruleno;
    }

    public void setGruleno(String gruleno) {
        this.gruleno = gruleno == null ? null : gruleno.trim();
    }

    public String getGenappl() {
        return genappl;
    }

    public void setGenappl(String genappl) {
        this.genappl = genappl == null ? null : genappl.trim();
    }

    public Integer getSegcnt() {
        return segcnt;
    }

    public void setSegcnt(Integer segcnt) {
        this.segcnt = segcnt;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}