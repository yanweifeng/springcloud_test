package com.ywf.model;

import java.util.Date;

public class IeFare {
    private Long id;

    private Date createtime;

    private Date updatetime;

    private Long fareId;

    private Byte canRefund;

    private String refundCondition;

    private String refundPenaltyAssessed;

    private Byte canChange;

    private String changeCondition;

    private String changePenaltyAssessed;

    private String noshowTimeRestrict;

    private Byte noshowRule;

    private String noshowCondition;

    private String depCity;

    private String arrCity;

    private Long scheduleId;

    private Long sourceFareId;

    private String airline;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Long getFareId() {
        return fareId;
    }

    public void setFareId(Long fareId) {
        this.fareId = fareId;
    }

    public Byte getCanRefund() {
        return canRefund;
    }

    public void setCanRefund(Byte canRefund) {
        this.canRefund = canRefund;
    }

    public String getRefundCondition() {
        return refundCondition;
    }

    public void setRefundCondition(String refundCondition) {
        this.refundCondition = refundCondition == null ? null : refundCondition.trim();
    }

    public String getRefundPenaltyAssessed() {
        return refundPenaltyAssessed;
    }

    public void setRefundPenaltyAssessed(String refundPenaltyAssessed) {
        this.refundPenaltyAssessed = refundPenaltyAssessed == null ? null : refundPenaltyAssessed.trim();
    }

    public Byte getCanChange() {
        return canChange;
    }

    public void setCanChange(Byte canChange) {
        this.canChange = canChange;
    }

    public String getChangeCondition() {
        return changeCondition;
    }

    public void setChangeCondition(String changeCondition) {
        this.changeCondition = changeCondition == null ? null : changeCondition.trim();
    }

    public String getChangePenaltyAssessed() {
        return changePenaltyAssessed;
    }

    public void setChangePenaltyAssessed(String changePenaltyAssessed) {
        this.changePenaltyAssessed = changePenaltyAssessed == null ? null : changePenaltyAssessed.trim();
    }

    public String getNoshowTimeRestrict() {
        return noshowTimeRestrict;
    }

    public void setNoshowTimeRestrict(String noshowTimeRestrict) {
        this.noshowTimeRestrict = noshowTimeRestrict == null ? null : noshowTimeRestrict.trim();
    }

    public Byte getNoshowRule() {
        return noshowRule;
    }

    public void setNoshowRule(Byte noshowRule) {
        this.noshowRule = noshowRule;
    }

    public String getNoshowCondition() {
        return noshowCondition;
    }

    public void setNoshowCondition(String noshowCondition) {
        this.noshowCondition = noshowCondition == null ? null : noshowCondition.trim();
    }

    public String getDepCity() {
        return depCity;
    }

    public void setDepCity(String depCity) {
        this.depCity = depCity == null ? null : depCity.trim();
    }

    public String getArrCity() {
        return arrCity;
    }

    public void setArrCity(String arrCity) {
        this.arrCity = arrCity == null ? null : arrCity.trim();
    }

    public Long getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(Long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public Long getSourceFareId() {
        return sourceFareId;
    }

    public void setSourceFareId(Long sourceFareId) {
        this.sourceFareId = sourceFareId;
    }

    public String getAirline() {
        return airline;
    }

    public void setAirline(String airline) {
        this.airline = airline == null ? null : airline.trim();
    }
}