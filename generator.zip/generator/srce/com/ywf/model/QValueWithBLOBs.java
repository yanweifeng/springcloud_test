package com.ywf.model;

public class QValueWithBLOBs extends QValue {
    private String cat4FlightLimitLv;

    private String cat4FlightLimitRt;

    public String getCat4FlightLimitLv() {
        return cat4FlightLimitLv;
    }

    public void setCat4FlightLimitLv(String cat4FlightLimitLv) {
        this.cat4FlightLimitLv = cat4FlightLimitLv == null ? null : cat4FlightLimitLv.trim();
    }

    public String getCat4FlightLimitRt() {
        return cat4FlightLimitRt;
    }

    public void setCat4FlightLimitRt(String cat4FlightLimitRt) {
        this.cat4FlightLimitRt = cat4FlightLimitRt == null ? null : cat4FlightLimitRt.trim();
    }
}