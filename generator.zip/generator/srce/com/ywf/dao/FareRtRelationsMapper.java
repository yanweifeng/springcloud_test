package com.ywf.dao;

import com.ywf.model.FareRtRelations;

public interface FareRtRelationsMapper {
    int insert(FareRtRelations record);

    int insertSelective(FareRtRelations record);
}