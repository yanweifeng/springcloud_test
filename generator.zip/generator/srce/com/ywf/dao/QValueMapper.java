package com.ywf.dao;

import com.ywf.model.QValue;

public interface QValueMapper {
    int insert(QValue record);

    int insertSelective(QValue record);
}