package com.ywf.dao;

import com.ywf.model.Refund;

public interface RefundMapper {
    int insert(Refund record);

    int insertSelective(Refund record);
}