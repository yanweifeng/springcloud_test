package com.ywf.dao;

import com.ywf.model.IeFare;

public interface IeFareMapper {
    int insert(IeFare record);

    int insertSelective(IeFare record);
}