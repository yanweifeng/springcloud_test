package com.ywf.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Test {

	
	//txt
	public static void main(String[] args) {
		
		String filename = "D:\\工具包\\generator\\1.txt";
		try {
			
			File file = new File(filename);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String str = null;
			
			while((str = br.readLine())!=null) {
				StringBuffer tableObj = new StringBuffer();
				String[] tableStr = str.toLowerCase().split("_");
				if(tableStr[0].equals("t")) {
					//do nothing
				}else {
					tableObj.append(toUpperCaseFirst(tableStr[0]));
				}
				if(tableStr.length>1) {
					for(int i=1;i<tableStr.length;i++) {
						tableObj.append(toUpperCaseFirst(tableStr[i]));
					}
				}
				//
				String temp = "<table tableName=\""+str+"\" domainObjectName=\""+tableObj.toString()+"\" enableCountByExample=\"false\" enableUpdateByExample=\"false\" enableDeleteByExample=\"false\" enableSelectByExample=\"false\" selectByExampleQueryId=\"false\"/>";
				System.out.println(temp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private static String toUpperCaseFirst(String word) {
		if(null == word || "".equals(word.trim())) {
			return "";
		}
		String f = word.charAt(0)+"";
		return f.toUpperCase()+word.substring(1, word.length());
	}

}
